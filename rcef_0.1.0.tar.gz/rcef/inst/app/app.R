# ============================================================
#  Discard Raising Explorer  (v2)
#  Shiny front end over the 0_Functions_*.R data modules
#  Run with:  shiny::runApp("app.R")
# ============================================================

library(shiny)
library(DT)

# Where the helper files live. On shinyapps.io (deployed with
# appDir = "R_development") they sit in the working directory, so ".".
# Run locally from the parent APP/ folder they are in "R_development/".
# Auto-detect rather than hard-coding, so both layouts work; an explicit
# rcef.app_dir option still overrides.
APP_DIR <- getOption(
  "rcef.app_dir",
  if (file.exists("0_Functions_utils.R")) "." else "R_development")
# ---- data modules: package-ready, no shiny, usable on their own in RStudio.
# Order matters only here: utils and theme define the vocabulary, units and
# palettes the rest build on. They ship in this folder (not the external R/
# one) so they load on shinyapps.io too.
source(file.path(APP_DIR, "0_Functions_utils.R"))     # vocab, derive, units
source(file.path(APP_DIR, "0_Functions_theme.R"))     # one look, stable colours
source(file.path(APP_DIR, "0_Functions_classify.R"))  # sampling status
source(file.path(APP_DIR, "0_Functions_groups.R"))    # auto + manual grouping
source(file.path(APP_DIR, "0_Functions_raising.R"))   # apply, scenarios, compare
source(file.path(APP_DIR, "0_Functions_emit.R"))      # the reproducible script
source(file.path(APP_DIR, "0_Functions_taf.R"))       # the same, as an ICES TAF set
# ---- shiny-only helpers (icons, panel sizes, legend panel, DT styling)
source(file.path(APP_DIR, "app_ui_helpers.R"))
source(file.path(APP_DIR, "session_log.R"))
source(file.path(APP_DIR, "summaries.R"))
source(file.path(APP_DIR, "mod_length.R"))
source(file.path(APP_DIR, "mod_alloc_raising.R"))
source(file.path(APP_DIR, "external_loader.R"))
source(file.path(APP_DIR, "mod_intercatch.R"))
source(file.path(APP_DIR, "mod_native_raising.R"))
# The plotting module is package-ready and lives in the external R/ folder
# for standalone use, but a copy ships here and is sourced directly: the
# plots are core to the app and the external R/ folder is not part of the
# shinyapps.io bundle, so it must load regardless.
source(file.path(APP_DIR, "0_Functions_plots.R"))

# The InterCatch and raising functions are maintained outside this app;
# load whatever is present and carry on without the rest.
EXT_DIR <- getOption("rcef.app_dir", "R")
EXT <- load_external(getOption("rcef.external_dir", EXT_DIR))
EXT_STATUS <- external_status(EXT)

suppressPackageStartupMessages({
  library(dplyr); library(tidyr); library(ggplot2); library(rlang)
  library(purrr); library(ggalluvial); library(data.table); library(stringr)
  # jsonlite is NOT attached: its validate() would mask shiny::validate()
  requireNamespace("jsonlite", quietly = TRUE)
})



alloc_box <- function() uiOutput("alloc_box")


# ---------------------------------------------------------
#  Section 1: InterCatch, split across three tabs
# ---------------------------------------------------------
ic_load_ui <- function() tagList(
  uiOutput("ic_input_note"),
  sidebarLayout(
  sidebarPanel(width = 4,
    h4("Input files"),
    radioButtons("ic_mode", NULL,
      c("Upload files" = "upload", "Point at a folder" = "dir"), "upload"),
    conditionalPanel("input.ic_mode == 'upload'",
      fileInput("ic_upl", NULL, multiple = TRUE, accept = c(".csv", ".txt")),
      span(class = "note",
           "Select the InterCatch files. They are matched to roles on the ",
           "right; fix any row matched to the wrong file.")),
    conditionalPanel("input.ic_mode == 'dir'",
      dir_picker("ic_path", "."),
      span(class = "note",
           "Type a path, or click the folder to browse into subdirectories.")),
    conditionalPanel("input.ic_source == 'icout'",
      textInput("ic_years", "years (comma separated)", "2022")),
    tags$hr(),
    h4("stock_relation"),
    radioButtons("ic_rel_mode", NULL,
      c("Build with funMakeRelation(year)" = "build",
        "Upload a csv" = "upload",
        "Let funICoutCEF build it" = "auto")),
    conditionalPanel("input.ic_rel_mode == 'build'",
      numericInput("ic_rel_year", "year", 2022, 1990, 2100, 1),
      actionButton("build_rel", "Build stock_relation", class = "btn-sm")),
    conditionalPanel("input.ic_rel_mode == 'upload'",
      fileInput("ic_rel_file", NULL, accept = ".csv")),
    uiOutput("rel_status")),
  mainPanel(width = 8,
    uiOutput("cfg_banner"),
    h4("Files and their roles"),
    uiOutput("ic_file_map"),
    tags$hr(),
    h4("Availability"), uiOutput("ic_status"))))

ic_output_ui <- function() tagList(
  span(class = "note",
       "Select the output type required. If to_file or to_upload is chosen, ",
       "fill in out_path, file_prefix and file_suffix (those fields appear ",
       "only when a file is being written)."),
  sidebarLayout(
  sidebarPanel(width = 4,
    h4("Output"),
    checkboxGroupInput("ic_output_format", "output_format",
      choiceNames = lapply(names(OUTPUT_DESC),
                           function(k) opt_lab(k, OUTPUT_DESC[[k]])),
      choiceValues = names(OUTPUT_DESC),
      selected = c("to_list", "to_file")),
    # out_path / file_prefix / file_suffix are only needed when a file is
    # actually written, so they stay hidden until to_file or to_upload is
    # ticked - nothing to fill in otherwise
    conditionalPanel(
      paste0("(input.ic_output_format || []).indexOf('to_file') > -1 || ",
             "(input.ic_output_format || []).indexOf('to_upload') > -1"),
      textInput("ic_out_path", "out_path", "./data/data_CEF_format"),
      textInput("ic_prefix", "file_prefix", ""),
      span(class = "note", "Taken from the stock code and year set at start-up."),
      textInput("ic_suffix", "file_suffix", "_CEF_v17.1")),
    tags$hr(), h4("Options"),
    checkboxInput("ic_incl_bms",
      opt_lab("include_BMS_Caton",
              "keep BMS rows in the Caton stack; off drops them"), TRUE),
    checkboxInput("ic_patch_psu",
      opt_lab("patch_missing_DIS_PSU",
              "insert FishingTrip and 0 where a discard domain has no PSU"),
      FALSE),
    checkboxInput("ic_keep_temp",
      opt_lab("keep_temp_file",
              "keep the temporary exchange files funICoutCEF() writes (output format only)"),
      FALSE),
    selectInput("ic_metier6", "metier6",
                c("NULL (MIS_MIS_0_0_0)" = "", "Fleet" = "Fleet")),
    span(class = "note",
         "Fleet copies fleetValue into metier6 and remaps count units to NE3; ",
         "NULL leaves the MIS_MIS_0_0_0 placeholder."),
    tags$hr(),
    actionButton("run_ic", "Run conversion", class = "btn-success btn-lg")),
  mainPanel(width = 8,
    h4("Status"), uiOutput("ic_result"))))

# ---------------------------------------------------------
#  A CEF result view, shared by section 1 and section 2
# ---------------------------------------------------------
cef_result_ui <- function(src) {
  ns <- function(x) paste0(src, "_", x)
  tagList(
  span(class = "note",
       "Overview of the three CEF tables (CN: catch, DN: distributions and ",
       "EN: effort)."),
  tabsetPanel(
    tabPanel("catches",
      fluidRow(column(5, h4("Overview"), tbl_slot(ns("cat_sum"))),
               column(7, h4("By catch category"), tbl_slot(ns("cat_cat")))),
      h4("Preview"), tbl_slot(ns("cat_prev"))),
    tabPanel("distributions",
      span(class = "note",
           "Biology is linked to the catch table through domainBiology: only ",
           "catch strata carrying that key, and whose key appears here, have ",
           "been sampled. distributionType says what was measured ",
           "(LengthTotal / Age); variableType says what the value is ",
           "(Number / WeightLive)."),
      fluidRow(column(5, h4("Overview"), tbl_slot(ns("dist_sum"))),
               column(7, h4("What was measured"), tbl_slot(ns("dist_type")))),
      h4("Biology sampling by stratum"),
      fluidRow(column(3, selectInput(ns("bio_dim"), "Group by", DIMS, "Fleet")),
               column(9, tbl_slot(ns("bio_cov")))),
      h4("Preview"), tbl_slot(ns("dist_prev"))),
    tabPanel("effort",
      h4("Overview"), tbl_slot(ns("eff_sum")),
      h4("Preview"), tbl_slot(ns("eff_prev")))))
}

# ---------------------------------------------------------
#  CEF database call: credentials and request
#  Framework only. The actual fetch lives in db_fetch_cef() on the
#  server side; these two panels collect what it will need.
# ---------------------------------------------------------
db_cred_ui <- function() sidebarLayout(
  sidebarPanel(width = 4,
    h4("Credentials"),
    textInput("db_user", "Username", ""),
    passwordInput("db_pass", "Password", ""),
    span(class = "note",
         "Used only to authenticate this session's database call; not stored."),
    actionButton("db_connect", "Connect", class = "btn-primary")),
  mainPanel(width = 8, uiOutput("db_cred_status")))

db_request_ui <- function() sidebarLayout(
  sidebarPanel(width = 4,
    h4("Request"),
    textInput("db_stock", "Stock code", "", placeholder = "bll.27.3a47de"),
    numericInput("db_year", "Year",
                 as.integer(format(Sys.Date(), "%Y")) - 1, 1990, 2100, 1),
    tags$hr(),
    h4("CEF tables to request"),
    checkboxInput("db_cn", opt_lab("CN", "catch"), TRUE),
    checkboxInput("db_dn", opt_lab("DN", "distributions"), TRUE),
    checkboxInput("db_en", opt_lab("EN", "effort"), TRUE),
    tags$hr(),
    actionButton("db_request", "Request data", class = "btn-success btn-lg")),
  mainPanel(width = 8, load_owner_ui(3), uiOutput("db_request_status")))

# ---------------------------------------------------------
#  Section 2: load the three CEF tables
# ---------------------------------------------------------
cef_load_ui <- function() sidebarLayout(
  sidebarPanel(width = 4,
    h4("CEF files"),
    span(class = "note",
         "catches is required. distributions is only needed when lengths or ",
         "ages are being allocated; effort is optional."),
    radioButtons("cef_mode", NULL,
      c("Upload files" = "upload", "Point at a folder" = "dir"), "upload"),
    conditionalPanel("input.cef_mode == 'upload'",
      fileInput("file", "catches", accept = c(".csv", ".txt")),
      uiOutput("cef_dist_input"),
      fileInput("file_eff", "effort (optional)", accept = c(".csv", ".txt"))),
    conditionalPanel("input.cef_mode == 'dir'",
      load_owner_ui(2),
      dir_picker("cef_dir", "."),
      span(class = "note",
           "The three CEF tables are matched by name: catches, ",
           "distributions, effort."),
      actionButton("cef_load_dir", "Load from folder", class = "btn-sm btn-primary")),
    selectInput("sep", "Separator", c("," = ",", ";" = ";", "tab" = "\t")),
    tags$hr(),
    uiOutput("stock_ui"), uiOutput("year_ui"),
    span(class = "note",
         "Sufficiency thresholds are set where they are used: on each ",
         "Sampling coverage tab.")),
  mainPanel(width = 8,
    uiOutput("cfg_banner"),
    uiOutput("data_msg"),
    h4("Files"), uiOutput("cef_file_check"),
    span(class = "note",
         "Raw preview only here - coverage and thresholds come later.")))

# ---------------------------------------------------------
#  Section 3: merged plot tabs
# ---------------------------------------------------------
coverage_ui <- function() sidebarLayout(
  sidebarPanel(width = 3,
    h4("Plot"),
    # rendered server-side: the heatmap and bubbles need both axes, so they
    # grey out when X / Fill is set to (none)
    uiOutput("cov_type_bar"),
    # The threshold sits directly under the plot icons because it is what
    # the colours in those two plots MEAN. The bars view splits weight into
    # sampled and unsampled and never consults a threshold, so showing the
    # control there invites the reader to move it and wonder why nothing
    # happened. The condition mirrors cov_type_eff(): with no X / Fill the
    # heatmap and bubbles are unavailable and bars is what is drawn.
    conditionalPanel("input.cov_type != 'bars' && input.cov_fill != ''",
      threshold_box("threshold", NULL, "% coverage")),
    tags$hr(),
    role_chips("cov", c(y = "Y axis", fill = "X / Fill", facet = "Facet"),
               c("Fleet", "Season", "Country"), stacked = TRUE),
    apply_bar("cov"),
    tags$hr(),
    level_box("cov")),
  mainPanel(width = 9,
    div(class = "legend-strip", plotOutput("cov_legend", height = "150px")),
    plot_slot("cov_plot", capture = TRUE)))

drates_ui <- function() sidebarLayout(
  sidebarPanel(width = 3,
    h4("Plot"),
    pick_bar("dr_type", list(raw = "Raw strata", box = "Boxplot"), "raw"),
    tags$hr(),
    conditionalPanel("input.dr_type != 'box'",
      role_chips("dr", c(x = "X axis", fill = "Colour", shape = "Shape",
                         facet = "Facet"),
                 c("Fleet", "Area", "Season", "Country"), stacked = TRUE),
      checkboxInput("dr_jitter", "Jitter", TRUE)),
    conditionalPanel("input.dr_type == 'box'",
      role_chips("box", c(x = "X axis", fill = "Fill", facet = "Facet"),
                 c("Country", "Area", ""), stacked = TRUE),
      checkboxInput("box_points", "Show individual strata", TRUE),
      checkboxInput("box_pooled", "Show catch-weighted pooled rate", TRUE)),
    apply_bar("dr"),
    tags$hr(),
    level_box("dr")),
  mainPanel(width = 9,
    div(class = "legend-strip", plotOutput("dr_legend", height = "120px")),
    plot_slot("dr_plot", capture = TRUE),
    tags$hr(), h4("Underlying strata"), tbl_slot("dr_tbl")))

final_ui <- function() sidebarLayout(
  sidebarPanel(width = 3,
    h4("Adopted allocation"),
    span(class = "note",
         "The one that feeds the assessment. It is the allocation the ",
         "script records as final; the rest stay as exploration."),
    selectInput("final_alloc", NULL, choices = character(0)),
    actionButton("run_final", "Raise with this allocation",
                 class = "btn-success"),
    tags$hr(),
    h4("Aggregation"),
    selectInput("fin_x", "Split by", c("(whole stock)" = "", DIMS), ""),
    selectInput("fin_facet", "Facet", c(NONE, DIMS), ""),
    tags$hr(),
    h4("Cross-tab"),
    selectInput("fin_row", "Rows", DIMS, "Country"),
    selectInput("fin_col", "Columns", DIMS, "Area"),
    apply_bar("fin"),
    level_box("nr"), alloc_box()),
  mainPanel(width = 9,
    uiOutput("final_status"),
    plot_slot("fin_plot", capture = TRUE),
    h4("Imported and raised data overview"), tbl_slot("fin_overview"),
    h4("Discards, landings and BMS (tonnes)"), tbl_slot("fin_crosstab")))

fragments_ui <- function() fluidPage(fluidRow(
  column(3,
    checkboxGroupInput("code_parts", "Include",
      c("Header" = "head", "Load and derive" = "derive",
        "Exploration plots" = "explore",
        "Allocations and raising" = "auto"),
      selected = c("head", "derive", "explore", "auto")),
    span(class = "note",
         "Same text as the live script; these only choose which blocks ",
         "are shown.")),
  column(9, verbatimTextOutput("code_txt"))))

# ---------------------------------------------------------
#  Length exploration: three views over the same linked data.
#  catchCategory is now part of the stratum keys rather than a
#  tab, so landings and discards can be compared side by side or
#  separated with a facet, exactly like any other dimension.
# ---------------------------------------------------------

# Landings and discards are sampled and allocated separately, so exactly
# one is plotted at a time - a picker, not a filter.
len_cc_filter <- function(ns)
  tagList(h4("Catch category"),
          pick_bar(ns("cc"), list(catlan = "Landings", catdis = "Discards"),
                   "catlan"))

# The sufficiency thresholds, shown where they are used rather than at
# load time. Coverage asks how much of the weight carries a
# distribution; measurements asks how many fish that distribution was
# built on. A stratum has to clear both to be a usable donor, so a
# domain resting on eight fish cannot pass on coverage alone.
threshold_box <- function(id_cov, id_meas = NULL, cov_label = "% coverage",
                          cov_default = 50, meas_default = 0) {
  tagList(
    h4("Sufficiency"),
    fluidRow(
      column(if (is.null(id_meas)) 12 else 6,
             numericInput(id_cov, cov_label, cov_default, 0, 100, 5)),
      if (!is.null(id_meas))
        column(6, numericInput(id_meas, "min measurements", meas_default,
                               0, 100000, 10)) else NULL),
    span(class = "note",
         if (is.null(id_meas))
           "Strata at or above this share of sampled weight count as covered."
         else
           paste("Coverage sets the sampling status; the measurement count",
                 "refines it. A stratum with fewer than this many measured",
                 "fish is flagged as a warning (a lighter shade) rather than",
                 "trusted - it is not dropped, so its coverage still shows.")))
}

# --- 3rd level 1: sampling coverage (same shapes as the discards) ---
len_coverage_ui <- function(p, type = "LengthTotal") {
  ns <- function(x) paste0(p, "_cov_", x)
  sidebarLayout(
    sidebarPanel(width = 3,
      len_cc_filter(ns),
      tags$hr(),
      h4("Plot"),
      pick_bar(ns("type"),
               list(heatmap = "Heatmap", bubbles = "Bubbles", bars = "Bars"),
               "heatmap"),
      # same reasoning as the discard coverage tab: the two thresholds are
      # what the heatmap and bubble colours mean, and mean nothing to bars
      conditionalPanel(sprintf("input.%s != 'bars'", ns("type")),
        threshold_box(paste0(p, "_thr_cov"), paste0(p, "_thr_meas"))),
      tags$hr(),
      role_chips(ns("r"), c(y = "Y axis", fill = "X / Fill", facet = "Facet"),
                 c("Fleet", "Country", "Area"), stacked = TRUE),
      apply_bar(paste0(p, "_cov")),
      tags$hr(), level_box(paste0(p, "_lv"))),
    mainPanel(width = 9,
      uiOutput(paste0(p, "_status")),
      div(class = "legend-strip", plotOutput(ns("legend"), height = "150px")),
      plot_slot(ns("plot"), capture = TRUE),
      tags$hr(), h4("Link summary"), tbl_slot(paste0(p, "_sum"))))
}

# Free the panel scales. Fixed scales keep panels comparable but squash
# a small stratum against a big one; freeing an axis makes the shape
# readable at the cost of comparability, so both are offered.
free_scale_ticks <- function(ns)
  div(style = "display:flex;gap:12px;margin:2px 0 6px 0",
      checkboxInput(ns("freex"), "free x", FALSE),
      checkboxInput(ns("freey"), "free y", FALSE))

# --- 3rd level 2: numbers at length -------------------------------
len_numbers_ui <- function(p, type = "LengthTotal") {
  ns <- function(x) paste0(p, "_n_", x)
  sidebarLayout(
    sidebarPanel(width = 3,
      len_cc_filter(ns),
      tags$hr(),
      h4("Plot"),
      pick_bar(ns("type"), list(hist = "Histogram", ridge = "Density"), "hist"),
      tags$hr(),
      role_chips(ns("r"), c(fill = "Stack / colour", facet = "Facet",
                            shape = "Facet 2"),
                 c("Country", "Fleet", ""), stacked = TRUE),
      free_scale_ticks(ns),
      conditionalPanel(sprintf("input.%s != 'ridge'", ns("type")),
        checkboxInput(ns("stack"), "Stack the bars", TRUE)),
      conditionalPanel(sprintf("input.%s == 'ridge'", ns("type")),
        sliderInput(ns("smooth"), "Smoothing", 0.2, 3, 1, 0.1),
        span(class = "note",
             "Turn it down for a well-sampled stratum to keep the detail, ",
             "up for a sparse or noisy one so the shape stays readable.")),
      apply_bar(paste0(p, "_n")),
      tags$hr(), level_box(paste0(p, "_lv"))),
    mainPanel(width = 9,
      uiOutput(paste0(p, "_status")),
      div(class = "legend-strip", plotOutput(ns("legend"), height = "120px")),
      plot_slot(ns("plot"), capture = TRUE)))
}

# --- 3rd level 3: mean weight at length ---------------------------
len_meanw_ui <- function(p, type = "LengthTotal") {
  ns <- function(x) paste0(p, "_w_", x)
  sidebarLayout(
    sidebarPanel(width = 3,
      div(class = "chain", style = "font-size:11.5px;line-height:1.5",
          tags$b("How the points are built"), tags$br(),
          "Whatever is not given a Colour, Facet or Shape is averaged ",
          "over. The mean is weighted by the numbers measured, and the ",
          "band around the dots is one standard deviation across the ",
          "strata that were combined - so the spread hidden by the ",
          "grouping stays visible. Give Shape a variable and those ",
          "strata are drawn separately instead, and the band disappears ",
          "because nothing is being averaged."),
      tags$hr(),
      len_cc_filter(ns),
      tags$hr(),
      h4("Plot"), pick_bar(ns("type"), list(linedot = "Line + dots"), "linedot"),
      tags$hr(),
      role_chips(ns("r"), c(fill = "Colour", facet = "Facet",
                            shape = "Facet 2"),
                 c("Fleet", "Country", ""), stacked = TRUE),
      free_scale_ticks(ns),
      selectInput(ns("pt"), "Shape",
                  c("-- none (average the rest) --" = "",
                    setNames(DIMS, DIMS)), ""),
      checkboxInput(ns("points"), "Show points", TRUE),
      apply_bar(paste0(p, "_w")),
      tags$hr(), level_box(paste0(p, "_lv"))),
    mainPanel(width = 9,
      uiOutput(paste0(p, "_status")),
      div(class = "legend-strip", plotOutput(ns("legend"), height = "120px")),
      plot_slot(ns("plot"), capture = TRUE)))
}

# --- 2nd level: allocation groups ---------------------------------
len_alloc_ui <- function(p, type = "LengthTotal") {
  ns <- function(x) paste0(p, "_ga_", x)
  div(style = "padding:8px 4px",
    pick_bar(ns("method"),
             list(ladder = "Hierarchical", manual = "Manual groups"), "ladder"),
    checkboxInput(ns("bms"), "Treat BMS as discards", TRUE),
    span(class = "note",
         "BMS is a landing in the exchange format but behaves like a ",
         "discard. With this on, any clause naming Dis also picks up BMS."),
    conditionalPanel(sprintf("input.%s != 'manual'", ns("method")),
      sidebarLayout(
        sidebarPanel(width = 3,
          h4("Nesting order"),
          checkboxInput(ns("keepcc"), "Never drop catchCategory", TRUE),
          span(class = "note",
               "On: the cascade stops at the catch category, so a landings ",
               "stratum is only ever matched to landings. Off: once the ",
               "other keys are exhausted the category is dropped too and ",
               "landings and discards pool together."),
          uiOutput(ns("keys")),
          uiOutput(ns("chain")),
          tags$hr(),
          textInput(ns("name"), "Save as", "alloc_1"),
          actionButton(ns("save"), "Save allocation", class = "btn-success")),
        mainPanel(width = 9,
          uiOutput(ns("status")),
          h4("What each step resolves"),
          span(class = "note",
               "One row per rung in the order it is tested, with the running ",
               "total. The last row is whatever the ladder never resolved."),
          tbl_slot(ns("steps")),
          h4("Strata the ladder never resolved"),
          span(class = "note",
               "Heaviest first. If this is not empty, either a threshold is ",
               "too strict or the category must be allowed to drop."),
          tbl_slot(ns("cmissing")),
          h4("Strata and the group that raises them"),
          plot_slot(ns("river")),
          h4("One river per step"),
          span(class = "note",
               "What each rung claims and where it draws from, read the same ",
               "way as the manual per-rule rivers."),
          uiOutput(ns("step_rivers"))))),
    conditionalPanel(sprintf("input.%s == 'manual'", ns("method")),
      sidebarLayout(
        sidebarPanel(width = 3,
          h4("Build a clause"),
          span(class = "note",
               "Build a clause, then drop it into either box. The two can ",
               "differ: a group of strata may be allocated from a wider ",
               "pool of sampled data."),
          selectInput(ns("var"), "Variable", LEN_DIMS, "Area"),
          uiOutput(ns("vals")),
          checkboxInput(ns("neg"), "NOT in these", FALSE),
          actionButton(ns("add"), "Add to clause", class = "btn-sm btn-primary"),
          actionButton(ns("clear"), "Clear", class = "btn-sm"),
          uiOutput(ns("clause")),
          tags$hr(),
          div(class = "condbox",
              div(class = "condtitle", "allocStrataCond - strata to allocate"),
              uiOutput(ns("alloc_txt")),
              actionButton(ns("to_alloc"), "Put clause here",
                           class = "btn-sm btn-info")),
          div(style = "display:flex;gap:6px;margin:6px 0",
              actionButton(ns("mirror"), HTML("Copy down &darr;"),
                           class = "btn-sm btn-warning", style = "flex:1")),
          div(class = "condbox",
              div(class = "condtitle", "bioMatchedCond - sampled data used"),
              uiOutput(ns("matched_txt")),
              actionButton(ns("to_matched"), "Put clause here",
                           class = "btn-sm btn-info")),
          tags$hr(),
          h4("5. Save group"),
          textInput(ns("gid"), "Group id", "GA1"),
          textInput(ns("glab"), "Label", ""),
          actionButton(ns("saverule"), "Save group", class = "btn-success"),
          tags$hr(),
          h4("6. Order"),
          span(class = "note",
               "First match wins, so the order decides what each group ",
               "catches. Use the arrows to reorder."),
          uiOutput(ns("order")),
          tags$hr(),
          textInput(ns("mname"), "Save this set as", "manual_1"),
          actionButton(ns("savemanual"), "Save allocation",
                       class = "btn-success")),
        mainPanel(width = 9,
          uiOutput(ns("bmsnote")),
          h4("allocStrataCond / bioMatchedCond"),
          span(class = "note",
               "The two lists as they would be written in a script."),
          verbatimTextOutput(ns("conds")),
          h4("What each group allocates"), tbl_slot(ns("rules")),
          tags$hr(),
          h4("What is assigned, and what is still missing"),
          span(class = "note",
               "One row per rule in the order it is tested, with the running ",
               "total. The last row is whatever no rule has claimed yet - the ",
               "gap to close."),
          tbl_slot(ns("progress")),
          h4("Strata still unassigned"),
          span(class = "note", "Heaviest first, so the biggest hole is on top."),
          tbl_slot(ns("missing")),
          tags$hr(),
          h4("Strata and the data they are allocated from"),
          plot_slot(ns("mriver")),
          h4("One river per rule"),
          span(class = "note",
               "The same reading as the automated ladder: what each rule ",
               "claims, and where it draws from."),
          uiOutput(ns("rule_rivers"))))))
}

# --- 2nd level: raising ------------------------------------------
len_raise_ui <- function(p, what = "Length") {
  ns <- function(x) paste0(p, "_rz_", x)
  div(style = "padding:8px 4px",
    # same two-step shape as the discard raising: compare first, adopt one
    pick_bar(ns("mode"), list(stgexpl = "Compare allocations",
                              stgraise = "Final allocation"), "stgraise"),
    tags$hr(),
    conditionalPanel(sprintf("input.%s == 'stgexpl'", ns("mode")),
      sidebarLayout(
        sidebarPanel(width = 3,
          h4("Compare"),
          span(class = "note",
               "Every saved allocation is re-run against the data currently ",
               "loaded, so the comparison is like-for-like."),
          actionButton(ns("runall"), "Run all allocations",
                       class = "btn-success"),
          tags$hr(),
          radioButtons(ns("cmpval"), "Show",
                       c("Numbers" = "numbers",
                         "Stock weight (t)" = "tonnes"), "numbers"),
          selectInput(ns("cmpfacet"), "Facet",
                      c(NONE, "Catch category" = "catchCategory"),
                      "catchCategory"),
          apply_bar(ns("cmp"))),
        mainPanel(width = 9,
          uiOutput(ns("cmpstatus")),
          h4("Totals by allocation"), tbl_slot(ns("cmptot")),
          div(class = "legend-strip", plotOutput(ns("cmplegend"), height = "90px")),
          plot_slot(ns("cmpplot"))))),
    conditionalPanel(sprintf("input.%s == 'stgraise'", ns("mode")),
  sidebarLayout(
    sidebarPanel(width = 3,
      h4("Allocation to apply"),
      selectInput(ns("alloc"), NULL, choices = character(0)),
      span(class = "note",
           "Both the hierarchical and the manual builders save here."),
      tags$hr(),
      h4("catchAllocationAoL settings"),
      selectInput(ns("origin"), "originType_catch",
                  c("WGEstimate", "Official"), "WGEstimate"),
      selectInput(ns("vartype"), "variableType_catch",
                  c("WeightLive", "Number"), "WeightLive"),
      selectInput(ns("weighting"), "weighting",
                  c("NumberAtAoL", "CATON"), "NumberAtAoL"),
      tags$hr(),
      actionButton(ns("run"), sprintf("Allocate %s", tolower(what)),
                   class = "btn-success btn-lg"),
      tags$hr(),
      h4("Aggregation"),
      selectInput(ns("group"), "Group by", c("catchCategory", NONE),
                  "catchCategory"),
      numericInput(ns("minaol"), sprintf("min %s", what), 0, 0, 100, 1),
      numericInput(ns("maxaol"), sprintf("max %s (blank = all)", what),
                   NA, 0, 1000, 1),
      checkboxInput(ns("plus"), "plus group", FALSE),
      apply_bar(ns("fig"))),
    mainPanel(width = 9,
      uiOutput(ns("raisewarn")),
      uiOutput(ns("status")),
      h4("Imported vs allocated"), tbl_slot(ns("overview")),
      div(class = "legend-strip", plotOutput(ns("legend"), height = "90px")),
      h4(sprintf("Numbers at %s", tolower(what))),
      plot_slot(ns("nplot"), capture = TRUE),
      h4(sprintf("Stock weight at %s (tonnes)", tolower(what))),
      plot_slot(ns("wplot"), capture = TRUE),
      tags$hr(),
      h4("Aggregated numbers"), tbl_slot(ns("ntab")),
      h4("Aggregated mean weights"), tbl_slot(ns("wtab"))))))
}

# ---------------------------------------------------------
#  Length / Age skeletons
# ---------------------------------------------------------
stub_note <- function(...) div(class = "chain",
  style = "font-size:13px;line-height:1.55;max-width:780px", ...)

sampling_stub <- function(kind) {
  v <- if (kind == "length") "length class" else "age class"
  sidebarLayout(
    sidebarPanel(width = 3,
      h4("Plot"),
      pick_bar(paste0(kind, "_type"),
               list(heatmap = "Coverage", bars = "Sampled", box = "Distribution"),
               "heatmap"),
      tags$hr(),
      role_chips(paste0(kind, "_cov"),
                 c(y = "Y axis", fill = "X / Fill", facet = "Facet"),
                 c("Fleet", "Season", "Country"), stacked = TRUE),
      selectInput(paste0(kind, "_cc"), "Catch category",
                  c("Landings" = "Lan", "Discards" = "Dis", "Both" = "")),
      level_box(paste0(kind, "_lv"))),
    mainPanel(width = 9,
      stub_note(tags$b("Not built yet."), tags$br(),
        "The stratum here carries one more dimension than the discard ",
        "section: catchCategory. Landings and discards are measured ",
        "separately, so a stratum is fleet x country x area x season x catch ",
        "category, and the coverage question becomes which of those have a ",
        "distribution at all - read off domainBiology, not domainCatchDis.",
        tags$br(), tags$br(),
        "The rate view is replaced by two curves: numbers at ", v,
        " and mean weight at ", v, ". The equivalent of the discard-rate ",
        "boxplot is those distributions overlaid by stratum, so it is ",
        "visible whether pooling two strata merges compatible shapes or ",
        "smears two different ones together.")))
}

grouping_stub <- function(kind) div(style = "padding:8px 4px",
  pick_bar(paste0(kind, "_grp"),
           list(ladder = "Hierarchical", manual = "Manual groups"), "ladder"),
  stub_note(tags$b("Not built yet."), tags$br(),
    "Both builders carry over unchanged in shape - a threshold cascade and ",
    "an ordered rule table producing strataCond and matchedDataCond. What ",
    "changes is the criterion: a stratum qualifies on number of samples and ",
    "number of measurements rather than on the sampled fraction of ",
    "landings, so the thresholds are counts, not percentages."))

alloc_stub <- function(kind) div(style = "padding:8px 4px",
  stub_note(tags$b("Not built yet."), tags$br(),
    "Runs the groups through catchAllocationAoL() from ",
    "0_Functions_age-length_alloc.R, the age/length counterpart of ",
    "catchRaising(), and compares allocations the same way the discard ",
    "section does."))

# A clause you can pick up and drop into either box. The buttons stay as
# a fallback, since drag-and-drop is awkward on a trackpad.
dropzone <- function(which) tags$div(
  id = paste0("drop_", which), class = "dropzone",
  ondragover = "event.preventDefault(); this.classList.add('over')",
  ondragleave = "this.classList.remove('over')",
  ondrop = sprintf(
    "event.preventDefault(); this.classList.remove('over');
     Shiny.setInputValue('drop_target','%s',{priority:'event'})", which),
  uiOutput(paste0(which, "_txt_ui")))

# Variable chips: the ones that matter are shown, the rest are one click
# away, rather than every column being dumped into a dropdown.
var_chips <- function(id, shown, extra, selected) {
  tagList(
    div(lapply(shown, function(v)
      tags$span(class = paste("varchip", if (identical(v, selected)) "on" else ""),
                onclick = sprintf("Shiny.setInputValue('%s','%s',{priority:'event'})",
                                  id, v), v))),
    if (length(extra))
      tags$details(style = "margin-top:4px",
        tags$summary(class = "note", style = "cursor:pointer",
                     sprintf("more variables (%s)", length(extra))),
        div(lapply(extra, function(v)
          tags$span(class = paste("varchip", if (identical(v, selected)) "on" else ""),
                    onclick = sprintf("Shiny.setInputValue('%s','%s',{priority:'event'})",
                                      id, v), v))))
    else NULL)
}



stub_ui <- function(kind, what) {
  lbl <- if (kind == "length") "Length" else "Age"
  var <- if (kind == "length") "length class" else "age class"
  body <- switch(what,
    provision = list(
      "Same shape as the discard sampling tabs, with one extra stratum ",
      "dimension: catchCategory. Landings and discards are sampled ",
      "separately, so a stratum here is fleet x country x area x season x ",
      "catch category. The coverage question becomes: which strata have a ",
      "distribution at all?"),
    dist = list(
      "Replaces the discard-rate view. Instead of one rate per stratum ",
      "there are two curves: numbers at ", var, " and mean weight at ",
      var, ". The equivalent of the boxplot is a set of distributions ",
      "overlaid by stratum, so you can see whether pooling two strata ",
      "would merge compatible shapes or smear two different ones together."),
    groups = list(
      "The same two builders as the discard section - a threshold cascade ",
      "and a manual rule table - producing strataCond and matchedDataCond. ",
      "The rules will need different criteria: number of samples and ",
      "number of measurements rather than a sampled fraction of landings."),
    alloc = list(
      "Applies the groups through the age-length allocation functions ",
      "and compares scenarios, as the discard section does."))
  div(style = "padding:18px;max-width:760px",
      h3(paste(lbl, "-", tools::toTitleCase(what))),
      div(class = "chain", style = "font-size:13px;line-height:1.5",
          tags$b("Not built yet."), tags$br(), do.call(tagList, body)),
      div(class = "note", style = "margin-top:12px",
          "The stratum machinery (build_strata, the role slots, the group ",
          "builders, the scenario store and the script log) is shared, so ",
          "this section reuses it rather than duplicating it."))
}

nr_ui <- function() {
  sidebarLayout(
    sidebarPanel(width = 3,
      h4("Groups from"),
      span(class = "note",
           "Raising always runs through catchRaising(), on the full CEF ",
           "table, so catch categories, units and domains survive and every ",
           "row comes back flagged imported or raised."),
      radioButtons("nr_source", NULL,
        c("Auto raising cascade" = "auto", "Manual groups" = "manual")),
      selectInput("nr_type", "type", c("discards", "BMS")),
      selectInput("nr_origin", "originType", c("WGEstimate", "Official")),
      selectInput("nr_vartype", "variableType", c("WeightLive", "Number")),
      checkboxInput("nr_assembled", "assembled_output", TRUE),
      textInput("nr_log", "logFile", "Log.txt"),
      tags$hr(),
      actionButton("run_native", "Run raising", class = "btn-success"),
      level_box("nr"), alloc_box()),
    mainPanel(width = 9,
      uiOutput("nr_status"),
      h4("Conditions that will be used"),
      verbatimTextOutput("nr_conds"),
      h4("Result"), tbl_slot("nr_tbl"),
      h4("By group"), tbl_slot("nr_grp")))
}

# A copy-to-clipboard button for a given verbatimTextOutput id. Factored out
# because every one of the seven script views needs one.
copy_btn <- function(id) tags$button(
  "Copy to clipboard", class = "btn btn-sm btn-primary",
  style = "margin-bottom:6px",
  onclick = sprintf(
    "var t=document.getElementById('%s').innerText;
     navigator.clipboard.writeText(t);
     var b=this; b.innerHTML='Copied';
     setTimeout(function(){b.innerHTML='Copy to clipboard';},1400);", id))

# ---------------------------------------------------------
#  The TAF script set
# ---------------------------------------------------------
# One tab per file. Each shows only that file, because the whole point of
# the TAF split is that a reader can open the stage they care about without
# reading the other six - a reviewer checking why a group was drawn opens
# model_explore_discards.R and stops there.

taf_ui <- function(part) {
  fid <- paste0("taf_", part)
  fluidPage(fluidRow(
    column(3,
      div(class = "tafhead",
          div(class = "taffile", TAF_FILES[[part]]),
          div(class = "note", TAF_BLURB[[part]])),
      downloadButton(paste0("dl_", fid),
                     sprintf("Download %s", TAF_FILES[[part]]),
                     class = "btn-sm btn-primary")),
    column(9, copy_btn(paste0(fid, "_txt")),
           verbatimTextOutput(paste0(fid, "_txt")))))
}

# The kept-plot list, with a way to drop one again. Shown beside output.R
# because that is the file it controls: this list IS the contents of
# output.R, in this order.
# Lives on the whole-set view rather than on one file's tab, because the
# kept plots no longer all go to one file: an exploratory figure is written
# into the model script that computes what it shows, a result figure into
# output.R. Each row says where it will land.
kept_box <- function() tagList(
  h4("Plots kept"),
  span(class = "note",
       "Each 'Keep for script' press adds a figure block to the script the ",
       "plot belongs to. Keeping the same plot twice with different ",
       "settings is deliberate - both blocks are written. Every figure is ",
       "saved into output/ wherever it is drawn from."),
  uiOutput("kept_list"),
  actionButton("kept_clear", "Clear all", class = "btn-xs btn-warning"))

log_ui <- function() {
  fluidPage(fluidRow(
    column(3,
      h4("Write the set"),
      textInput("log_dir", "Folder", "."),
      checkboxInput("log_auto", "Write on every change", FALSE),
      actionButton("log_write_now", "Write all 7 files now",
                   class = "btn-sm btn-primary"),
      span(class = "note",
           "Writes data.R, the four model scripts, output.R and report.R ",
           "into the folder above, ready to run in place."),
      tags$hr(),
      h4("Download"),
      checkboxGroupInput("taf_parts", NULL,
        setNames(names(TAF_FILES), unname(TAF_FILES)),
        selected = names(TAF_FILES)),
      downloadButton("dl_taf_sel", "Download ticked (.zip)",
                     class = "btn-sm btn-primary"),
      downloadButton("dl_taf_all", "Download all (.zip)", class = "btn-sm"),
      tags$hr(),
      downloadButton("dl_log", "Download as one .R file", class = "btn-sm"),
      span(class = "note",
           "The same seven scripts concatenated, for reading in one go."),
      tags$hr(),
      kept_box(),
      tags$hr(),
      h4("Session state"),
      span(class = "note",
           "The scripts are for reading and re-running outside the app. ",
           "The state file is what the app reads back to refill every ",
           "control."),
      downloadButton("dl_state", "Download state (.json)"),
      fileInput("up_state", "Restore state", accept = ".json"),
      uiOutput("state_status")),
    column(9, copy_btn("log_txt"), verbatimTextOutput("log_txt"))))
}

DIMS <- c("Fleet", "Country", "Area", "Season")
# catchCategory is a stratum key in the length/age sections
LEN_DIMS <- c("Catch cat.", DIMS)
# The empty option every role chip carries. It used to be blank, so
# clearing a facet meant selecting a row with nothing in it and hoping -
# the label makes it an option you can aim at, and the CSS below tints it
# so it does not read as the name of a variable.
NONE <- c("-- none --" = "")

# ------------------------------------------------------------
#  Small UI factories
# ------------------------------------------------------------

# Per-tab level-of-detail box, pinned to the bottom of each sidebar.
# Pinned to the bottom-right of the window and highlighted, because it
# silently changes what every other control on the tab means.
level_box <- function(p, fleet = "metier4", area = "ICESDivision") {
  div(class = "lodbox",
      div(class = "lodtitle", "Level of detail"),
      selectInput(paste0(p, "_fleet"), "Fleet", FLEET_LEVELS, fleet, width = "100%"),
      selectInput(paste0(p, "_area"),  "Area",  AREA_LEVELS,  area,  width = "100%"),
      tags$span(class = "note", style = "color:#9a5000",
                "Set per tab. Changing this re-aggregates everything here."))
}

# Plot slot whose container height is set from the server, so tables and
# other plots are pushed down instead of being drawn over.
# A plot slot, optionally with its own two-button toolbar.
#
# "Keep for script" is the answer to a real problem with the emitted script:
# the app can draw the same coverage a dozen ways in a minute, but only the
# last configuration survives into the log, so the version that was actually
# worth having is usually the one that got overwritten. Keeping is explicit
# and additive - press it on each cut you want and all of them end up in
# output.R, in the order you kept them.
#
# "Save image" is the other half: the picture itself, at print resolution,
# without going through the script at all.
#
# capture = FALSE for the diagnostic plots (the rivers, the step views),
# which illustrate a decision rather than reporting a result and have no
# business in output.R.
# The toolbar is pinned to the top-right CORNER of the plot area rather
# than stacked above it. A bar in the flow pushed every plot down by its own
# height and put a strip of chrome between the legend and the thing it
# describes; in the corner it costs no vertical space and sits over the
# plot's own margin, which is empty in every one of these panels.
plot_slot <- function(id, capture = FALSE)
  div(class = if (isTRUE(capture)) "plotwrap has-tools" else "plotwrap",
      if (isTRUE(capture)) plot_tools(id),
      uiOutput(paste0(id, "_ui")))

# The "which route owns the data" banner. Shiny binds one output id once,
# so each place that shows it needs its own id; the server fills them all
# from the same renderer.
LOAD_OWNER_SLOTS <- 1:3
load_owner_ui <- function(k) uiOutput(paste0("load_owner_", k))

# Apply gate for a plot panel.
#
# Every control on these panels is reactive, so dragging a slider or walking
# a dropdown fires a redraw per step - on a stock with a few hundred
# thousand catch rows that is several seconds of work per keystroke, all of
# it thrown away. The panel therefore draws from a FROZEN set of settings,
# and this button is what refreshes them.
#
# The plot still redraws by itself when the DATA changes, because that is
# not a control change and making the user press a button to see their own
# newly loaded file would be obtuse.
apply_bar <- function(p, label = "Apply") div(class = "applybar",
  actionButton(paste0(p, "_apply"), label, class = "btn btn-sm btn-apply"),
  uiOutput(paste0(p, "_apply_note"), inline = TRUE))

plot_tools <- function(id) div(class = "plottools",
  # title= rather than a note beside them: the explanation was only ever
  # read once, and in the corner there is no room for a sentence
  tags$span(title = paste("Adds this plot, with its current settings, to the",
                          "R script. Several cuts of the same plot can be",
                          "kept - each becomes its own figure block."),
    actionButton(paste0(id, "_keep"), "Keep for script",
                 class = "btn btn-xs btn-keep")),
  tags$span(title = "Save this plot as a PNG at print resolution.",
    downloadButton(paste0(id, "_png"), "Save image",
                   class = "btn btn-xs btn-img")))
tbl_slot  <- function(id) div(class = "dtwrap", DTOutput(id))

# Colored role "chips" that are themselves the variable selectors: each is
# a compact dropdown tinted by role. Laid out in a row by default, or
# stacked vertically (stacked=TRUE) when they live in the narrow sidebar.
# Every chip carries the shared NONE option so a role can be left empty
# without having to clear the box by hand.
ROLE_COL <- c(y = "#59A14F", x = "#59A14F", fill = "#F28E2B",
              facet = "#E15759", shape = "#B07AA1", colour = "#F28E2B")
role_chips <- function(p, roles, defaults,
                       choices = c(NONE, setNames(DIMS, DIMS)),
                       stacked = FALSE) {
  div(class = if (stacked) "rolechips rolechips-stacked" else "rolechips",
    lapply(seq_along(roles), function(i) {
      rk <- names(roles)[i]
      col <- ROLE_COL[[rk]] %||% "#777"
      div(class = "rolechip-wrap",
        tags$label(class = "rolechip-lab",
                   style = sprintf("background:%s", col), roles[[i]]),
        selectInput(paste0(p, "_", rk), NULL, choices, defaults[i],
                    width = if (stacked) "100%" else "130px"))
    }))
}

# ============================================================
#  UI
# ============================================================
ui <- navbarPage(
  "RCEF Workbench", id = "nav",
  header = tags$head(tags$style(HTML("
    .well{padding:10px} .form-group{margin-bottom:6px}
    .note{color:#666;font-size:11px;display:block;margin:3px 0 6px 0}
    h4{margin-top:6px;font-size:15px}
    .btn-sm{margin:2px 2px 6px 0}
    .chain{background:#fcfcfd;border:1px solid #e3e3e8;border-radius:6px;
           padding:6px;font-size:12px;margin:6px 0}
    .clausebox{background:#fff;border:1px solid #ddd;border-radius:6px;
               padding:6px;min-height:52px;font-family:monospace;font-size:11px;
               margin-bottom:6px}
    /* plots get their height from renderUI, so nothing can overlap */
    .plotwrap{margin-bottom:26px;clear:both;overflow:hidden}
    .shiny-plot-output{margin-bottom:10px}
    .dtwrap{margin-top:18px;margin-bottom:30px;clear:both}
    /* level-of-detail panel, pinned bottom right */
    .lodbox{position:fixed;bottom:14px;right:14px;z-index:1030;width:250px;
            background:#fff6e5;border:2px solid #F28E2B;border-radius:9px;
            padding:9px 11px;box-shadow:0 3px 12px rgba(0,0,0,.22)}
    .lodbox .form-group{margin-bottom:5px}
    .lodtitle{color:#9a5000;font-weight:700;font-size:12px;
              text-transform:uppercase;letter-spacing:.4px}
    .container-fluid{padding-bottom:190px}
    /* --- top bar: keep it to its natural height (no tall blue gap) --- */
    .navbar{margin-bottom:0!important;position:sticky;top:0;z-index:1040;
            min-height:46px;box-shadow:0 1px 4px rgba(0,0,0,.12)}
    .navbar-default{background:#12324f;border-color:#0d2740}
    .navbar .container-fluid{min-height:46px;padding-bottom:0}
    .navbar-header{min-height:46px}
    .navbar-default .navbar-brand{color:#fff;font-weight:700;letter-spacing:.3px;
            height:46px;padding-top:13px}
    .navbar-default .navbar-nav>li>a{color:#cfe0ee;padding-top:13px;
            padding-bottom:13px}
    .navbar-default .navbar-nav>.active>a,
    .navbar-default .navbar-nav>.active>a:hover{background:#1d4b73;color:#fff}
    /* the tab-pane wrapper must not add its own blank height */
    .navbar+.container-fluid{padding-top:0}
    .tab-content>.tab-pane{padding-top:0}

    /* navbarPage nests the tab content as
         .container-fluid > .tab-content > .tab-pane > .tabbable > .nav-tabs
       for the 2nd level, and one .tabbable deeper for the 3rd. Pin every
       nav-tabs bar sticky; the offset grows with depth so they stack
       directly under the top bar and each other. */
    ul.nav-tabs{position:sticky;z-index:1030;margin:0;
                border-bottom:1px solid #b5c9db}

    /* 2nd level: directly under the 46px top bar, mid-blue */
    .container-fluid>.tab-content>.tab-pane>.tabbable>ul.nav-tabs{
            top:46px;z-index:1036;background:#1d4b73;padding:0 8px;
            border-bottom:2px solid #12324f}
    .container-fluid>.tab-content>.tab-pane>.tabbable>ul.nav-tabs>li>a{
            color:#cfe0ee;font-size:13px;padding:8px 14px;border:none;
            border-radius:0;margin:0}
    .container-fluid>.tab-content>.tab-pane>.tabbable>ul.nav-tabs>li>a:hover{
            background:#2a5c88;border:none}
    .container-fluid>.tab-content>.tab-pane>.tabbable>ul.nav-tabs>li.active>a,
    .container-fluid>.tab-content>.tab-pane>.tabbable>ul.nav-tabs>li.active>a:hover{
            background:#f2f5f8;color:#12324f;font-weight:700;border:none}

    /* 3rd level: under the 2nd (46+37), lighter blue */
    .tab-content>.tab-pane>.tabbable .tab-content>.tab-pane>.tabbable>ul.nav-tabs{
            top:83px;z-index:1032;background:#dbe6f0;padding:2px 10px 0 10px;
            border-bottom:1px solid #b5c9db}
    .tab-content>.tab-pane>.tabbable .tab-content>.tab-pane>.tabbable>ul.nav-tabs>li>a{
            color:#39536b;font-size:12.5px;padding:5px 12px;border-radius:0}
    .tab-content>.tab-pane>.tabbable .tab-content>.tab-pane>.tabbable>ul.nav-tabs>li.active>a{
            font-weight:700;color:#12324f;background:#f2f5f8}

    /* 4th level (e.g. inside cef_result_ui): under the 3rd (83+34) */
    .tab-content>.tab-pane>.tabbable .tab-content>.tab-pane>.tabbable
      .tab-content>.tab-pane>.tabbable>ul.nav-tabs{
            top:116px;z-index:1028;background:#eef3f8;padding:2px 10px 0 10px}
    .tab-content{padding-top:8px}
    .busy-spinner{width:38px;height:38px;margin:0 auto;border:4px solid #dbe6f0;
                  border-top-color:#12324f;border-radius:50%;
                  animation:busyspin 0.8s linear infinite}
    @keyframes busyspin{to{transform:rotate(360deg)}}
    /* plot-type switcher */
    .picker{display:flex;gap:8px;margin:2px 0 8px 0;flex-wrap:wrap}
    .pick{border:2px solid #d3dae1;border-radius:8px;padding:5px;cursor:pointer;
          background:#fff;text-align:center;width:74px}
    .pick:hover{border-color:#7fa8c9}
    .pick.on{border-color:#12324f;background:#eaf1f7;box-shadow:0 1px 3px rgba(0,0,0,.15)}
    .pick div{font-size:10px;color:#39536b;margin-top:2px}
    .pick.disabled{opacity:0.32;cursor:not-allowed;pointer-events:none}
    .rolechips{display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;
               margin:2px 0 6px 0}
    .rolechips-stacked{flex-direction:column;align-items:stretch;gap:7px}
    .rolechip-wrap{display:flex;flex-direction:column}
    .rolechip-lab{font-size:10px;font-weight:700;color:#fff;text-transform:uppercase;
                  letter-spacing:.3px;border-radius:5px 5px 0 0;padding:2px 8px;
                  margin:0}
    .rolechip-wrap .form-group{margin-bottom:0}
    .rolechip-wrap .selectize-input,.rolechip-wrap select{border-radius:0 0 5px 5px;
                  border-top:none;min-height:30px}
    /* the top strip that holds only the extracted legend */
    .legend-strip{border-bottom:1px solid #e2e8ee;margin-bottom:8px;
                  padding-bottom:4px;min-height:80px}
    /* the apply gate under each panel's controls */
    .applybar{display:flex;align-items:center;gap:9px;margin:10px 0 2px 0;
              padding:7px 8px;background:#eef3f8;border:1px solid #cfd8e0;
              border-radius:7px}
    .applybar .btn-apply{background:#12324f;border-color:#12324f;color:#fff;
                         font-weight:700;min-width:78px}
    .applybar .btn-apply:hover{background:#1d4b73;border-color:#1d4b73}
    .applybar.stale{background:#fff4e0;border-color:#e0a458}
    .applystale{font-size:10.5px;color:#9a5000;font-weight:600;line-height:1.25}
    .applyok{font-size:10.5px;color:#5b7186;line-height:1.25}
    /* per-plot toolbar, floated into the plot's own top-right margin so it
       costs no vertical space and never sits between legend and plot */
    .plotwrap.has-tools{position:relative}
    .plottools{position:absolute;top:2px;right:2px;z-index:5;
               display:flex;align-items:center;gap:5px;
               padding:3px 5px;background:rgba(255,255,255,.92);
               border:1px solid #e2e8ee;border-radius:6px;
               opacity:.55;transition:opacity .12s}
    .plotwrap.has-tools:hover .plottools{opacity:1}
    .plottools:hover{opacity:1}
    .plottools .btn{font-size:11px;padding:2px 9px;border-radius:5px;
                    font-weight:600}
    .plottools .btn-keep{background:#12324f;border-color:#12324f;color:#fff}
    .plottools .btn-keep:hover{background:#1d4b73;border-color:#1d4b73}
    .plottools .btn-img{background:#fff;border:1px solid #59A14F;color:#2f6b2a}
    .plottools .btn-img:hover{background:#eef6ef}
    /* the none row in every variable picker: tinted and italic, so it
       reads as an instruction rather than as a variable of that name.
       Two selectors because shiny renders selectInput through selectize
       (a div list) but falls back to a plain <select> when selectize is
       off, and the two share no markup. */
    .selectize-dropdown [data-value=''],
    .selectize-dropdown-content .option[data-value='']{
      color:#9a5000 !important;font-style:italic;font-weight:600;
      background:#fff6e5 !important;border-bottom:1px solid #f0d9b5}
    .selectize-dropdown [data-value=''].active{background:#ffe9c7 !important}
    .selectize-input .item[data-value='']{color:#9a5000;font-style:italic}
    select option[value='']{color:#9a5000;font-style:italic;background:#fff6e5}
    .plottools .note{font-size:10.5px}
    /* the TAF script viewer */
    .tafhead{background:#eef3f8;border-left:4px solid #12324f;
             padding:7px 11px;margin-bottom:8px;border-radius:0 6px 6px 0}
    .taffile{font-family:monospace;font-weight:700;color:#12324f;font-size:13px}
    .keptrow{display:flex;align-items:center;gap:8px;font-size:11.5px;
             border-left:4px solid #59A14F;background:#fff;border-radius:4px;
             padding:4px 7px;margin:4px 0}
    .keptrow .ttl{font-weight:600;color:#12324f}
    .keptrow .sub{color:#666;font-size:10.5px}
    .hier-key-row{align-items:center;margin-bottom:2px}
    .hier-key-fixed{background:#eef3f8;border:1px solid #cfd8e0;border-radius:6px;
                    padding:6px 9px;font-size:12px;color:#12324f}
    .allocbox{position:fixed;top:96px;right:14px;z-index:1030;width:236px;
              background:#eef6ef;border:2px solid #59A14F;border-radius:9px;
              padding:8px 10px;box-shadow:0 3px 12px rgba(0,0,0,.18);
              max-height:210px;overflow:auto}
    .alloctitle{color:#245c2a;font-weight:700;font-size:11px;
                text-transform:uppercase;letter-spacing:.4px}
    .dragchip{cursor:grab;background:#12324f;color:#fff;border-radius:14px;
              padding:5px 12px;font-family:monospace;font-size:11px;
              display:inline-block;max-width:100%;overflow:hidden;
              text-overflow:ellipsis;white-space:nowrap;
              box-shadow:0 1px 3px rgba(0,0,0,.25)}
    .dragchip.empty{background:#c9ccd1;cursor:default}
    .dropzone{border:2px dashed #b8c4cf;border-radius:6px;padding:8px;
              min-height:46px;background:#fff;font-family:monospace;
              font-size:11px;transition:.12s}
    .dropzone.over{border-color:#12324f;background:#eaf1f7}
    .varchip{display:inline-block;background:#eef2f6;border:1px solid #cfd8e0;
             border-radius:12px;padding:2px 9px;margin:2px;font-size:11px;
             color:#39536b;cursor:pointer}
    .varchip.on{background:#12324f;color:#fff;border-color:#12324f}
    .condbox{border:2px solid #9bb7d4;border-radius:8px;padding:8px;
             margin-bottom:6px;background:#f6f9fc}
    .condtitle{font-weight:700;font-size:12px;color:#2c5578;margin-bottom:4px}
    .rulerow{display:flex;align-items:center;gap:6px;padding:4px 6px;
             margin-bottom:4px;border-radius:6px;border:1px solid #ddd;
             background:#fff;font-size:12px}
    .rulechip{width:34px;text-align:center;border-radius:5px;color:#fff;
              font-weight:700;padding:2px 0}
    .rulebtn{border:1px solid #bbb;background:#f4f4f4;border-radius:4px;
             cursor:pointer;font-size:11px;padding:1px 6px}
  ")),
  tags$script(HTML(
    "// A picker only sent its value on click, so on first load every
     // conditionalPanel keyed on one was hidden and the section looked
     // empty. This publishes each picker's initial .on choice as soon as
     // it exists, and again whenever new pickers arrive with a panel.
     function pickInit(){
       document.querySelectorAll('.picker').forEach(function(p){
         var id = p.getAttribute('data-pick-id');
         if (!id) return;
         var on = p.querySelector('.pick.on') || p.querySelector('.pick');
         if (!on) return;
         var v = on.getAttribute('data-val');
         if (v != null) Shiny.setInputValue(id, v);
       });
     }
     $(document).on('shiny:connected', function(){ setTimeout(pickInit, 0); });
     $(document).on('shiny:value shiny:visualchange', function(){
       setTimeout(pickInit, 0); });
     function pickOn(el){var p=el.closest('.picker');if(!p)return;
     p.querySelectorAll('.pick').forEach(function(x){x.classList.remove('on');});
     el.classList.add('on');}")),

  # a "clear this screen" button, always visible top-right of the bar
  tags$div(style = "position:fixed;top:7px;right:14px;z-index:1050",
    actionButton("clear_screen", "Clear this screen", icon = icon("eraser"),
                 class = "btn-sm",
                 style = "background:#2a5c88;color:#fff;border:1px solid #12324f")),

  # a centred busy overlay shown while an action runs, to stop double-clicks
  tags$div(id = "busy_overlay",
    style = "display:none;position:fixed;inset:0;z-index:3000;
             background:rgba(18,50,79,0.28);",
    tags$div(style = "position:absolute;top:50%;left:50%;
                      transform:translate(-50%,-50%);background:#fff;
                      border-radius:10px;padding:20px 30px;
                      box-shadow:0 6px 26px rgba(0,0,0,.3);text-align:center",
      tags$div(class = "busy-spinner"),
      tags$div(id = "busy_msg", style = "margin-top:10px;color:#12324f;
                                         font-weight:600", "Working..."))),
  # A floating preview of whatever stratum the pointer is over in an
  # exclusion list. The SVGs are sent once and cached client-side, so the
  # hover is instant and costs no round-trip.
  tags$div(id = "strat_tip",
    style = "display:none;position:fixed;z-index:4000;pointer-events:none;
             box-shadow:0 4px 16px rgba(0,0,0,.28);border-radius:6px"),
  tags$script(HTML(
    "var STRAT_SVG = {};
     Shiny.addCustomMessageHandler('stratSvg', function(m){ STRAT_SVG = m.map || {}; });
     (function(){
       var tip = null;
       function key(el){
         var t = (el.textContent || '').trim();
         var i = t.indexOf('   (');
         return i > 0 ? t.slice(0, i) : t;
       }
       document.addEventListener('mouseover', function(e){
         var o = e.target.closest('.selectize-dropdown-content .option, .item');
         if (!o) return;
         var k = key(o), svg = STRAT_SVG[k];
         if (!svg) return;
         tip = document.getElementById('strat_tip');
         tip.innerHTML = svg; tip.style.display = 'block';
       });
       document.addEventListener('mousemove', function(e){
         if (!tip || tip.style.display === 'none') return;
         tip.style.left = Math.min(e.clientX + 16, window.innerWidth - 240) + 'px';
         tip.style.top  = Math.min(e.clientY + 16, window.innerHeight - 110) + 'px';
       });
       document.addEventListener('mouseout', function(e){
         if (!e.target.closest('.selectize-dropdown-content .option, .item')) return;
         if (tip) tip.style.display = 'none';
       });
     })();")),
  tags$script(HTML(
    "Shiny.addCustomMessageHandler('busy', function(m){
       document.getElementById('busy_msg').innerText = m.msg || 'Working...';
       document.getElementById('busy_overlay').style.display =
         m.show ? 'block' : 'none';
     });"))),  # closes tags$head

  # =========================================================
  tabPanel("1. Load data",
    div(style = "padding:8px 4px",
      pick_bar("src", list(srcic = "InterCatch files",
                           srccef = "CEF files",
                           srcdb = "CEF database call"), "srcic"),
      span(class = "note",
           "Choose the method to be used to import the data into the App. ",
           "Only one route can own the data at a time - switching route ",
           "replaces what is loaded, and everything built on it."),
      load_owner_ui(1),
      tags$hr(),

      # --- InterCatch: exchange or output, then the three steps ---
      conditionalPanel("input.src == 'srcic'",
        pick_bar("ic_source", list(icexch = "IC exchange",
                                   icout = "IC output"), "icexch"),
        uiOutput("ic_source_note"),
        tags$hr(),
        pick_bar("ic_step", list(stepin = "Input", stepout = "Output CEF",
                                 stepres = "Result"), "stepin"),
        tags$hr(),
        conditionalPanel("input.ic_step == 'stepin'",  ic_load_ui()),
        conditionalPanel("input.ic_step == 'stepout'", ic_output_ui()),
        conditionalPanel("input.ic_step == 'stepres'", cef_result_ui("ic"))),

      # --- CEF: load, then result ---
      conditionalPanel("input.src == 'srccef'",
        span(class = "note",
             "Load the CEF files directly. These can be the result of the ",
             "conversion of InterCatch files from the previous section, or ",
             "CEF files downloaded from the CEF database. If the latter, we ",
             "recommend extracting the data directly from the database using ",
             "the next option (CEF database call)."),
        pick_bar("cef_step", list(stepin = "Load", stepres = "Result"),
                 "stepin"),
        tags$hr(),
        conditionalPanel("input.cef_step == 'stepin'",  cef_load_ui()),
        conditionalPanel("input.cef_step == 'stepres'", cef_result_ui("cef"))),

      # --- CEF database call: credentials -> request -> result ---
      conditionalPanel("input.src == 'srcdb'",
        span(class = "note",
             "Pull the CEF tables straight from the CEF database. Enter your ",
             "credentials, describe the request, and download - the result ",
             "joins the same pipeline as the other two sources."),
        pick_bar("db_step", list(dbcred = "Credentials", dbreq = "Request",
                                 stepres = "Result"), "dbcred"),
        tags$hr(),
        conditionalPanel("input.db_step == 'dbcred'", db_cred_ui()),
        conditionalPanel("input.db_step == 'dbreq'",  db_request_ui()),
        conditionalPanel("input.db_step == 'stepres'", cef_result_ui("db"))))),

  # =========================================================
  tabPanel("2. Discards",
    div(style = "padding:8px 4px",
      pick_bar("sec3", list(stgexpl = "Data exploration",
                            stggrp = "Allocation groups",
                            stgraise = "Raise groups"), "stgexpl"),
      tags$hr(),

      conditionalPanel("input.sec3 == 'stgexpl'",
        pick_bar("sec3a", list(stgexpl = "Sampling coverage",
                               stgdr = "Discard rates"), "stgexpl"),
        tags$hr(),
        conditionalPanel("input.sec3a == 'stgexpl'", coverage_ui()),
        conditionalPanel("input.sec3a == 'stgdr'", drates_ui())),

      conditionalPanel("input.sec3 == 'stggrp'",
        div(style = "padding:8px 4px",
          pick_bar("grp_method",
                   list(ladder = "Hierarchical", manual = "Manual groups"),
                   "ladder"),
          conditionalPanel("input.grp_method != 'manual'", 
          sidebarLayout(
            sidebarPanel(width = 3,
              h4("1. Select hierarchical method"),
              span(class = "note",
                   "The donor pool is widened one key at a time. Each step ",
                   "keeps the keys above it and releases the one below, so a ",
                   "pool is always a relaxation of the one before it."),
              div(class = "chain", style = "font-size:11.5px;line-height:1.45",
                tags$b("How this works"), tags$br(),
                "You list keys from broadest to narrowest. The search then runs the ",
                "other way round, from the narrowest donor pool to the widest:",
                "A stratum starts as narrowly as possible and the donor pool is ",
                "widened one step at a time until it holds enough sampling. The ",
                "first pool that clears its threshold wins, so every stratum ends ",
                "up with the narrowest pool that is well enough sampled.", tags$br(),
                tags$b("Widen one key at a time"), " with keys Fleet, Country, ",
                "Area, Season: first the stratum on its own; then same gear, ",
                "country and area pooled across all seasons; then same gear and ",
                "country pooled across all areas and seasons; then same gear ",
                "pooled across all countries, areas and seasons; and finally ALL, ",
                "which pools every stratum regardless of gear.", tags$br(),
                tags$br(),
                tags$b("Why only this one:"), " using each key on its own was ",
                "removed. It builds pools that ignore the keys above them - ",
                "raising a Belgian TBB stratum from every Belgian stratum ",
                "regardless of gear - which is not a defensible donor."),
              tags$hr(),
              h4("2. Select keys to group"),
              span(class = "note",
                   "Key 1 is always the stratum's own data. Keys 2 onward ",
                   "widen the donor pool one dimension at a time."),
              div(class = "chain", style = "font-size:11.5px;line-height:1.45",
                tags$b("The threshold beside each key"), tags$br(),
                "is the share of that pool's landings weight that must carry a ",
                "discard estimate before the pool is accepted. Set it high and ",
                "a stratum has to look further for a well-sampled donor; set it ",
                "low and it settles for a thinly sampled one nearby. The ",
                "cascade stops at the first pool that clears its own threshold."),
              fluidRow(column(7, numericInput("thr_all", "Set all thresholds to",
                                              50, 0, 100, 5)),
                       column(5, br(), actionButton("apply_all", "Apply",
                                                    class = "btn-sm btn-primary"))),
              uiOutput("hier_keys"),
              uiOutput("hier_chain"),
              tags$hr(), h4("3. Exclude donors"),
              span(class = "note",
                   "Strata whose own discard rate falls outside this range stay in ",
                   "the diagnosis but never feed a donor pool. Applies to every ",
                   "step of the cascade."),
              uiOutput("ar_dr_ui"),
              tags$hr(),
              span(class = "note",
                   "Drop specific stratum/strata out of the donor group based ",
                   "on expert judgement."),
              radioButtons("ar_excl_sort", "Order the list by",
                           c("Landings" = "landings",
                             "Discard rate" = "rate"), "landings",
                           inline = TRUE),
              uiOutput("ar_excl_ui"),
              uiOutput("ar_excl_note"),
              h4("Currently excluded", style = "font-size:13px;margin-top:8px"),
              span(class = "note",
                   "From both routes together - named strata and anything ",
                   "outside the rate window - so it is clear why each one is ",
                   "out of the pool."),
              tbl_slot("ar_excl_tbl"),
              tags$hr(),
              h4("4. Save scenario"),
              textInput("auto_name", "Scenario name", "auto_1"),
              actionButton("save_auto", "Save as scenario", class = "btn-success btn-sm"),
              level_box("ar"), alloc_box()),
            mainPanel(width = 9,
              h4("Decision process"),
              uiOutput("tree_check"),
              uiOutput("tree_ui"),
              tbl_slot("tree_tbl"),
              tags$hr(),
              h4("Diagnosis with recommended raising strata"), tbl_slot("diag_tbl"),
              tags$hr(), h4("Groups"), tbl_slot("grp_tbl"),
                    tags$hr(), h4("Which strata are raised from where"),
              selectInput("river_left", "Left-hand grouping", DIMS, "Fleet"),
              plot_slot("auto_river")))),
          conditionalPanel("input.grp_method == 'manual'", 
          sidebarLayout(
            sidebarPanel(width = 4,
              h4("1. Group"),
              fluidRow(column(5, textInput("rule_id", "Id", "G1")),
                       column(7, textInput("rule_label", "Label", ""))),

              h4("2. Build a clause"),
              span(class = "note", "A clause is one or more variable restrictions ",
                   "combined with AND. Add them one at a time."),
              div(tags$b("Variable", style = "font-size:12px")),
        uiOutput("clause_var_chips"),
              selectizeInput("clause_vals", "Values", NULL, multiple = TRUE),
              checkboxInput("clause_neg", "Negate (NOT in)", FALSE),
              actionButton("add_clause", "Add to clause", class = "btn-sm btn-primary"),
              actionButton("clear_clause", "Clear clause", class = "btn-sm"),
              uiOutput("clause_chip"),

              tags$hr(),
              h4("3. Exclude donors"),
              span(class = "note",
                   "Both of these narrow matchedDataCond only - never the ",
                   "strata being raised. Same controls as the hierarchical ",
                   "tab, so the two read the same way."),
              checkboxInput("dr_on", "Exclude on discard rate", FALSE),
              conditionalPanel("input.dr_on == true", uiOutput("rule_dr_ui")),
              span(class = "note",
                   "Drop specific stratum/strata out of the donor group based ",
                   "on expert judgement."),
              radioButtons("mg_excl_sort", "Order the list by",
                           c("Landings" = "landings",
                             "Discard rate" = "rate"), "landings",
                           inline = TRUE),
              uiOutput("mg_excl_ui"),
              uiOutput("mg_excl_note"),
              h4("Currently excluded", style = "font-size:13px;margin-top:8px"),
              span(class = "note",
                   "Applies to THIS group's donor pool only. The stratum stays ",
                   "available to later groups and to the catch-all."),
              tbl_slot("mg_excl_tbl"),

              tags$hr(),
              h4("4. Assign the clause"),
              # side by side: the two conditions are read against each
              # other far more often than in sequence
              div(style = "display:flex;gap:8px;align-items:stretch",
                div(style = "flex:1",
                  div(class = "condbox",
                      div(class = "condtitle", "strataCond"),
                      span(class = "note", "strata to be raised"),
                      dropzone("strata"),
                      actionButton("to_strata", "Put clause here",
                                   class = "btn-sm btn-info"))),
                div(style = "flex:0 0 42px;display:flex;flex-direction:column;
                             justify-content:center;gap:4px",
                  actionButton("mirror", HTML("&rarr;"),
                               class = "btn-sm btn-warning",
                               title = "copy to matchedDataCond"),
                  actionButton("mirror_back", HTML("&larr;"),
                               class = "btn-sm btn-warning",
                               title = "copy back to strataCond")),
                div(style = "flex:1",
                  div(class = "condbox",
                      div(class = "condtitle", "matchedDataCond"),
                      span(class = "note", "data used to raise"),
                      dropzone("matched"),
                      actionButton("to_matched", "Put clause here",
                                   class = "btn-sm btn-info")))),

              actionButton("save_rule", "5. Save group", class = "btn-success"),
              tags$hr(),

              h4("6. Catch-all group"),
              span(class = "note",
                   "Adds a final group with no clause. Its strataCond is the ",
                   "COMPLEMENT of everything above it, so it raises only the ",
                   "strata no earlier rule claimed - a stratum is never raised ",
                   "twice. Its matchedDataCond is every stratum, including ",
                   "those already used by earlier groups: a donor can be ",
                   "reused, only a raised stratum cannot. Put it last."),
              sliderInput("catchall_dr", "Catch-all discard rate", 0, 1, c(0, 1), 0.01),
              checkboxInput("catchall_keep_excl",
                            "Also apply the exclusions above to the catch-all",
                            FALSE),
              span(class = "note",
                   "Off by default: a stratum kept out of one group's donor ",
                   "pool is usually still wanted as a last resort. Tick it to ",
                   "keep it out of the catch-all too."),
              actionButton("add_catchall", "Add catch-all", class = "btn-sm"),
              tags$hr(),

              h4("7. Order"),
              span(class = "note",
                   "Evaluated top to bottom; first match wins. A stratum is ",
                   "raised by exactly one rule - the first that claims it - ",
                   "so the emitted strataCond of each rule is its clause ",
                   "minus everything above. Donor pools are the opposite: ",
                   "they may overlap freely, so one stratum can feed several ",
                   "groups."),
              uiOutput("rule_order"),
              tags$hr(),
              h4("8. Save scenario"),
              textInput("man_name", "Scenario name", "manual_1"),
              actionButton("save_manual", "Save as scenario", class = "btn-success btn-sm"),
              level_box("mg"), alloc_box()),
            mainPanel(width = 8,
              h4("strataCond / matchedDataCond"),
              span(class = "note",
                   "The two lists as they would be written in a script - ",
                   "paste them straight into the raising call. strataCond ",
                   "carries the complements that make the rules a partition; ",
                   "matchedDataCond does not, because donors are reusable."),
              verbatimTextOutput("man_conds"),

              tags$hr(),
              h4("What each rule actually raises"),
              span(class = "note",
                   "Read top to bottom, the way the rules are evaluated. ",
                   "Each card shows what its rule TAKES - after the rules ",
                   "above it have taken theirs - and the running total of ",
                   "the stock resolved so far. The river beside it shows ",
                   "which strata those are and where they are raised from."),
              uiOutput("man_check"),
              uiOutput("man_ladder"),

              tags$hr(),
              h4("Groups"), tbl_slot("rules_tbl"),
              h4("Strata"), tbl_slot("rules_strata_tbl"),
              tags$hr(), h4("Overview: raised vs donated per group"), tbl_slot("man_ov"),
                    tags$hr(), h4("Which strata are raised from where"),
              plot_slot("man_river")))))),

      conditionalPanel("input.sec3 == 'stgraise'",
        div(style = "padding:8px 4px",
          pick_bar("raise_mode",
                   list(compare = "Compare allocations", final = "Final raising"),
                   "compare"),
          conditionalPanel("input.raise_mode != 'final'", 
          sidebarLayout(
            sidebarPanel(width = 3,
              h4("Comparison plot"),
              # Fleet by default rather than (none): with no X axis the panel
              # opened blank and looked broken, when the commonest first
              # question - how do the allocations differ by fleet - is
              # exactly what it should have been showing.
              role_chips("cmp", c(x = "X axis", facet = "Facet"),
                         c("Fleet", ""), stacked = TRUE),
              span(class = "note",
                   "Pick the keys the allocations share; leave Facet on ",
                   "(none) for a single panel."),
              apply_bar("cmp"),
              tags$hr(),
              h4("Saved group allocations"),
              span(class = "note",
                   "Allocations live in this session only. Download writes a ",
                   ".json to your browser's download folder; load it back next ",
                   "year to reuse the setup."),
              downloadButton("dl_sc", "Download (.json)", class = "btn-sm"),
              fileInput("up_sc", "Load (.json)", accept = ".json"),
              selectInput("del_sc_id", "Remove", choices = character(0)),
              actionButton("del_sc", "Remove", class = "btn-sm btn-danger")),
            mainPanel(width = 9,
              tbl_slot("sc_tbl"),
              uiOutput("cmp_note"),
              div(class = "legend-strip", plotOutput("cmp_legend", height = "110px")),
              plot_slot("cmp_plot", capture = TRUE),
              h4("Discards by allocation"),
              span(class = "note", "Imported = already in the data. The remaining ",
                   "columns are the estimated total after raising, one per allocation."),
              tbl_slot("cmp_tbl")))),
          conditionalPanel("input.raise_mode == 'final'", final_ui()))))),

  # =========================================================
  tabPanel("3. Length",
    div(style = "padding:8px 4px",
      pick_bar("sec4", list(stgexpl = "Exploration",
                            stggrp = "Allocation groups",
                            stgraise = "Raising"), "stgexpl"),
      tags$hr(),
      conditionalPanel("input.sec4 == 'stgexpl'",
        pick_bar("sec4x", list(stgexpl = "Sampling coverage",
                               lengthvar = "Numbers at length",
                               weightvar = "Mean weight at length"), "stgexpl"),
        tags$hr(),
        conditionalPanel("input.sec4x == 'stgexpl'", len_coverage_ui("len")),
        conditionalPanel("input.sec4x == 'lengthvar'", len_numbers_ui("len")),
        conditionalPanel("input.sec4x == 'weightvar'", len_meanw_ui("len"))),
      conditionalPanel("input.sec4 == 'stggrp'", len_alloc_ui("len")),
      conditionalPanel("input.sec4 == 'stgraise'",
                       len_raise_ui("len", "Length")))),

  # =========================================================
  tabPanel("4. Age",
    div(style = "padding:8px 4px",
      pick_bar("sec5", list(stgexpl = "Exploration",
                            stggrp = "Allocation groups",
                            stgraise = "Raising"), "stgexpl"),
      tags$hr(),
      conditionalPanel("input.sec5 == 'stgexpl'",
        pick_bar("sec5x", list(stgexpl = "Sampling coverage",
                               agevar = "Numbers at age",
                               ageweightvar = "Mean weight at age"), "stgexpl"),
        tags$hr(),
        conditionalPanel("input.sec5x == 'stgexpl'", len_coverage_ui("age")),
        conditionalPanel("input.sec5x == 'agevar'", len_numbers_ui("age")),
        conditionalPanel("input.sec5x == 'ageweightvar'", len_meanw_ui("age"))),
      conditionalPanel("input.sec5 == 'stggrp'", len_alloc_ui("age")),
      conditionalPanel("input.sec5 == 'stgraise'",
                       len_raise_ui("age", "Age")))),

  # =========================================================
  # The script is written in ICES TAF shape: read -> model -> present.
  # The model stage is four files rather than one because the discard
  # raising and the length/age allocation are separate decisions taken at
  # separate times, and in each case the exploration that justifies a
  # grouping is worth keeping apart from the grouping itself.
  tabPanel("5. R script",
    tabsetPanel(id = "sec6",
      tabPanel("Live script (full)", log_ui()),
      tabPanel("data", taf_ui("data")),
      tabPanel("model",
        tabsetPanel(id = "sec6m",
          tabPanel(TAF_LABEL[["model_explore_discards"]],
                   taf_ui("model_explore_discards")),
          tabPanel(TAF_LABEL[["model_allocate_raise_discards"]],
                   taf_ui("model_allocate_raise_discards")),
          tabPanel(TAF_LABEL[["model_explore_length_age"]],
                   taf_ui("model_explore_length_age")),
          tabPanel(TAF_LABEL[["model_allocate_length_age"]],
                   taf_ui("model_allocate_length_age")))),
      tabPanel("output", taf_ui("output")),
      tabPanel("report", taf_ui("report")),
      tabPanel("Fragments", fragments_ui())))
)

startup_modal <- function() modalDialog(
  title = NULL, size = "l", easyClose = FALSE, fade = TRUE,
  footer = tagList(actionButton("start_go", "Start", class = "btn-success")),
  div(style = "text-align:center;margin-bottom:10px",
      h3(style = "margin:0;color:#12324f", "RCEF Workbench"),
      div(class = "note",
          "Sampling coverage, group allocation and raising for ICES ",
          "catch data. Set the run up here; the answers decide which ",
          "tabs open and which files are asked for.")),
  fluidRow(
    column(6,
      h4("Stock"),
      textInput("cfg_stock", "Stock code", "", placeholder = "bll.27.3a47de"),
      textInput("cfg_coord", "Stock coordinator", "", placeholder = "name"),
      numericInput("cfg_year", "Year", as.integer(format(Sys.Date(), "%Y")) - 1,
                   1990, 2100, 1),
      h4("Where the input files are"),
      dir_picker("cfg_dir", "."),
      span(class = "note",
           "Type a path, or click the folder to browse. It is checked as ",
           "soon as you start.")),
    column(6,
      h4("Starting point"),
      radioButtons("cfg_entry", NULL,
        c("InterCatch exchange format (HI / SI / SD)" = "ic_exchange",
          "InterCatch output format (StockOverview / Numbers / MeanWeigth)" = "ic_output",
          "CEF files already prepared" = "cef")),
      span(class = "note",
           "Only the matching loader stays enabled; the others are ",
           "locked so two routes cannot be mixed by accident."),
      tags$hr(),
      h4("What has to be raised or allocated"),
      checkboxInput("cfg_disc", "Discards", TRUE),
      span(class = "note", "Always required."),
      checkboxInput("cfg_len", "Lengths", FALSE),
      checkboxInput("cfg_age", "Ages", FALSE),
      span(class = "note",
           "Leaving lengths and ages off means no distribution file is ",
           "asked for, and those sections stay closed."))))

server <- function(input, output, session) {

  showModal(startup_modal())

  # show/hide the centred busy overlay. with_busy() wraps a slow action so
  # the overlay is guaranteed to come down even if the action errors.
  set_busy <- function(show, msg = "Working...")
    session$sendCustomMessage("busy", list(show = show, msg = msg))
  with_busy <- function(msg, expr) {
    set_busy(TRUE, msg); on.exit(set_busy(FALSE))
    force(expr)
  }

  cfg <- reactiveValues(done = FALSE, stock = "", coord = "", year = NA,
                        dir = ".", entry = "cef",
                        need = c("discards"))

  observeEvent(input$start_go, {
    cfg$done <- TRUE
    cfg$stock <- input$cfg_stock %||% ""
    cfg$coord <- input$cfg_coord %||% ""
    cfg$year  <- input$cfg_year
    cfg$dir   <- input$cfg_dir %||% "."
    cfg$entry <- input$cfg_entry %||% "cef"
    cfg$need  <- c("discards",
                   if (isTRUE(input$cfg_len)) "lengths",
                   if (isTRUE(input$cfg_age)) "ages")
    # lock the routes that were not chosen
    if (cfg$entry != "cef") {
      updateRadioButtons(session, "ic_source",
        selected = if (cfg$entry == "ic_exchange") "exchange" else "output")
      updateTextInput(session, "ic_path", value = cfg$dir)
    }
    # prefix from stock and year, as asked
    updateTextInput(session, "ic_prefix",
      value = if (nzchar(cfg$stock) && !is.na(cfg$year))
        paste0(gsub("[^A-Za-z0-9]", "_", cfg$stock), "_", cfg$year, "_") else "")
    for (sec in c("4. Length", "5. Age")) {
      want <- (sec == "4. Length" && "lengths" %in% cfg$need) ||
              (sec == "5. Age"    && "ages"    %in% cfg$need)
      if (want) showTab("nav", sec) else hideTab("nav", sec)
    }
    if (cfg$entry == "cef") hideTab("nav", "1. From InterCatch")
    showNotification(sprintf("Set up for %s (%s)",
                             if (nzchar(cfg$stock)) cfg$stock else "unnamed stock",
                             paste(cfg$need, collapse = ", ")),
                     duration = 5)
    removeModal() })

  output$cfg_banner <- renderUI({
    if (!cfg$done) return(NULL)
    div(class = "note", style = "font-size:12px;color:#12324f",
        sprintf("%s | %s | %s | raising: %s",
                if (nzchar(cfg$stock)) cfg$stock else "unnamed",
                if (nzchar(cfg$coord)) cfg$coord else "no coordinator",
                cfg$dir, paste(cfg$need, collapse = ", "))) })

  # Clear the work on the CURRENT section without touching the rest. Which
  # state that is depends on which top-level tab is open.
  observeEvent(input$clear_screen, {
    sec <- input$nav %||% ""
    showModal(modalDialog(
      title = "Clear this screen?",
      sprintf("This resets the work on '%s' only. Everything on the other sections stays.", sec),
      footer = tagList(modalButton("Cancel"),
                       actionButton("clear_confirm", "Clear", class = "btn-danger")),
      easyClose = TRUE, size = "s")) })

  observeEvent(input$clear_confirm, {
    sec <- input$nav %||% ""
    if (grepl("InterCatch|Load from IC", sec)) {
      rv$ic <- NULL
    } else if (grepl("Load from CEF", sec)) {
      rv$cef_catches <- NULL; rv$dist <- NULL; rv$eff <- NULL
    } else if (grepl("Discards", sec)) {
      rv$rules <- list(); rv$clause <- list(); rv$pend_raise <- NULL
      rv$pend_source <- NULL; rv$scenarios <- list(); rv$native <- NULL
      rv$final <- NULL
    }
    removeModal()
    showNotification(sprintf("Cleared '%s'", sec), duration = 3) })

  # files the chosen route needs, and whether they are there
  REQ_FILES <- list(
    ic_exchange = c("HI", "SI", "SD"),
    ic_output   = c("StockOverview", "NumbersAtAgeLength", "MeanWeigthAtAgeLength"),
    cef         = c("catches", "distributions", "effort"))

  file_check <- reactive({
    d <- if (isTruthy(input$ic_path)) input$ic_path else cfg$dir
    pat <- REQ_FILES[[cfg$entry]]
    fs <- if (dir.exists(d)) list.files(d, recursive = TRUE) else character(0)
    need <- pat
    # distributions / age-length files are only needed if asked for
    if (cfg$entry == "cef" && !any(c("lengths","ages") %in% cfg$need))
      need <- setdiff(need, "distributions")
    if (cfg$entry == "ic_output" && !any(c("lengths","ages") %in% cfg$need))
      need <- setdiff(need, c("NumbersAtAgeLength", "MeanWeigthAtAgeLength"))
    data.frame(file = pat,
               required = pat %in% need,
               found = vapply(pat, function(k)
                 any(grepl(k, fs, ignore.case = TRUE)), logical(1)),
               stringsAsFactors = FALSE) })


  rv <- reactiveValues(sets = list(), rules = list(), clause = list(),
                       pend_raise = NULL, pend_source = NULL, scenarios = list(),
                       ic = NULL, native = NULL, log = log_new(),
                       dist = NULL, eff = NULL, final = NULL, restore = NULL,
                       cef_catches = NULL, len_allocs = list(), len_raised = NULL, len_raised_err = NULL,
                       len_raised_runs = NULL, age_raised_runs = NULL,
                       age_raised_err = NULL,
                       age_allocs = list(), age_raised = NULL,
                       len_clause = list(), len_groups = list(),
                       len_alloc_pend = NULL, len_match_pend = NULL,
                       len_alloc = NULL,
                       age_clause = list(), age_groups = list(),
                       age_alloc_pend = NULL, age_match_pend = NULL,
                       age_alloc = NULL,
                       # plots the user explicitly kept, in the order kept;
                       # this list IS the body of output.R. kept_seq only
                       # ever increases, so a record's uid stays valid after
                       # something above it is removed.
                       kept = list(), kept_seq = 0,
                       # which of the four input routes owns the data, the
                       # files it read, and a counter that ticks whenever
                       # the data underneath everything is replaced
                       load_method = NULL, cef_files = NULL, data_version = 0)

  # =========================================================
  #  One input route at a time
  # =========================================================
  # The four routes - InterCatch exchange, InterCatch output, CEF files,
  # the RDBES database - all end up filling the same slots. Letting two of
  # them fill those slots at once produces a catch table whose provenance
  # nobody can state, and an emitted data.R that would have to claim two
  # origins for one object. So a route takes ownership, and taking it from
  # another route is a deliberate, confirmed replacement.
  data_loaded <- reactive(
    !is.null(rv$ic) || !is.null(rv$cef_catches) ||
    !is.null(rv$dist) || !is.null(rv$eff))

  # Everything downstream is derived from the catch table, so replacing the
  # table invalidates all of it. Leaving a raising or an allocation behind
  # after the data changed under it is the worst kind of stale: it looks
  # like a result.
  clear_all_data <- function() {
    rv$ic <- NULL; rv$cef_catches <- NULL; rv$dist <- NULL; rv$eff <- NULL
    rv$cef_files <- NULL
    rv$native <- NULL; rv$final <- NULL
    rv$scenarios <- list(); rv$rules <- list(); rv$clause <- list()
    rv$len_allocs <- list(); rv$age_allocs <- list()
    rv$len_raised <- NULL; rv$age_raised <- NULL
    rv$len_raised_runs <- NULL; rv$age_raised_runs <- NULL
    rv$len_groups <- list(); rv$age_groups <- list()
  }

  pending_load <- reactiveVal(NULL)

  # Run `action` under this route, asking first if another route owns the
  # data. `action` is a function so the confirm path can run exactly the
  # same code the direct path would have run.
  with_load_guard <- function(method, action) {
    cur <- rv$load_method
    if (is.null(cur) || identical(cur, method) || !isTRUE(data_loaded())) {
      rv$load_method <- method
      rv$data_version <- rv$data_version + 1
      return(action())
    }
    pending_load(list(method = method, action = action))
    showModal(modalDialog(
      title = "Replace the data already loaded?",
      div(class = "chain", style = "color:#7a1f1f;line-height:1.55",
          tags$b("This stock is already loaded from another route."), tags$br(),
          sprintf("Loaded from: %s", TAF_METHOD_LABEL[[cur]] %||% cur), tags$br(),
          sprintf("About to load: %s", TAF_METHOD_LABEL[[method]] %||% method)),
      tags$hr(),
      div(class = "note", style = "line-height:1.55",
          "Only one route can own the data at a time. Continuing will ",
          "discard the catch, distribution and effort tables loaded so far, ",
          tags$b("and everything built on them"), " - saved group ",
          "allocations, raisings, and length and age allocations. The ",
          "emitted data.R will then describe the new route only."),
      footer = tagList(
        modalButton("Cancel"),
        actionButton("load_replace_ok", "Replace everything",
                     class = "btn-danger")),
      easyClose = TRUE, size = "m"))
  }

  observeEvent(input$load_replace_ok, {
    p <- pending_load(); removeModal(); req(!is.null(p))
    clear_all_data()
    rv$load_method <- p$method
    rv$data_version <- rv$data_version + 1
    pending_load(NULL)
    p$action()
    showNotification(sprintf("Replaced. Data now comes from %s.",
                             TAF_METHOD_LABEL[[p$method]] %||% p$method),
                     type = "warning", duration = 7) })

  # A banner on every load tab, so the owning route is visible before a
  # click rather than only in the dialog that interrupts it.
  load_owner_note <- reactive({
    if (!isTRUE(data_loaded()) || is.null(rv$load_method))
      return(div(class = "note", "No data loaded yet."))
    div(class = "chain", style = "color:#14532d",
        sprintf("Data is loaded from: %s.",
                TAF_METHOD_LABEL[[rv$load_method]] %||% rv$load_method),
        tags$br(),
        tags$span(style = "color:#9a5000",
          "Loading from a different route will replace it and everything ",
          "built on it.")) })
  for (.k in LOAD_OWNER_SLOTS) local({
    k <- .k
    output[[paste0("load_owner_", k)]] <- renderUI(load_owner_note()) })

  # =========================================================
  #  Apply gates
  # =========================================================
  # `sig` is a reactive returning the panel's current control settings as a
  # plain list. `gate_of()` returns the settings the panel should DRAW from,
  # which lag the live ones until Apply is pressed.
  #
  # Three things refresh them:
  #   * the Apply button - the point of the exercise;
  #   * the first time a usable signature exists, so the panel is not blank
  #     on arrival (an Apply button that hides the plot until pressed reads
  #     as a broken tab, not as a feature);
  #   * new data, which is not a control change and must land unasked.
  # `live` is the settings that BYPASS the gate. Switching plot type is one:
  # picking Bubbles instead of Heatmap asks to see a different picture of the
  # same thing, and making that wait for a second click is the opposite of
  # what the gate is for. The gate exists to stop a half-configured redraw
  # firing on every keystroke of a CONFIGURATION - axes, thresholds, level of
  # detail - not to slow down a toggle.
  gate_of <- function(p, sig, refresh = NULL, live = NULL) {
    applied <- reactiveVal(NULL)
    observe({ if (is.null(applied())) applied(sig()) })
    observeEvent(input[[paste0(p, "_apply")]], applied(sig()), ignoreInit = TRUE)
    observeEvent(rv$data_version, applied(sig()), ignoreInit = TRUE)
    # a result the panel exists to show (a raising, an allocation) is not a
    # control either; producing one must show it
    if (!is.null(refresh))
      observeEvent(refresh(), applied(sig()), ignoreInit = TRUE)
    # A live setting must also refresh the frozen ones, or the two drift:
    # switch to Bubbles after editing an axis and you would get the new type
    # drawn with the old axis - a configuration nobody chose.
    if (!is.null(live)) observeEvent(live(), applied(sig()), ignoreInit = TRUE)

    stale <- reactive(!is.null(applied()) && !identical(applied(), sig()))
    # Without this the button is a mystery: nothing on screen says whether
    # what you are looking at reflects the controls beside it.
    output[[paste0(p, "_apply_note")]] <- renderUI(
      if (isTRUE(stale()))
        div(class = "applystale", "Settings changed", tags$br(),
            "press Apply to redraw")
      else div(class = "applyok", "Up to date"))

    list(now = applied, stale = stale)
  }

  # Build a reactive that recomputes only when its gate opens.
  #
  # The body is evaluated inside isolate(), so it can go on reading
  # input$... and the panel's own helpers exactly as before - no rewrite of
  # every builder to thread a settings list through it. The values it reads
  # are the ones live at the moment the gate opened, which is precisely the
  # moment Apply was pressed.
  # `live` is read OUTSIDE the isolate, so the reactive re-runs when it
  # changes; everything else is read inside and therefore frozen.
  gated <- function(g, expr, live = NULL) {
    e <- substitute(expr); env <- parent.frame()
    reactive({ g$now(); if (!is.null(live)) live(); isolate(eval(e, env)) })
  }

  # =========================================================
  #  Keeping a plot for the script, and saving it as an image
  # =========================================================
  # Registering a plot here does two things: wires its "Keep for script"
  # button to append the CURRENT configuration to rv$kept, and wires its
  # "Save image" button to a download of the plot as drawn.
  #
  # `call` and `prep` are functions rather than values because they have to
  # be read at the moment the button is pressed - that is the whole point.
  # Evaluating them at registration time would freeze whatever the controls
  # happened to say when the app started.
  # `section` says which TAF script the plot is written into. Exploratory
  # figures belong beside the analysis that produced them, not in a distant
  # output.R - so a coverage plot lands in model_explore_discards.R and a
  # result plot in output.R. Every one of them is still SAVED to output/.
  keep_plot <- function(id, obj, title, note = NULL, call = NULL, prep = NULL,
                        section = "output", gate = NULL, w = 10, h = 7) {
    val <- function(x, fallback = NULL)
      tryCatch(if (is.function(x)) x() else x, error = function(e) fallback)

    observeEvent(input[[paste0(id, "_keep")]], {
      # `call` and `title` read the controls live, but the plot on screen was
      # drawn from the settings the last Apply froze. With the panel stale
      # those two disagree, and keeping would write a block that does not
      # reproduce the picture the user is looking at - the one failure this
      # whole feature exists to prevent.
      if (!is.null(gate) && isTRUE(gate$stale())) {
        showNotification(
          paste("Press Apply first. The plot on screen was drawn from the",
                "previous settings, so keeping now would record something",
                "you cannot see."),
          type = "warning", duration = 7)
        return()
      }
      cl <- val(call)
      if (!length(cl)) {
        showNotification(
          "Nothing to keep yet - the plot has to be drawn first.",
          type = "warning", duration = 4)
        return()
      }
      ttl <- val(title, id)
      rv$kept_seq <- rv$kept_seq + 1
      rv$kept <- c(rv$kept, list(list(
        uid = rv$kept_seq, section = section,
        id = id, title = ttl, note = val(note), prep = val(prep), call = cl,
        stamp = format(Sys.time(), "%H:%M:%S"))))
      showNotification(
        sprintf("Kept '%s'. output.R now has %s plot%s.", ttl,
                length(rv$kept), if (length(rv$kept) == 1) "" else "s"),
        type = "message", duration = 4)
    }, ignoreInit = TRUE)

    output[[paste0(id, "_png")]] <- downloadHandler(
      filename = function()
        sprintf("%s_%s.png", taf_slug(val(title, id)),
                format(Sys.time(), "%Y%m%d_%H%M%S")),
      content = function(f) {
        p <- tryCatch(obj(), error = function(e) NULL)
        if (is.null(p)) {
          # a broken download is worse than an honest one: write a legible
          # placeholder rather than letting the handler error out
          grDevices::png(f, 1000, 700, res = 110)
          on.exit(grDevices::dev.off(), add = TRUE)
          graphics::plot.new()
          graphics::text(0.5, 0.5, "Nothing to save - the plot is not drawn.")
          return()
        }
        ggplot2::ggsave(f, p, width = w, height = h, dpi = 300, bg = "white")
      })
  }

  # =========================================================
  #  SECTION 4 - Length sampling
  #  catchCategory is a stratum key here, not a tab, so the same
  #  three views cover landings and discards together or apart.
  # =========================================================
  len_dim_col <- function(p, label) {
    if (is.null(label) || !nzchar(label)) return(NULL)
    if (label == "Catch cat.") return("catchCategory")
    unname(dmap(paste0(p, "_lv"))[label])
  }

  length_server <- function(p, type = "LengthTotal") {
    what_word <- if (identical(type, "Age")) "age" else "length"
    thr_cov  <- reactive(input[[paste0(p, "_thr_cov")]] %||% 50)
    thr_meas <- reactive(input[[paste0(p, "_thr_meas")]] %||% 0)
    dims_of <- function()
      unique(c("catchCategory", unname(dmap(paste0(p, "_lv"))[DIMS])))

    dist_tbl <- reactive({
      if (!is.null(rv$dist)) rv$dist
      else if (!is.null(rv$ic$distributions)) as.data.frame(rv$ic$distributions)
      else NULL })

    # the category icons return catlan / catdis; one is always chosen
    cc_of <- function(view) {
      v <- input[[paste0(p, "_", view, "_cc")]] %||% "catlan"
      if (identical(v, "catdis")) "Dis" else "Lan" }
    cc_word <- function(view)
      if (identical(cc_of(view), "Dis")) "discards" else "landings"

    linked_for <- function(view) {
      d <- tryCatch(dat(), error = function(e) NULL)
      req(!is.null(d), !is.null(dist_tbl()))
      link_dist_to_strata(d, dist_tbl(), dims_of(), cc_of(view), type) }

    blink_for <- function(view) {
      d <- tryCatch(dat(), error = function(e) NULL)
      req(!is.null(d))
      biology_link(d, dist_tbl(), dims_of(), cc_of(view), type) }

    rc <- function(view, role) len_dim_col(p, input[[paste0(p, "_", view, "_r_", role)]])

    # One gate per view. The biology builders are the most expensive things
    # in the app - biology_link() and stratum_measurements() both walk the
    # whole distributions table - so an ungated dropdown here costs seconds
    # per step, and the level-of-detail box re-aggregates everything.
    i_ <- function(x) input[[paste0(p, "_", x)]]
    lv_sig <- function() list(i_("lv_fleet"), i_("lv_area"))
    # the plot TYPE is deliberately absent from both signatures - switching
    # heatmap/bubbles/bars, or histogram/density, is a different view of the
    # same configuration and should be immediate
    cov_sig <- reactive(c(list(i_("cov_cc"), i_("thr_cov"),
                               i_("thr_meas"), i_("cov_r_y"), i_("cov_r_fill"),
                               i_("cov_r_facet")), lv_sig()))
    cov_live <- reactive(i_("cov_type"))
    n_sig <- reactive(c(list(i_("n_cc"), i_("n_r_fill"),
                             i_("n_r_facet"), i_("n_r_shape"), i_("n_stack"),
                             i_("n_smooth"), i_("n_freex"), i_("n_freey")),
                        lv_sig()))
    n_live <- reactive(i_("n_type"))
    w_sig <- reactive(c(list(i_("w_cc"), i_("w_r_fill"), i_("w_r_facet"),
                             i_("w_r_shape"), i_("w_pt"), i_("w_points"),
                             i_("w_freex"), i_("w_freey")), lv_sig()))
    dist_ref <- reactive(rv$dist)
    cov_gate <- gate_of(paste0(p, "_cov"), cov_sig, refresh = dist_ref,
                        live = cov_live)
    n_gate   <- gate_of(paste0(p, "_n"),   n_sig,   refresh = dist_ref,
                        live = n_live)
    w_gate   <- gate_of(paste0(p, "_w"),   w_sig,   refresh = dist_ref)

    # ---- shared status + summary --------------------------------
    output[[paste0(p, "_status")]] <- renderUI({
      if (is.null(dist_tbl()))
        return(div(class = "chain", style = "color:#7a1f1f",
                   sprintf("No distributions table loaded - %s work needs it.",
                           what_word)))
      bl <- tryCatch(blink_for("cov"), error = function(e) NULL)
      if (is.null(bl) || !nrow(bl))
        return(div(class = "note",
                   sprintf("No %s rows in the catch table.", cc_word("cov"))))
      lk <- tryCatch(linked_for("cov"), error = function(e) NULL)
      un <- distribution_units(dist_tbl(), type)
      sc <- tryCatch(length_scale_check(lk), error = function(e) NULL)
      tagList(
        div(class = "chain", style = "color:#14532d",
            sprintf("%s: %s of %s strata have %s data (%s%% of the %s weight). Shown in %s.",
                    tools::toTitleCase(cc_word("cov")),
                    sum(bl$sampled), nrow(bl), what_word,
                    round(sum(bl$weight_measured) / sum(bl$weight) * 100, 1),
                    cc_word("cov"),
                    if (identical(type, "Age")) "years and g" else "cm and g")),
        if (!is.null(un) && isTRUE(un$mixed))
          div(class = "chain", style = "color:#9a5000",
              sprintf("The file mixes units (%s); all rows were converted before plotting.",
                      paste(c(un$class, un$weight), collapse = ", "))) else NULL,
        if (sum(bl$n_dangling, na.rm = TRUE) > 0)
          div(class = "chain", style = "color:#9a5000",
              sprintf("%s catch row(s) carry a domainBiology that matches nothing in the distributions table.",
                      format(sum(bl$n_dangling), big.mark = ","))) else NULL,
        {
          orph <- tryCatch(dist_without_catch(
                             tryCatch(dat(), error = function(e) NULL),
                             dist_tbl(), cc_of("cov"), type),
                           error = function(e) NULL)
          if (!is.null(orph) && nrow(orph))
            div(class = "chain", style = "color:#7a1f1f",
                sprintf(paste("%s %s distribution domain(s) have no matching",
                              "catch row (no catch carries that domainBiology).",
                              "The catch and biology files disagree - check the",
                              "submitted data."),
                        nrow(orph), what_word)) else NULL
        },
        {
          m2 <- tryCatch(stratum_measurements(tryCatch(dat(), error = function(e) NULL),
                                              dist_tbl(), dims_of(), cc_of("cov"), type),
                         error = function(e) NULL)
          b2 <- tryCatch(add_sufficiency(bl, m2, thr_cov(), thr_meas()),
                         error = function(e) NULL)
          w <- if (!is.null(b2)) measurement_warning(b2, thr_meas()) else NULL
          if (!is.null(w)) div(class = "chain", style = "color:#9a5000", w) else NULL
        },
        if (!is.null(sc) && !isTRUE(sc$plausible))
          div(class = "chain", style = "color:#7a1f1f",
              sprintf(paste("Length scale looks wrong: fitting weight against",
                            "length gives an exponent of %.2f but a coefficient",
                            "of %.2g, about %.0fx off. The class column may be",
                            "on a finer scale than its unit says - check it",
                            "before using these numbers."),
                      sc$b, sc$a, sc$implied_factor)) else NULL) })

    output[[paste0(p, "_sum")]] <- renderDT({
      bl <- blink_for("cov")
      validate(need(!is.null(bl) && nrow(bl), "No catch rows."))
      datatable(length_link_summary(bl, linked_for("cov"), type), rownames = FALSE,
                colnames = c("", ""), options = list(dom = "t", scrollX = TRUE)) })

    # ---- view 1: sampling coverage ------------------------------
    cov_obj <- gated(cov_gate, {
      bl <- blink_for("cov")
      validate(need(!is.null(bl) && nrow(bl), "No catch rows."))
      # Re-shape the biology link into the same columns the discard
      # coverage plots expect, then run it through classify_strata so it
      # gets its Status / cat_key exactly like a discard stratum. Here
      # "covered" means a length distribution exists, not a discard one.
      # a stratum is only a usable donor if it clears BOTH thresholds, so
      # the measurement count is joined on and a stratum that is covered
      # but thinly measured is demoted rather than shown as fine
      m <- tryCatch(stratum_measurements(tryCatch(dat(), error = function(e) NULL),
                                         dist_tbl(), dims_of(), cc_of("cov"), type),
                    error = function(e) NULL)
      bl <- add_sufficiency(bl, m, thr_cov(), thr_meas())
      # keep the real coverage and measurement count; a thinly measured
      # stratum is flagged by classify_strata (via min_meas), not demoted
      # to "unsampled" as the old filter did
      sc <- bl %>%
        mutate(landings = weight,
               landings_with_discards = weight_measured,
               discards = 0, discard_rate = NA_real_)
      sc <- classify_strata(sc, thr_cov(), what_word, thr_meas())
      y <- rc("cov", "y"); f <- rc("cov", "fill"); fc <- rc("cov", "facet")
      validate(need(!is.null(y), "Pick a Y axis."))
      wl <- cc_word("cov"); th <- thr_cov()
      plot_biology_coverage(sc, type = input[[paste0(p, "_cov_type")]] %||% "heatmap",
        y = y, fill = f, facet = fc, threshold = th, what = what_word,
        weight_label = wl, min_meas = thr_meas()) },
      live = cov_live)

    # how many rows the plot will actually draw, so the panel grows with them
    n_levels_of <- function(d, v)
      if (!is.null(d) && !is.null(v) && length(v) == 1 && !is.na(v) &&
          nzchar(v) && v %in% names(d))
        length(unique(as.character(d[[v]]))) else 10

    output[[paste0(p, "_cov_plot_ui")]] <- renderUI({
      cov_gate$now(); cov_live()
      bl <- tryCatch(isolate(blink_for("cov")), error = function(e) NULL)
      plotOutput(paste0(p, "_cov_plot"),
        height = paste0(length_plot_height(bl, rc("cov","facet"), NULL,
                                           n_y = n_levels_of(bl, rc("cov","y"))),
                        "px")) })
    output[[paste0(p, "_cov_plot")]] <- renderPlot({
      pl <- cov_obj(); validate(need(!is.null(pl), "Nothing to plot."))
      pl + theme(legend.position = "none") })
    output[[paste0(p, "_cov_legend")]] <- renderPlot({
      pl <- cov_obj(); validate(need(!is.null(pl), "")); draw_legend(pl) },
      bg = "transparent")

    # The biology objects are rebuilt in output.R rather than reloaded,
    # because the level of detail is a plotting choice here: the same saved
    # bio_link can be redrawn at metier4 or metier6 without re-running the
    # model stage. The dims are written out literally so the block stands
    # on its own.
    bio_obj <- function() if (identical(type, "Age")) "bio_age" else "bio_length"
    bio_prep <- function(view, out = "bio_sc") c(
      sprintf("dims_biology <- %s", fmt_vals(dims_of())),
      sprintf('bl <- biology_link(catch_for_biology, distributions, dims_biology, %s, "%s")',
              taf_q(cc_of(view)), type),
      sprintf('ms <- stratum_measurements(catch_for_biology, distributions, dims_biology, %s, "%s")',
              taf_q(cc_of(view)), type),
      sprintf("bl <- add_sufficiency(bl, ms, %s, %s)", thr_cov(), thr_meas()),
      "## reshaped into the columns classify_strata() expects, so a biology",
      "## stratum is classified by exactly the same code as a discard one",
      sprintf("%s <- bl %%>%% mutate(landings = weight,", out),
      "        landings_with_discards = weight_measured,",
      "        discards = 0, discard_rate = NA_real_)",
      sprintf('%s <- classify_strata(%s, %s, "%s", %s)',
              out, out, thr_cov(), what_word, thr_meas()))

    keep_plot(paste0(p, "_cov_plot"), cov_obj, gate = cov_gate,
      section = "model_explore_length_age",
      title = function() sprintf("%s coverage - %s, %s",
        tools::toTitleCase(what_word),
        input[[paste0(p, "_cov_type")]] %||% "heatmap", cc_word("cov")),
      note = function() sprintf(
        "%s at %s coverage / %s measurements; fleet = %s, area = %s",
        tools::toTitleCase(cc_word("cov")), paste0(thr_cov(), "%"),
        thr_meas(), unname(dmap(paste0(p, "_lv"))["Fleet"]),
        unname(dmap(paste0(p, "_lv"))["Area"])),
      prep = function() bio_prep("cov"),
      call = function() taf_call("plot_biology_coverage", list(
        "bio_sc",
        type = taf_q(input[[paste0(p, "_cov_type")]] %||% "heatmap"),
        y = taf_q(rc("cov", "y")), fill = taf_q(rc("cov", "fill")),
        facet = taf_q(rc("cov", "facet")), threshold = thr_cov(),
        what = taf_q(what_word), weight_label = taf_q(cc_word("cov")),
        min_meas = thr_meas())))

    # ---- view 2: numbers at length ------------------------------
    num_data <- reactive({
      lk <- linked_for("n")
      validate(need(!is.null(lk) && nrow(lk), "No length distributions."))
      gv <- unique(na.omit(c(rc("n","fill"), rc("n","facet"), rc("n","shape"))))
      length_numbers(lk, gv) })
    num_obj <- gated(n_gate, {
      d <- num_data()
      validate(need(!is.null(d) && nrow(d), "No numbers-at-length rows."))
      plot_biology_distribution(d, quantity = "numbers",
        type = if (identical(input[[paste0(p, "_n_type")]], "ridge"))
                 "density" else "histogram",
        fill = rc("n","fill"), facet1 = rc("n","facet"), facet2 = rc("n","shape"),
        stacked = isTRUE(input[[paste0(p, "_n_stack")]]),
        smooth = input[[paste0(p, "_n_smooth")]] %||% 1,
        scales = facet_scales(isTRUE(input[[paste0(p, "_n_freex")]]),
                              isTRUE(input[[paste0(p, "_n_freey")]])),
        class_label = class_axis_label(type)) },
      live = n_live)
    output[[paste0(p, "_n_plot_ui")]] <- renderUI({
      n_gate$now(); n_live()
      d <- tryCatch(isolate(num_data()), error = function(e) NULL)
      plotOutput(paste0(p, "_n_plot"),
        height = paste0(length_plot_height(d, rc("n","facet"), rc("n","shape"),
                          n_y = if (identical(input[[paste0(p, "_n_type")]], "ridge"))
                                  n_levels_of(d, rc("n","fill")) else 10),
                        "px")) })
    output[[paste0(p, "_n_plot")]] <- renderPlot({
      pl <- num_obj(); validate(need(!is.null(pl), "Nothing to plot."))
      pl + theme(legend.position = "none") })
    output[[paste0(p, "_n_legend")]] <- renderPlot({
      pl <- num_obj(); validate(need(!is.null(pl), "")); draw_legend(pl) },
      bg = "transparent")

    keep_plot(paste0(p, "_n_plot"), num_obj, gate = n_gate,
      section = "model_explore_length_age",
      title = function() sprintf("Numbers at %s - %s", what_word,
        if (identical(input[[paste0(p, "_n_type")]], "ridge")) "density"
        else "histogram"),
      note = function() sprintf("%s, grouped by %s", cc_word("n"),
        paste(na.omit(c(rc("n","fill"), rc("n","facet"), rc("n","shape"))),
              collapse = ", ")),
      prep = function() c(
        sprintf("dims_biology <- %s", fmt_vals(dims_of())),
        sprintf('linked <- link_dist_to_strata(catch_for_biology, distributions, dims_biology, %s, "%s")',
                taf_q(cc_of("n")), type),
        sprintf("d_num <- length_numbers(linked, %s)",
                fmt_vals(unique(na.omit(c(rc("n","fill"), rc("n","facet"),
                                          rc("n","shape"))))))),
      call = function() taf_call("plot_biology_distribution", list(
        "d_num", quantity = '"numbers"',
        type = if (identical(input[[paste0(p, "_n_type")]], "ridge"))
                 '"density"' else '"histogram"',
        fill = taf_q(rc("n","fill")), facet1 = taf_q(rc("n","facet")),
        facet2 = taf_q(rc("n","shape")),
        stacked = if (isTRUE(input[[paste0(p, "_n_stack")]])) "TRUE" else "FALSE",
        smooth = input[[paste0(p, "_n_smooth")]] %||% 1,
        class_label = taf_q(class_axis_label(type)))))

    # ---- view 3: mean weight at length --------------------------
    mw_data <- reactive({
      lk <- linked_for("w")
      validate(need(!is.null(lk) && nrow(lk), "No length distributions."))
      pt <- len_dim_col(p, input[[paste0(p, "_w_pt")]])
      gv <- unique(na.omit(c(rc("w","fill"), rc("w","facet"), rc("w","shape"), pt)))
      length_meanweight(lk, gv) })
    mw_obj <- gated(w_gate, {
      d <- mw_data()
      validate(need(!is.null(d) && nrow(d), "No mean-weight rows."))
      plot_biology_distribution(d, quantity = "meanweight", type = "line",
        colour = rc("w","fill"), facet1 = rc("w","facet"), facet2 = rc("w","shape"),
        shape = len_dim_col(p, input[[paste0(p, "_w_pt")]]),
        show_points = isTRUE(input[[paste0(p, "_w_points")]]),
        scales = facet_scales(isTRUE(input[[paste0(p, "_w_freex")]]),
                              isTRUE(input[[paste0(p, "_w_freey")]])),
        class_label = class_axis_label(type)) })
    output[[paste0(p, "_w_plot_ui")]] <- renderUI({
      w_gate$now()
      d <- tryCatch(isolate(mw_data()), error = function(e) NULL)
      plotOutput(paste0(p, "_w_plot"),
        height = paste0(length_plot_height(d, rc("w","facet"), rc("w","shape")), "px")) })
    output[[paste0(p, "_w_plot")]] <- renderPlot({
      pl <- mw_obj(); validate(need(!is.null(pl), "Nothing to plot."))
      pl + theme(legend.position = "none") })
    output[[paste0(p, "_w_legend")]] <- renderPlot({
      pl <- mw_obj(); validate(need(!is.null(pl), "")); draw_legend(pl) },
      bg = "transparent")

    keep_plot(paste0(p, "_w_plot"), mw_obj, gate = w_gate,
      section = "model_explore_length_age",
      title = function() sprintf("Mean weight at %s", what_word),
      note = function() sprintf(
        "%s; whatever is not given a role is averaged over, weighted by the numbers measured",
        cc_word("w")),
      prep = function() c(
        sprintf("dims_biology <- %s", fmt_vals(dims_of())),
        sprintf('linked <- link_dist_to_strata(catch_for_biology, distributions, dims_biology, %s, "%s")',
                taf_q(cc_of("w")), type),
        sprintf("d_mw <- length_meanweight(linked, %s)",
                fmt_vals(unique(na.omit(c(rc("w","fill"), rc("w","facet"),
                          rc("w","shape"),
                          len_dim_col(p, input[[paste0(p, "_w_pt")]]))))))),
      call = function() taf_call("plot_biology_distribution", list(
        "d_mw", quantity = '"meanweight"', type = '"line"',
        colour = taf_q(rc("w","fill")), facet1 = taf_q(rc("w","facet")),
        facet2 = taf_q(rc("w","shape")),
        shape = taf_q(len_dim_col(p, input[[paste0(p, "_w_pt")]])),
        show_points = if (isTRUE(input[[paste0(p, "_w_points")]])) "TRUE" else "FALSE",
        class_label = taf_q(class_axis_label(type)))))
  }

  length_server("len", "LengthTotal")
  length_server("age", "Age")

  # ---- allocation groups for length -----------------------------
  length_alloc_server <- function(p, type = "LengthTotal") {
    ns <- function(x) paste0(p, "_ga_", x)
    # each section keeps its own clause and groups
    R <- function(slot) paste0(p, "_", slot)
    getrv <- function(slot) rv[[R(slot)]]
    setrv <- function(slot, v) rv[[R(slot)]] <- v
    keep_cc <- reactive(isTRUE(input[[ns("keepcc")]]))

    # the allocation works on the whole catch table, both categories, so
    # it links without a category filter
    dims_of <- function()
      unique(c("catchCategory", unname(dmap(paste0(p, "_lv"))[DIMS])))
    dist_tbl <- reactive({
      if (!is.null(rv$dist)) rv$dist
      else if (!is.null(rv$ic$distributions)) as.data.frame(rv$ic$distributions)
      else NULL })
    blink_for <- function(...) {
      d <- tryCatch(dat(), error = function(e) NULL)
      req(!is.null(d))
      biology_link(d, dist_tbl(), dims_of(), NULL, type) }

    # the key labels resolved to actual columns
    alloc_cols <- reactive(
      vapply(alloc_keys(), function(k) len_dim_col(p, k), character(1)))

    alloc_keys <- reactive({
      k <- vapply(1:4, function(i) input[[ns(paste0("k", i))]] %||% "",
                  character(1))
      k[nzchar(k)] })

    alloc_thr <- reactive(
      vapply(1:5, function(i) {
        x <- input[[ns(paste0("t", i))]]
        if (is.null(x) || all(is.na(x))) 50 else as.numeric(x)[1] }, numeric(1)))

    # the per-step minimum measurement counts that sit beside the coverage
    # sliders, kept together so the emitted grouping code carries both
    alloc_meas <- reactive(
      vapply(1:5, function(i) {
        x <- input[[ns(paste0("m", i))]]
        if (is.null(x) || all(is.na(x))) 0 else as.numeric(x)[1] }, numeric(1)))

    output[[ns("keys")]] <- renderUI({
      k1 <- fluidRow(class = "hier-key-row",
        column(6, div(class = "hier-key-fixed", tags$b("Key 1"), tags$br(),
                      "Own stratum")),
        column(3, sliderInput(ns("t1"), "% coverage", 0, 100, c(50, 100), 5)),
        column(3, numericInput(ns("m1"), "min meas.", 0, 0, 100000, 10)))
      cc <- fluidRow(class = "hier-key-row",
        column(6, div(class = "hier-key-fixed",
                      style = if (keep_cc()) "border-left:5px solid #59A14F" else
                              "border-left:5px solid #BFBFBF",
                      tags$b("Key 2"), tags$br(), "catchCategory",
                      tags$span(class = "note",
                                if (keep_cc()) "kept to the end" else "droppable"))),
        column(6, tags$span(class = "note",
                            "no threshold - this is the ceiling of the cascade")))
      rows <- lapply(1:4, function(i)
        fluidRow(class = "hier-key-row",
          column(6, selectInput(ns(paste0("k", i)), paste("Key", i + 2),
                                c(NONE, setNames(DIMS, DIMS)),
                                c("Fleet","Country","Season","Area")[i])),
          column(3, sliderInput(ns(paste0("t", i + 1)), "% coverage", 0, 100,
                                c(50, 100), 5)),
          column(3, numericInput(ns(paste0("m", i + 1)), "min meas.", 0,
                                 0, 100000, 10))))
      tagList(k1, cc, tags$hr(style = "margin:6px 0"), rows) })

    steps <- reactive(alloc_steps(alloc_keys(), alloc_thr(), keep_cc()))

    output[[ns("chain")]] <- renderUI({
      st <- steps()
      lab <- vapply(st, `[[`, character(1), "label")
      joined <- vapply(st, function(x) isTRUE(x$drop_cc), logical(1))
      # mark where the ladder restarts with the categories joined
      first_join <- which(joined)[1]
      if (length(first_join) && !is.na(first_join))
        lab[first_join] <- paste0("<b>&#8635; back to full precision:</b> ",
                                  lab[first_join])
      div(class = "chain", tags$b("Order actually tested:"), tags$br(),
          HTML(paste(lab, collapse = " &rarr; "))) })

    # what each rung ACTUALLY resolved, not just what it would test
    output[[ns("steps")]] <- renderDT({
      a <- tryCatch(cascade_assigned(), error = function(e) NULL)
      st <- steps()
      d <- if (is.null(a)) data.frame(
        step = seq_along(st),
        scope = vapply(st, alloc_step_scope, character(1)),
        pool = vapply(st, `[[`, character(1), "label"),
        threshold = vapply(st, function(x)
          if (is.na(x$threshold)) NA_real_ else x$threshold, numeric(1)),
        stringsAsFactors = FALSE)
      else alloc_cascade_table(a, st)
      datatable(d, rownames = FALSE, options = list(dom = "t", scrollX = TRUE)) })

    output[[ns("status")]] <- renderUI({
      st <- steps()
      n_join <- sum(vapply(st, function(x) isTRUE(x$drop_cc), logical(1)))
      div(class = "chain",
        if (keep_cc())
          "catchCategory is kept throughout: landings are only ever allocated from landings, and the widest pool is all other data in the same category."
        else
          sprintf(paste("Once the within-category ladder is exhausted the",
                        "categories are joined and the ladder RESTARTS at full",
                        "precision, widening again over %s further step(s).",
                        "Pooling everything is the last of them, not the first",
                        "thing tried."), n_join)) })

    cascade_assigned <- reactive({
      bl <- blink_for()
      validate(need(!is.null(bl) && nrow(bl), "No catch rows."))
      assign_alloc_cascade(bl, alloc_cols(), steps(), bms_on()) })

    # the strata the cascade never resolved, so a too-strict threshold or
    # a category that must be released is visible rather than inferred
    output[[ns("cmissing")]] <- renderDT({
      a <- cascade_assigned()
      un <- a[is.na(a$alloc_step), , drop = FALSE]
      validate(need(nrow(un), "Every stratum was resolved."))
      keep <- intersect(c(dims_of(), "weight", "coverage", "n_measurements"),
                        names(un))
      d <- un[order(-un$weight), keep, drop = FALSE]
      num <- vapply(d, is.numeric, logical(1))
      d[num] <- lapply(d[num], function(x) round(x, 3))
      datatable(d, rownames = FALSE,
                options = list(scrollX = TRUE, pageLength = 10)) })

    # one river per rung, matching the manual per-rule rivers
    output[[ns("step_rivers")]] <- renderUI({
      a <- tryCatch(cascade_assigned(), error = function(e) NULL)
      st <- steps()
      if (is.null(a)) return(div(class = "note", "No strata yet."))
      tagList(lapply(seq_along(st), function(i) {
        n <- sum(a$alloc_step == i, na.rm = TRUE)
        div(style = "margin-bottom:8px",
            tags$b(sprintf("Step %s - %s - %s stratum/strata", i,
                           st[[i]]$label, n)),
            if (n > 0) plotOutput(ns(paste0("sriver_", i)),
                                  height = paste0(max(200, 60 + n * 24), "px"))
            else div(class = "note", "resolves nothing"))
      })) })

    observe({
      a <- tryCatch(cascade_assigned(), error = function(e) NULL)
      st <- steps()
      if (is.null(a)) return()
      for (i in seq_along(st)) local({
        j <- i
        output[[ns(paste0("sriver_", j))]] <- renderPlot({
          sub <- a[!is.na(a$alloc_step) & a$alloc_step == j, , drop = FALSE]
          validate(need(nrow(sub), "resolves nothing"))
          g <- cascade_to_groups(sub, alloc_cols())
          validate(need(length(g), "nothing to plot"))
          pl <- plot_alloc_river(sub, dims_of(), g, group_palette(names(g)))
          validate(need(!is.null(pl), "Nothing to plot.")); pl })
      }) })

    output[[ns("river_ui")]] <- renderUI(
      plotOutput(ns("river"), height = "620px"))

    output[[ns("river")]] <- renderPlot({
      a <- cascade_assigned()
      g <- cascade_to_groups(a, alloc_cols())
      validate(need(length(g), "Nothing resolved yet."))
      pl <- plot_alloc_river(a, dims_of(), g, group_palette(names(g)))
      validate(need(!is.null(pl), "Nothing to plot.")); pl })

    # saving an allocation: both methods land in the same store, so the
    # raising tab can pick either
    save_alloc <- function(nm, groups, method) {
      req(nzchar(nm), length(groups))
      # getrv/setrv resolve to len_allocs or age_allocs from the module
      # prefix. Writing rv$len_allocs directly would file every Age
      # allocation under Length, leaving age_allocs empty and the Age
      # grouping out of the emitted script.
      a <- getrv("allocs") %||% list()
      a[[nm]] <- list(name = nm, method = method, groups = groups,
                      saved = format(Sys.time(), "%H:%M:%S"),
                      # how the grouping was reached, so the script can
                      # reproduce it rather than only its resolved conditions
                      spec = list(keys = alloc_keys(), thresholds = alloc_thr(),
                                  min_meas = alloc_meas(), keep_cc = keep_cc(),
                                  cols = alloc_cols(), bms = bms_on(),
                                  dims = dims_of()))
      setrv("allocs", a)
      showNotification(sprintf("Allocation '%s' saved (%s groups)", nm,
                               length(groups)), duration = 3) }

    observeEvent(input[[ns("save")]], {
      g <- cascade_to_groups(cascade_assigned(), alloc_cols())
      save_alloc(input[[ns("name")]] %||% "alloc_1", g, "hierarchical") })

    observeEvent(input[[ns("savemanual")]], {
      save_alloc(input[[ns("mname")]] %||% "manual_1",
                 rv$len_groups %||% list(), "manual") })

    # ---- manual groups ------------------------------------------
    bms_on <- reactive(isTRUE(input[[ns("bms")]]))

    output[[ns("bmsnote")]] <- renderUI(
      if (bms_on())
        div(class = "chain", style = "color:#245c2a",
            "BMS is being treated as a discard: a clause naming Dis also matches BMS.")
      else
        div(class = "chain", style = "color:#9a5000",
            "BMS is being kept separate from Dis."))

    output[[ns("vals")]] <- renderUI({
      d <- tryCatch(dat(), error = function(e) NULL)
      col <- len_dim_col(p, input[[ns("var")]])
      validate(need(!is.null(d) && !is.null(col), "Load data first."))
      selectizeInput(ns("v"), NULL, sort(unique(as.character(d[[col]]))),
                     multiple = TRUE) })

    output[[ns("clause")]] <- renderUI({
      cl <- getrv("clause") %||% list()
      div(class = "clausebox",
          if (!length(cl)) "(empty clause)" else alloc_cond_string(cl)) })

    observeEvent(input[[ns("add")]], {
      col <- len_dim_col(p, input[[ns("var")]])
      req(!is.null(col), length(input[[ns("v")]]))
      vals <- input[[ns("v")]]
      if (identical(col, "catchCategory")) vals <- expand_cc(vals, bms_on())
      cl <- getrv("clause") %||% list()
      cl[[col]] <- if (isTRUE(input[[ns("neg")]]))
        structure(vals, negate = TRUE) else vals
      setrv("clause", cl) })

    observeEvent(input[[ns("clear")]], setrv("clause", list()))

    observeEvent(input[[ns("to_alloc")]], {
      req(length(getrv("clause")))
      setrv("alloc_pend", getrv("clause")); setrv("clause", list()) })
    observeEvent(input[[ns("to_matched")]], {
      req(length(getrv("clause")))
      setrv("match_pend", getrv("clause")); setrv("clause", list()) })
    observeEvent(input[[ns("mirror")]], setrv("match_pend", getrv("alloc_pend")))

    output[[ns("alloc_txt")]] <- renderUI(div(class = "clausebox",
      if (is.null(getrv("alloc_pend"))) "(not set - matches every stratum)"
      else alloc_cond_string(getrv("alloc_pend"))))
    output[[ns("matched_txt")]] <- renderUI(div(class = "clausebox",
      if (is.null(getrv("match_pend")))
        "(mirrors allocStrataCond)"
      else alloc_cond_string(getrv("match_pend"))))

    observeEvent(input[[ns("saverule")]], {
      req(nzchar(input[[ns("gid")]] %||% ""))
      a <- getrv("alloc_pend") %||% list()
      m <- getrv("match_pend") %||% a
      g <- getrv("groups") %||% list()
      g[[input[[ns("gid")]]]] <- list(
        label   = input[[ns("glab")]] %||% "",
        alloc   = alloc_cond_string(a),
        matched = alloc_cond_string(m),
        alloc_expr   = alloc_quo(a),
        matched_expr = alloc_quo(m))
      setrv("groups", g)
      setrv("alloc_pend", NULL); setrv("match_pend", NULL)
      updateTextInput(session, ns("gid"),
                      value = paste0("GA", length(g) + 1))
      showNotification(paste("Saved", input[[ns("gid")]]), duration = 2) })

    # reorder / delete: first match wins, so order is meaningful
    output[[ns("order")]] <- renderUI({
      g <- getrv("groups") %||% list()
      if (!length(g)) return(div(class = "note", "No groups yet."))
      pal <- group_palette(names(g))
      tagList(lapply(seq_along(g), function(i) {
        gid <- names(g)[i]
        btn <- function(dir, sym) tags$button(class = "rulebtn", HTML(sym),
          onclick = sprintf(
            "Shiny.setInputValue('%s',{i:%d,dir:'%s'},{priority:'event'})",
            ns("move"), i, dir))
        div(class = "rulerow",
          div(class = "rulechip", style = paste0("background:", pal[[gid]]), gid),
          div(style = "flex:1;overflow:hidden",
              tags$b(if (nzchar(g[[gid]]$label %||% "")) g[[gid]]$label else gid),
              tags$br(),
              tags$span(style = "font-family:monospace;font-size:10px;color:#555",
                        g[[gid]]$alloc)),
          btn("up", "&#9650;"), btn("down", "&#9660;"), btn("del", "&#10005;"))
      })) })

    observeEvent(input[[ns("move")]], {
      g <- getrv("groups"); i <- input[[ns("move")]]$i; d <- input[[ns("move")]]$dir
      if (d == "del") { g[[i]] <- NULL; setrv("groups", g); return(invisible()) }
      j <- if (d == "up") i - 1 else i + 1
      if (j >= 1 && j <= length(g)) {
        o <- seq_along(g); o[c(i, j)] <- o[c(j, i)]
        setrv("groups", g[o]) } })

    man_assigned <- reactive({
      g <- getrv("groups") %||% list()
      validate(need(length(g), "No groups yet."))
      bl <- blink_for("cov")
      validate(need(!is.null(bl) && nrow(bl), "No catch rows."))
      assign_alloc_groups(bl, g, bms_on()) })

    output[[ns("conds")]] <- renderText(
      paste(emit_alloc_conditions(getrv("groups") %||% list()), collapse = "\n"))

    output[[ns("rules")]] <- renderDT({
      g <- getrv("groups") %||% list()
      validate(need(length(g), "No groups yet."))
      d <- alloc_group_table(man_assigned(), g, dims_of())
      validate(need(!is.null(d), "Nothing to summarise."))
      datatable(d, rownames = FALSE, options = list(scrollX = TRUE, dom = "t")) })

    # what each rule claims, and what nothing has claimed yet
    output[[ns("progress")]] <- renderDT({
      g <- getrv("groups") %||% list()
      validate(need(length(g), "No groups yet."))
      d <- manual_progress(man_assigned(), g)
      validate(need(!is.null(d), "Nothing to report."))
      DT::formatStyle(
        datatable(d, rownames = FALSE,
                  options = list(scrollX = TRUE, dom = "t")),
        "group", target = "row",
        backgroundColor = DT::styleEqual("STILL MISSING", "#fdece9")) })

    output[[ns("missing")]] <- renderDT({
      g <- getrv("groups") %||% list()
      validate(need(length(g), "No groups yet."))
      d <- manual_missing(man_assigned(), dims_of())
      validate(need(!is.null(d), "Every stratum is assigned."))
      datatable(d, rownames = FALSE,
                options = list(scrollX = TRUE, pageLength = 10)) })

    # one river per rule, same reading as the automated ladder
    output[[ns("rule_rivers")]] <- renderUI({
      g <- getrv("groups") %||% list()
      if (!length(g)) return(div(class = "note", "No groups yet."))
      a <- tryCatch(man_assigned(), error = function(e) NULL)
      if (is.null(a)) return(div(class = "note", "No strata yet."))
      tagList(lapply(seq_along(g), function(i) {
        gid <- names(g)[i]
        n <- sum(a$alloc_group == gid, na.rm = TRUE)
        div(style = "margin-bottom:8px",
            tags$b(sprintf("%s%s - %s stratum/strata", gid,
                           if (nzchar(fld(g[[gid]], "label", "")))
                             paste0(" (", fld(g[[gid]], "label", ""), ")") else "",
                           n)),
            if (n > 0) plotOutput(ns(paste0("rriver_", i)),
                                  height = paste0(max(200, 60 + n * 24), "px"))
            else div(class = "note", "claims nothing"))
      })) })

    observe({
      g <- getrv("groups") %||% list()
      a <- tryCatch(man_assigned(), error = function(e) NULL)
      if (!length(g) || is.null(a)) return()
      pal <- group_palette(names(g))
      for (i in seq_along(g)) local({
        j <- i; gid <- names(g)[j]
        output[[ns(paste0("rriver_", j))]] <- renderPlot({
          sub <- a[!is.na(a$alloc_group) & a$alloc_group == gid, , drop = FALSE]
          validate(need(nrow(sub), "claims nothing"))
          pl <- plot_alloc_river(sub, dims_of(), g[gid], pal[gid])
          validate(need(!is.null(pl), "Nothing to plot.")); pl })
      }) })

    output[[ns("mriver_ui")]] <- renderUI(
      plotOutput(ns("mriver"), height = "560px"))
    output[[ns("mriver")]] <- renderPlot({
      g <- getrv("groups") %||% list()
      validate(need(length(g), "No groups yet."))
      pl <- plot_alloc_river(man_assigned(), dims_of(), g,
                             group_palette(names(g)))
      validate(need(!is.null(pl), "Nothing to plot.")); pl })
  }
  length_alloc_server("len", "LengthTotal")
  length_alloc_server("age", "Age")

  # ---- raising: run catchAllocationAoL and compare -------------
  length_raise_server <- function(p, app_type = "LengthTotal",
                                  what = "Length", store = "len_allocs",
                                  out = "len_raised") {
    ns <- function(x) paste0(p, "_rz_", x)
    dist_tbl <- reactive({
      if (!is.null(rv$dist)) rv$dist
      else if (!is.null(rv$ic$distributions)) as.data.frame(rv$ic$distributions)
      else NULL })

    observe(updateSelectInput(session, ns("alloc"),
                              choices = names(rv[[store]] %||% list())))

    observeEvent(input[[ns("run")]], {
      nm <- input[[ns("alloc")]]
      a <- (rv[[store]] %||% list())[[nm %||% ""]]
      if (is.null(a)) {
        showNotification("Save an allocation first.", type = "error"); return() }
      # allocation runs on the RAISED catch table when there is one, so
      # length/age work follows the discard raising rather than the import
      cd <- if (!is.null(rv$final)) rv$final
            else if (!is.null(rv$native)) rv$native
            else tryCatch(dat(), error = function(e) NULL)
      if (is.null(cd)) {
        showNotification("No catch data.", type = "error"); return() }
      res <- with_busy(sprintf("Allocating %s...", tolower(what)),
        suppressWarnings(run_allocation(
          cd, dist_tbl(), a$groups, app_type,
          originType_catch = input[[ns("origin")]] %||% "WGEstimate",
          variableType_catch = input[[ns("vartype")]] %||% "WeightLive",
          weighting = input[[ns("weighting")]] %||% "NumberAtAoL",
          log_file = file.path(tempdir(), "alloc_log.txt"))))
      if (inherits(res, "alloc_error")) {
        rv[[out]] <- NULL
        rv[[paste0(out, "_err")]] <- res$message
        showNotification(paste("Allocation failed:", res$message),
                         type = "error", duration = 12)
      } else {
        res$alloc_name <- nm
        rv[[paste0(out, "_err")]] <- NULL
        rv[[out]] <- res
        showNotification(sprintf("Allocated with '%s': %s distribution rows",
                                 nm, format(nrow(res$distribution),
                                            big.mark = ",")), duration = 5)
      } })

    # ---- comparison across saved allocations --------------------
    observeEvent(input[[ns("runall")]], {
      allocs <- rv[[store]] %||% list()
      if (!length(allocs)) {
        showNotification("Save at least one allocation first.",
                         type = "error"); return() }
      cd <- if (!is.null(rv$final)) rv$final
            else if (!is.null(rv$native)) rv$native
            else tryCatch(dat(), error = function(e) NULL)
      if (is.null(cd)) {
        showNotification("No catch data.", type = "error"); return() }
      runs <- with_busy(sprintf("Running %s allocation(s)...", length(allocs)),
        run_allocation_set(allocs, cd, dist_tbl(), app_type,
          originType_catch = input[[ns("origin")]] %||% "WGEstimate",
          variableType_catch = input[[ns("vartype")]] %||% "WeightLive",
          weighting = input[[ns("weighting")]] %||% "NumberAtAoL",
          log_file = file.path(tempdir(), "alloc_cmp.txt")))
      rv[[paste0(out, "_runs")]] <- runs
      bad <- names(runs)[vapply(runs, function(r)
        inherits(r, "alloc_error"), logical(1))]
      showNotification(sprintf("Ran %s allocation(s)%s", length(runs),
        if (length(bad)) paste0("; failed: ", paste(bad, collapse = ", ")) else ""),
        duration = 6, type = if (length(bad)) "warning" else "message") })

    cmp_runs <- reactive(rv[[paste0(out, "_runs")]])

    cmp_data <- reactive({
      r <- cmp_runs(); req(!is.null(r), length(r))
      g <- if (isTruthy(input[[ns("cmpfacet")]])) input[[ns("cmpfacet")]]
           else "catchCategory"
      compare_allocations(r, g) })

    output[[ns("cmpstatus")]] <- renderUI({
      r <- cmp_runs()
      if (is.null(r))
        return(div(class = "note",
                   "Run the saved allocations to compare them."))
      bad <- names(r)[vapply(r, function(x) inherits(x, "alloc_error"),
                             logical(1))]
      tagList(
        div(class = "chain", style = "color:#14532d",
            sprintf("%s allocation(s) run against the current data.",
                    length(r) - length(bad))),
        if (length(bad))
          div(class = "chain", style = "color:#7a1f1f",
              sprintf("Failed: %s", paste(bad, collapse = ", "))) else NULL) })

    output[[ns("cmptot")]] <- renderDT({
      d <- comparison_totals(cmp_data())
      validate(need(!is.null(d), "Nothing to compare."))
      datatable(d, rownames = FALSE, options = list(dom = "t", scrollX = TRUE)) })

    cmp_sig <- reactive(list(input[[ns("cmpval")]], input[[ns("cmpfacet")]]))
    cmp_gate <- gate_of(ns("cmp"), cmp_sig,
                        refresh = reactive(rv[[paste0(p, "_groups")]]))
    cmp_obj <- gated(cmp_gate, {
      d <- cmp_data()
      validate(need(!is.null(d) && nrow(d), "Nothing to compare."))
      plot_allocation_comparison(d, input[[ns("cmpval")]] %||% "numbers",
        if (isTruthy(input[[ns("cmpfacet")]])) input[[ns("cmpfacet")]] else NULL,
        what) })

    output[[ns("cmpplot_ui")]] <- renderUI(
      plotOutput(ns("cmpplot"), height = "460px"))
    output[[ns("cmpplot")]] <- renderPlot({
      pl <- cmp_obj(); validate(need(!is.null(pl), ""))
      pl + theme(legend.position = "none") })
    output[[ns("cmplegend")]] <- renderPlot({
      pl <- cmp_obj(); validate(need(!is.null(pl), "")); draw_legend(pl) },
      bg = "transparent")

    grp <- reactive(if (isTruthy(input[[ns("group")]]))
                      input[[ns("group")]] else character(0))
    agg_args <- reactive(list(
      minAoL = input[[ns("minaol")]] %||% 0,
      maxAoL = if (is.na(input[[ns("maxaol")]] %||% NA)) NA
               else input[[ns("maxaol")]],
      plusGroup = isTRUE(input[[ns("plus")]])))

    # Length/age allocation uses the catch weights as the fraction to
    # apply. If the discards have not been raised yet those weights are
    # only the landings plus whatever discards were imported, so the
    # allocation is applied to an incomplete catch. That is sometimes
    # what you want and sometimes a mistake, so it is flagged rather than
    # blocked.
    discards_raised <- reactive(!is.null(rv$final) || !is.null(rv$native))

    output[[ns("raisewarn")]] <- renderUI({
      if (discards_raised())
        return(div(class = "chain", style = "color:#245c2a",
                   sprintf("Discards have been raised; the %s allocation will use the raised catch table.",
                           tolower(what))))
      div(class = "chain", style = "color:#9a5000;border-left:5px solid #E15759",
          tags$b("Discard raising has not been performed yet."), tags$br(),
          sprintf(paste("%s allocations will only be applied to landings and",
                        "imported discards. Consider whether that is sensible,",
                        "or go back to the Discards tab and raise the",
                        "corresponding discards first."), what)) })

    output[[ns("status")]] <- renderUI({
      r <- rv[[out]]; er <- rv[[paste0(out, "_err")]]
      if (is.null(r) && !is.null(er))
        return(div(class = "chain", style = "color:#7a1f1f",
                   tags$b("Allocation failed:"), tags$br(), er))
      if (is.null(r))
        return(div(class = "note",
          sprintf("Pick an allocation and run it. %s classes come from the distributions table; the catch weights come from the raised catch table when one exists.",
                  what)))
      div(class = "chain", style = "color:#14532d",
          sprintf("Allocated with '%s': %s distribution rows, %s catch rows. Imported rows are kept and flagged, so nothing measured is overwritten.",
                  r$alloc_name %||% "?",
                  format(nrow(r$distribution), big.mark = ","),
                  format(nrow(r$catch), big.mark = ","))) })

    cmp_n <- reactive({ r <- rv[[out]]; req(!is.null(r))
      suppressWarnings(alloc_compare_numbers(r, grp())) })
    cmp_w <- reactive({ r <- rv[[out]]; req(!is.null(r))
      suppressWarnings(alloc_stock_weight(r, grp())) })

    # both figures come off the same aggregation, so they share a gate
    fig_sig <- reactive(list(input[[ns("group")]], input[[ns("minaol")]],
                             input[[ns("maxaol")]], input[[ns("plus")]]))
    fig_gate <- gate_of(ns("fig"), fig_sig, refresh = reactive(rv[[out]]))

    nplot_obj <- gated(fig_gate, {
      d <- cmp_n(); validate(need(!is.null(d) && nrow(d), "Nothing to compare."))
      plot_alloc_numbers(d, if (length(grp())) grp()[1] else NULL, what) })
    wplot_obj <- gated(fig_gate, {
      d <- cmp_w(); validate(need(!is.null(d) && nrow(d), "Nothing to compare."))
      plot_alloc_stockweight(d, if (length(grp())) grp()[1] else NULL, what) })

    output[[ns("nplot_ui")]] <- renderUI(plotOutput(ns("nplot"), height = "420px"))
    output[[ns("wplot_ui")]] <- renderUI(plotOutput(ns("wplot"), height = "420px"))
    output[[ns("nplot")]] <- renderPlot({
      pl <- nplot_obj(); validate(need(!is.null(pl), ""))
      pl + theme(legend.position = "none") })
    output[[ns("wplot")]] <- renderPlot({
      pl <- wplot_obj(); validate(need(!is.null(pl), ""))
      pl + theme(legend.position = "none") })
    output[[ns("legend")]] <- renderPlot({
      pl <- nplot_obj(); validate(need(!is.null(pl), "")); draw_legend(pl) },
      bg = "transparent")

    obj_nm <- if (identical(what, "Age")) "alloc_age" else "alloc_length"
    keep_plot(ns("nplot"), nplot_obj, gate = fig_gate,
      section = "output",
      title = sprintf("Numbers at %s - imported vs allocated", tolower(what)),
      note = function() sprintf("grouped by %s",
        if (length(grp())) paste(grp(), collapse = ", ") else "(nothing)"),
      prep = function() sprintf("d_n <- alloc_compare_numbers(%s, %s)",
                                obj_nm, fmt_vals(grp())),
      call = function() taf_call("plot_alloc_numbers", list(
        "d_n", taf_q(if (length(grp())) grp()[1] else NULL), taf_q(what))))

    keep_plot(ns("wplot"), wplot_obj, gate = fig_gate,
      section = "output",
      title = sprintf("Stock weight at %s (tonnes)", tolower(what)),
      note = function() sprintf("grouped by %s",
        if (length(grp())) paste(grp(), collapse = ", ") else "(nothing)"),
      prep = function() sprintf("d_w <- alloc_stock_weight(%s, %s)",
                                obj_nm, fmt_vals(grp())),
      call = function() taf_call("plot_alloc_stockweight", list(
        "d_w", taf_q(if (length(grp())) grp()[1] else NULL), taf_q(what))))

    output[[ns("overview")]] <- renderDT({
      r <- rv[[out]]; validate(need(!is.null(r), "Run the allocation first."))
      d <- suppressWarnings(alloc_overview(r))
      validate(need(!is.null(d), "Nothing to summarise."))
      datatable(d, rownames = FALSE, options = list(dom = "t", scrollX = TRUE)) })

    output[[ns("ntab")]] <- renderDT({
      r <- rv[[out]]; validate(need(!is.null(r), "Run the allocation first."))
      a <- agg_args()
      d <- suppressWarnings(agg_numbers(r,
        grouping = unique(c(grp(), "sampledOrEstimated")),
        minAoL = a$minAoL, maxAoL = a$maxAoL, plusGroup = a$plusGroup))
      validate(need(!is.null(d), "Aggregation returned nothing."))
      datatable(d, rownames = FALSE, options = list(scrollX = TRUE, dom = "tp")) })

    output[[ns("wtab")]] <- renderDT({
      r <- rv[[out]]; validate(need(!is.null(r), "Run the allocation first."))
      a <- agg_args()
      d <- suppressWarnings(agg_meanweight(r,
        grouping = unique(c(grp(), "sampledOrEstimated")),
        minAoL = a$minAoL, maxAoL = a$maxAoL, plusGroup = a$plusGroup,
        unit = "g"))
      validate(need(!is.null(d), "Aggregation returned nothing."))
      datatable(d, rownames = FALSE, options = list(scrollX = TRUE, dom = "tp")) })
  }

  length_raise_server("len", "LengthTotal", "Length", "len_allocs", "len_raised")
  length_raise_server("age", "Age", "Age", "age_allocs", "age_raised")

  # =========================================================
  #  SECTION 1 - InterCatch -> CEF
  # =========================================================
  dir_picker_server("ic_path", input, output, session)
  dir_picker_server("cef_dir", input, output, session)
  dir_picker_server("cfg_dir", input, output, session)

  # the source icons carry icexch / icout; the rest of the code (and
  # IC_FILE_ROLES) speaks exchange / output
  ic_src <- reactive(
    if (identical(input$ic_source %||% "icexch", "icout")) "output" else "exchange")

  # files can come from an upload or a folder on disk
  ic_mode <- reactive(input$ic_mode %||% "upload")
  ic_uploads <- reactive(input$ic_upl)   # data frame: name, datapath, ...

  # resolve a chosen file NAME to an actual path on disk: the temp datapath
  # for an upload, dir/name for a folder. Must be called reactively.
  ic_path_of <- function(name) {
    if (!isTruthy(name)) return(NA_character_)
    if (ic_mode() == "upload") {
      u <- ic_uploads()
      if (is.null(u)) return(NA_character_)
      hit <- u$datapath[match(name, u$name)]
      if (length(hit) && !is.na(hit)) hit else NA_character_
    } else file.path(ic_dir(), name)
  }

  # the role -> file mapping the user set in the file-map table
  ic_mapping <- reactive({
    roles <- names(IC_FILE_ROLES[[ic_src()]])
    setNames(lapply(roles, function(k) ic_path_of(input[[paste0("icf_", k)]])),
             roles)
  })

  # year: detected from the files, overridable by the ic_years box
  ic_years_detected <- reactive({
    p <- ic_file_paths()
    if (!length(p)) return(integer(0))
    ic_detect_year(p)
  })

  ic_inputs <- reactive(list(
    source = ic_src(),
    path = input$ic_path %||% ".",
    years = {
      typed <- suppressWarnings(as.numeric(
        strsplit(input$ic_years %||% "", "\\s*,\\s*")[[1]]))
      typed <- typed[!is.na(typed)]
      if (length(typed)) typed
      else if (length(ic_years_detected())) ic_years_detected()
      else cfg$year
    },
    rel_mode = input$ic_rel_mode %||% "build",
    rel_year = input$ic_rel_year %||% 2022,
    rel_file = if (!is.null(input$ic_rel_file)) input$ic_rel_file$name else NULL,
    output_format = input$ic_output_format,
    out_path = input$ic_out_path %||% ".",
    prefix = input$ic_prefix %||% "", suffix = input$ic_suffix %||% "",
    incl_bms = isTRUE(input$ic_incl_bms), patch_psu = isTRUE(input$ic_patch_psu),
    keep_temp = isTRUE(input$ic_keep_temp), metier6 = input$ic_metier6))

  # push the detected year into the box (and the rel year) once found
  observeEvent(ic_years_detected(), {
    y <- ic_years_detected()
    if (length(y)) {
      updateTextInput(session, "ic_years", value = paste(y, collapse = ", "))
      updateNumericInput(session, "ic_rel_year", value = max(y))
    }
  }, ignoreInit = TRUE)


  output$ic_status <- renderUI({
    st <- EXT_STATUS
    row <- function(lbl, ok) div(style = sprintf("color:%s;font-size:12px",
      if (ok) "#14532d" else "#7a1f1f"),
      HTML(sprintf("%s %s", if (ok) "&#10003;" else "&#10007;", lbl)))
    div(class = "chain",
      row("funIntercatchCEF()", st$ic_exchange),
      row("funICoutCEF()", st$ic_output),
      row("funMakeRelation()", st$make_rel),
      row("check_group_conditions()", st$group_cond),
      row("catchRaising()", st$raising),
      row("catchAllocationAoL()", st$catch_alloc),
      row("catchAtAoLAggregation()", st$catch_agg),
      row("meanWoLatAoLAggregation()", st$mean_agg),
      if (length(st$pkgs_missing))
        div(class = "note", style = "color:#9a5000;margin-top:6px",
            "Packages not installed here: ",
            paste(st$pkgs_missing, collapse = ", "),
            ". The call above is still written to the R script, so it can ",
            "be run where they are available.") else NULL,
      if (length(EXT$missing))
        div(class = "note", style = "margin-top:4px",
            "Scripts not found in ", EXT$dir, ": ",
            paste(EXT$missing, collapse = ", ")) else NULL) })

  output$ic_source_note <- renderUI({
    src <- ic_src()
    # a bare character VECTOR is not a valid tag child - htmltools needs
    # one string, or the pieces passed as separate arguments
    txt <- if (src == "exchange")
      paste("One csv file holding HI, SI and SD records. Conversion to CEF",
            "will be done using the funIntercatchCEF() function.")
    else
      paste("The .txt InterCatch export files. The tables are first",
            "re-written into exchange format with funICoutCEF() into a",
            "temporary file. Conversion to CEF is then done using the",
            "funIntercatchCEF() function.")
    div(class = "note", txt) })

  # the note at the top of the Input step - depends on which route
  output$ic_input_note <- renderUI({
    txt <- if (ic_src() == "exchange")
      paste("Select the directory or files to be loaded. A single csv file",
            "with HI, SI and SD records is expected. If data is split into",
            "several files, please merge those first before loading them.")
    else
      paste("Select the directory or files to be loaded. Three txt files:",
            "StockOverview, NumbersAtLengthAge and MeanWeightAtLengthAge .txt",
            "are expected.")
    div(class = "note", txt) })

  # which files are needed, which were found, and which is which
  ic_dir <- reactive(if (isTruthy(input$ic_path)) input$ic_path else cfg$dir)

  ic_files <- reactive({
    if (ic_mode() == "upload") {
      u <- ic_uploads(); if (is.null(u)) character(0) else sort(u$name)
    } else {
      d <- ic_dir()
      if (!dir.exists(d)) character(0)
      else sort(list.files(d, pattern = "\\.(csv|txt)$", ignore.case = TRUE))
    } })

  # actual paths behind the listed file names (for year detection etc.)
  ic_file_paths <- reactive({
    fs <- ic_files(); if (!length(fs)) return(character(0))
    unname(vapply(fs, ic_path_of, character(1))) })

  ic_roles <- reactive({
    roles <- IC_FILE_ROLES[[ic_src()]]
    # SD / the age-length files are only needed when lengths or ages are wanted
    if (!any(c("lengths", "ages") %in% cfg$need))
      roles <- roles[!names(roles) %in%
                     c("SD", "NumbersAtAgeLength", "MeanWeigthAtAgeLength")]
    roles })

  output$ic_file_map <- renderUI({
    fs <- ic_files(); roles <- ic_roles()
    all_roles <- IC_FILE_ROLES[[ic_src()]]
    if (ic_mode() == "dir" && !dir.exists(ic_dir()))
      return(div(class = "chain", style = "color:#7a1f1f",
                 sprintf("Directory not found: %s", ic_dir())))
    if (!length(fs))
      return(div(class = "chain", style = "color:#9a5000",
                 if (ic_mode() == "upload")
                   "Upload the InterCatch files on the left, then map each role here."
                 else sprintf("No csv or txt files in %s", ic_dir())))
    rows <- lapply(names(all_roles), function(k) {
      needed <- k %in% names(roles)
      guess <- fs[grepl(IC_FILE_PATTERN[[k]], fs, ignore.case = TRUE)]
      cur <- input[[paste0("icf_", k)]]
      sel <- if (isTruthy(cur) && cur %in% fs) cur else
             if (length(guess)) guess[1] else ""
      okf <- nzchar(sel)
      # green tick when a file is present (required or optionally mapped);
      # red cross only for a REQUIRED file that is missing; grey dash for
      # an optional role left empty
      col <- if (okf) "#14532d" else if (needed) "#7a1f1f" else "#8a8a8a"
      sym <- if (okf) "&#10003;" else if (needed) "&#10007;" else "&#8211;"
      fluidRow(style = "margin-bottom:2px;align-items:center",
        column(1, HTML(sprintf('<span style="color:%s;font-size:16px">%s</span>',
                               col, sym))),
        column(4, tags$b(k, style = "font-size:12px"), tags$br(),
               tags$span(style = "color:#8a8a8a;font-size:10px;
                                  text-transform:uppercase;letter-spacing:.3px",
                         all_roles[[k]])),
        column(7, selectInput(paste0("icf_", k), NULL,
                              choices = c(NONE, fs), selected = sel,
                              width = "100%")))
    })
    div(class = "chain",
      div(class = "note",
          if (ic_mode() == "upload")
            sprintf("%s file(s) uploaded. The guess comes from the file name - ",
                    length(fs))
          else sprintf("%s file(s) in %s. The guess comes from the file name - ",
                       length(fs), ic_dir()),
          "change any row that was matched to the wrong file."),
      do.call(tagList, rows),
      if (!any(c("lengths","ages") %in% cfg$need))
        div(class = "note", style = "margin-top:6px",
            "Sample and age-length files are optional for this run (no length ",
            "or age allocation was requested), but you can still map them to ",
            "explore the biology sampling.") else NULL) })

  observeEvent(input$build_rel, {
    if (!EXT_STATUS$make_rel) {
      showNotification("funMakeRelation() is not loaded.", type = "error"); return()
    }
    r <- tryCatch(funMakeRelation(input$ic_rel_year), error = function(e) e)
    if (inherits(r, "error"))
      showNotification(paste("stock_relation failed:", conditionMessage(r)),
                       type = "error", duration = 8)
    else showNotification("stock_relation built", type = "message")
  })

  output$rel_status <- renderUI({
    ok <- exists("stock_relation", envir = globalenv())
    div(class = "note", style = if (ok) "color:#14532d" else "color:#9a5000",
        if (ok) sprintf("stock_relation in memory (%s rows)",
                        nrow(get("stock_relation", envir = globalenv())))
        else "stock_relation not built yet") })

  # The conversion body, lifted out of the observer so the "replace the
  # data?" path can call exactly the same code the direct path calls.
  do_ic_load <- function() {
    i <- ic_inputs()
    fn <- if (i$source == "exchange") "funIntercatchCEF" else "funICoutCEF"
    if (!exists(fn, mode = "function")) {
      showNotification(paste0(fn, "() is not loaded - check the script folder."),
                       type = "error", duration = 8); return()
    }
    # Stage the mapped files into the layout the function expects, with the
    # canonical names its internal grep looks for. This is what lets an
    # arbitrary directory work instead of failing on the StockOverview
    # grep. If no mapping was made, fall back to the raw path.
    mp <- ic_mapping()
    have_map <- any(vapply(mp, function(x) isTruthy(x) && file.exists(x),
                           logical(1)))
    stage_path <- if (have_map)
      ic_stage_mapping(mp, i$source, i$years[1]) else i$path

    of <- unique(c(i$output_format, "to_list"))
    res <- with_busy("Converting InterCatch to CEF...", tryCatch({
      if (i$source == "exchange")
        funIntercatchCEF(dat_path = stage_path,
          stock_relation = get("stock_relation", envir = globalenv()),
          output_format = of, out_path = i$out_path, file_prefix = i$prefix,
          file_suffix = i$suffix, include_BMS_Caton = i$incl_bms,
          patch_missing_DIS_PSU = i$patch_psu,
          metier6 = if (nzchar(i$metier6)) i$metier6 else NULL)
      else
        funICoutCEF(dat_path = stage_path, years = i$years,
          stock_relation = if (i$rel_mode == "auto") NULL else
            get("stock_relation", envir = globalenv()),
          output_format = of, out_path = i$out_path,
          keep_temp_file = i$keep_temp, file_prefix = i$prefix,
          include_BMS_Caton = i$incl_bms, patch_missing_DIS_PSU = i$patch_psu,
          metier6 = if (nzchar(i$metier6)) i$metier6 else NULL)
    }, error = function(e) e))
    if (inherits(res, "error")) {
      rv$ic <- NULL
      showNotification(paste("Conversion failed:", conditionMessage(res)),
                       type = "error", duration = 10)
    } else {
      rv$ic <- res
      showNotification("Conversion finished", type = "message", duration = 4)
    }
    invisible(NULL)
  }

  observeEvent(input$run_ic, with_load_guard(
    if (identical(input$ic_source %||% "icexch", "icout")) "ic_output"
    else "ic_exchange", do_ic_load))

  output$ic_result <- renderUI({
    if (is.null(rv$ic)) return(div(class = "note", "Nothing converted yet."))
    r <- rv$ic
    div(class = "chain", sprintf(
      "catches: %s rows | distributions: %s | effort: %s",
      if (!is.null(r$catches)) nrow(r$catches) else 0,
      if (!is.null(r$distributions)) nrow(r$distributions) else 0,
      if (!is.null(r$effort)) nrow(r$effort) else 0)) })


  # --- data ------------------------------------------------
  # CEF either uploaded here or handed over from the InterCatch section
  raw <- reactive({
    if (!is.null(rv$ic$catches)) return(as.data.frame(rv$ic$catches))
    if (!is.null(rv$cef_catches)) return(rv$cef_catches)
    req(input$file)
    read.csv(input$file$datapath, sep = input$sep, stringsAsFactors = FALSE)
  })

  # load the three CEF tables from a folder, matched by name
  do_cef_load <- function() {
    d <- input$cef_dir %||% "."
    if (!dir.exists(d)) {
      showNotification(paste("Folder not found:", d), type = "error"); return()
    }
    fs <- list.files(d, pattern = "\\.(csv|txt)$", ignore.case = TRUE,
                     full.names = TRUE)
    pick <- function(pat) {
      m <- fs[grepl(pat, basename(fs), ignore.case = TRUE)]
      if (length(m)) m[1] else NA_character_
    }
    rd <- function(p) if (is.na(p)) NULL else
      read.csv(p, sep = input$sep %||% ",", stringsAsFactors = FALSE)
    cat_f <- pick("catches|catch"); dis_f <- pick("distribution")
    eff_f <- pick("effort")
    if (is.na(cat_f)) {
      showNotification("No catches file found in that folder.",
                       type = "error", duration = 8); return()
    }
    rv$cef_catches <- rd(cat_f)
    rv$dist <- rd(dis_f); rv$eff <- rd(eff_f)
    # remember WHICH files were matched, so data.R can name them instead of
    # re-running the same guesswork on the reader's machine
    rv$cef_files <- list(dir = d, catches = basename(cat_f),
                         distributions = if (is.na(dis_f)) NA_character_
                                         else basename(dis_f),
                         effort = if (is.na(eff_f)) NA_character_
                                  else basename(eff_f))
    showNotification(sprintf("Loaded catches%s%s from folder",
                             if (!is.na(dis_f)) ", distributions" else "",
                             if (!is.na(eff_f)) ", effort" else ""),
                     type = "message", duration = 5)
    invisible(NULL)
  }

  observeEvent(input$cef_load_dir, with_load_guard("cef", do_cef_load))

  # Colour every level of every shared key from the FULL table, the moment
  # the data lands. var_palette() would otherwise assign colours in the
  # order plots happen to ask for them, so opening the length tab before the
  # discard tab could give a country a different colour than the reverse -
  # consistent within the session, but not reproducible between runs, which
  # is not a property a report should have.
  observe({
    d <- tryCatch(derived(), error = function(e) NULL)
    if (!is.null(d) && nrow(d)) seed_palettes(d)
  })

  derived <- reactive({
    d <- raw()
    req_cols <- c("fleetValue","areaValue","vesselFlagCountry","seasonValue",
                  "catchCategory","total")
    validate(need(all(req_cols %in% names(d)),
                  paste("Missing:", paste(setdiff(req_cols, names(d)),
                                          collapse = ", "))))
    if (!"domainCatchDis" %in% names(d)) d$domainCatchDis <- NA_character_
    if (!"stock" %in% names(d)) d$stock <- "(unknown)"
    if (!"year"  %in% names(d)) d$year  <- NA
    derive_fields(d)
  })


  output$stock_ui <- renderUI({ req(derived())
    selectInput("stock", "Stock", sort(unique(derived()$stock))) })
  output$year_ui <- renderUI({ req(derived())
    selectInput("year", "Year",
                c("(all)" = "", sort(unique(as.character(derived()$year))))) })

  dat <- reactive({
    d <- derived()
    if (isTruthy(input$stock)) d <- d[d$stock == input$stock, ]
    if (isTruthy(input$year))  d <- d[as.character(d$year) == input$year, ]
    validate(need(nrow(d) > 0, "No rows for this stock/year."))
    d
  })

  dmap <- function(p) {
    f <- input[[paste0(p, "_fleet")]]; a <- input[[paste0(p, "_area")]]
    c(Fleet = if (is.null(f)) "metier4" else f, Country = "Country",
      Area = if (is.null(a)) "ICESDivision" else a, Season = "Season")
  }
  col_of <- function(p, sel) {
    if (is.null(sel) || !nzchar(sel)) return(NULL)
    unname(dmap(p)[sel])
  }
  role <- function(p, r) col_of(p, input[[paste0(p, "_", r)]])

  # strata at the tab's full resolution (all four dimensions)
  strata_p <- function(p) build_strata(dat(), unname(dmap(p)[DIMS]))

  # strata aggregated to EXACTLY the columns used by the plot. Without this
  # the table still holds every dimension, so a heatmap cell or a bubble
  # gets several rows stacked on the same spot.
  strata_roles <- function(p, sels) {
    cols <- unique(unlist(lapply(sels, function(x) col_of(p, x))))
    validate(need(length(cols) >= 1, "Pick at least one variable."))
    build_strata(dat(), cols)
  }

  # --- data tab summary ------------------------------------

  output$data_msg <- renderUI({ req(dat())
    div(class = "note", style = "font-size:12px",
        sprintf("%s rows | %s strata at the level of detail set bottom-right",
                nrow(dat()), nrow(strata_p("dt")))) })



  # --- plot sizing: the container is sized here, so nothing overlaps ----
  hgt <- function(p, facet_sel, n_y = 10) {
    s <- try(strata_p(p), silent = TRUE)
    if (inherits(s, "try-error")) return(460)
    plot_height(s, col_of(p, facet_sel), n_y)
  }
  slot_ui <- function(id, h) renderUI(plotOutput(id, height = paste0(h, "px")))

  output$auto_river_ui <- renderUI(plotOutput("auto_river", height = "580px"))
  output$man_river_ui  <- renderUI(plotOutput("man_river",  height = "580px"))
  output$cmp_plot_ui <- renderUI({
    fc <- cmp_col(input$cmp_facet)
    n <- if (!is.null(fc) && length(rv$scenarios))
      length(unique(as.character(cmp()[[fc]]))) else 1
    plotOutput("cmp_plot",
               height = paste0(max(420, 300 + ceiling(n / 2) * 210), "px")) })

  # --- 2. discard rates ------------------------------------


  output$dr_tbl <- renderDT(datatable(
    strata_p("dr") %>% filter(!is.na(discard_rate)) %>%
      mutate(discard_rate = round(discard_rate, 3), coverage = round(coverage, 1)),
    options = list(scrollX = TRUE, pageLength = 10), rownames = FALSE))

  # --- 3/4/5: aggregate to the plotted roles only ----------

  tree_tbl_r <- reactive(decision_tree(
    rec(), hier_cols(), hier_thr(),
    self_thr_val(),
    input$hier_mode %||% "nested", unname(dmap("ar")[DIMS])))

  # Key 1 is always the stratum's own data; keys 2..5 are the widening
  # dimensions the user picks. Each key row carries its own threshold
  # slider right beside it.
  hier <- reactive({
    h <- vapply(2:5, function(i) input[[paste0("hier_", i)]] %||% "", character(1))
    h <- h[nzchar(h)]
    validate(need(length(h) >= 1, "Pick at least one widening key (Key 2 onward)."),
             need(!any(duplicated(h)), "Each key can be used once."))
    h })
  hier_cols <- reactive(unname(dmap("ar")[hier()]))

  # the own-stratum threshold is Key 1's slider
  self_thr_val <- reactive({
    x <- input$thr_1
    if (is.null(x) || all(is.na(x))) 50 else as.numeric(x)[1] })

  output$hier_keys <- renderUI({
    # Key 1: own stratum, fixed, with its threshold
    key1 <- fluidRow(class = "hier-key-row",
      column(6, tags$div(class = "hier-key-fixed",
                         tags$b("Key 1"), tags$br(), "Own stratum",
                         tags$span(class = "note", "(the stratum on its own data)"))),
      column(6, sliderInput("thr_1", "threshold %", 0, 100,
                            c(input$threshold %||% 50, 100), 5)))
    # Keys 2..5: user-chosen widening dimensions, each with a threshold
    picked <- vapply(2:5, function(i) input[[paste0("hier_", i)]] %||% "",
                     character(1))
    krows <- lapply(2:5, function(i) {
      def <- c(Fleet = "Fleet", Country = "Country", Area = "Area",
               Season = "Season")
      dflt <- c("Fleet", "Country", "Area", "Season")[i - 1]
      already <- picked[seq_len(i - 2)]
      fluidRow(class = "hier-key-row",
        column(6, selectInput(paste0("hier_", i), paste("Key", i),
                              c(NONE, setNames(DIMS, DIMS)),
                              input[[paste0("hier_", i)]] %||% dflt)),
        column(6, sliderInput(paste0("thr_", i), "threshold %", 0, 100,
                              c(input$threshold %||% 50, 100), 5)))
    })
    tagList(key1, tags$hr(style = "margin:6px 0"), krows) })

  output$hier_chain <- renderUI({
    st <- raising_steps(hier_cols(), hier_thr(),
                        self_thr_val(),
                        input$hier_mode %||% "nested", unname(dmap("ar")[DIMS]))
    div(class = "chain", tags$b("Order actually tested:"), tags$br(),
        HTML(paste(c(vapply(st, `[[`, character(1), "label"), "ALL"),
                   collapse = " &rarr; "))) })

  # the ladder: a step card on the left, its own river on the right
  output$tree_ui <- renderUI({
    tr <- tree_tbl_r2()
    pal <- c("#00441B","#41AE76","#7FCDBB","#FFD92F","#E66101","#BFBFBF")
    rows <- lapply(seq_len(nrow(tr)), function(i) {
      r <- tr[i, ]; col <- pal[min(i, length(pal))]
      fluidRow(style = "margin-bottom:10px",
        column(4,
          div(style = sprintf(
            "border-left:6px solid %s;background:#fbfbfd;border:1px solid #e2e2e8;
             border-radius:7px;padding:7px 10px;font-size:12px", col),
            tags$b(paste0(if (r$step == "Fallback") "Fallback" else
                          paste("Step", r$step), ": ", r$pool)),
            if (!is.na(r$threshold))
              tags$span(style = "color:#555",
                        sprintf("  (needs %s%%)", r$threshold)) else NULL,
            tags$br(),
            tags$span(style = "color:#666", r$what_it_pools), tags$br(),
            tags$span(style = sprintf("color:%s;font-weight:700", col),
              sprintf("%s strata | %s t (%s%% of landings)",
                      r$n_strata, fmt_t3(r$landings), r$pct_landings)),
            tags$br(),
            tags$span(style = "color:#777;font-size:11px",
              sprintf("cumulative: %s%% of strata, %s%% of landings resolved",
                      r$cum_pct_strata, r$cum_pct_landings)))),
        column(8,
          if (r$n_strata > 0)
            plotOutput(paste0("river_", i),
                       height = paste0(max(240, 60 + r$n_strata * 26), "px"))
          else div(class = "note", style = "padding-top:24px",
                   "nothing resolved at this step")))
    })
    do.call(tagList, rows) })

  tree_tbl_r2 <- reactive(decision_tree2(
    rec(), hier_cols(), hier_thr(),
    self_thr_val(),
    input$hier_mode %||% "nested", unname(dmap("ar")[DIMS])))

  output$tree_tbl <- renderDT(datatable(
    tree_tbl_r2(), rownames = FALSE, options = list(dom = "t", scrollX = TRUE)))


  observe({
    tr <- tree_tbl_r2()
    ids <- c("0", vapply(raising_steps(
      hier_cols(), hier_thr(),
      self_thr_val(),
      input$hier_mode %||% "nested", unname(dmap("ar")[DIMS])),
      `[[`, character(1), "id"), "fallback")
    rg <- rec_g(); pal <- auto_pal(); dd <- unname(dmap("ar")[DIMS])
    for (i in seq_along(ids)) local({
      j <- i; id <- ids[j]
      output[[paste0("river_", j)]] <- renderPlot({
        p <- plot_river_level(rg, id, dd, pal)
        validate(need(!is.null(p), "")); p })
    }) })

  # every stratum must leave at exactly one step
  output$tree_check <- renderUI({
    ck <- check_partition(rec(), tree_tbl_r())
    good <- ck$n_ok && ck$l_ok && ck$unassigned == 0
    div(style = sprintf(
      "border-radius:6px;padding:7px 10px;margin:4px 0 12px 0;font-size:12px;
       background:%s;border:1px solid %s;color:%s",
      if (good) "#eaf7ee" else "#fdeaea",
      if (good) "#41AE76" else "#E15759",
      if (good) "#14532d" else "#7a1f1f"),
      tags$b(if (good) "Checks out: the steps partition the data exactly."
             else "Problem: the steps do not partition the data."),
      tags$br(),
      sprintf("Strata assigned %s of %s. Landings across steps %s t of %s t total.",
              format(ck$n_steps, big.mark = ","), format(ck$n_total, big.mark = ","),
              fmt_t3(ck$l_steps), fmt_t3(ck$l_total)),
      if (ck$unassigned > 0)
        tags$div(sprintf("%s strata never resolved.", ck$unassigned)) else NULL)
  })

  # A single-value slider paints the region BELOW the handle, i.e. the part
  # that fails. Using a range pinned at 100 paints the qualifying side
  # instead, which is what the threshold actually means.
  observeEvent(input$apply_all, {
    updateSliderInput(session, "thr_1", value = c(input$thr_all, 100))
    for (i in 2:5)
      updateSliderInput(session, paste0("thr_", i),
                        value = c(input$thr_all, 100))
    showNotification(paste("All thresholds set to", input$thr_all, "%"),
                     type = "message", duration = 2) })

  # thresholds for the widening keys (2..5), in the order they are tested
  hier_thr <- reactive({
    vapply(seq_along(hier_cols()), function(k) {
      x <- input[[paste0("thr_", k + 1)]]   # Key 2 -> thr_2, etc.
      if (is.null(x) || all(is.na(x))) input$threshold else as.numeric(x)[1]
    }, numeric(1)) })

  # a discard rate can exceed 1 (discards with almost no landings), so the
  # slider always reaches 5% past the largest rate present - otherwise
  # those strata cannot be included or excluded explicitly
  dr_top <- function(p) {
    s <- try(strata_p(p), silent = TRUE)
    if (inherits(s, "try-error")) return(1)
    m <- suppressWarnings(max(s$discard_rate, na.rm = TRUE))
    if (!is.finite(m)) 1 else max(1, ceiling(m * 1.05 * 100) / 100) }

  # named-stratum exclusion, shared shape between the two builders
  excl_choices <- function(prefix, order_by = "landings") {
    st <- try(strata_p(prefix), silent = TRUE)
    if (inherits(st, "try-error")) return(character(0))
    donor_choices(st, unname(dmap(prefix)[DIMS]), order_by = order_by)
  }

  # everything currently out of the donor pool, from either route
  excl_table <- function(prefix, excluded, dr) {
    st <- try(strata_p(prefix), silent = TRUE)
    if (inherits(st, "try-error")) return(NULL)
    excluded_overview(st, unname(dmap(prefix)[DIMS]), excluded, dr[1], dr[2])
  }

  output$ar_excl_ui <- renderUI(
    selectizeInput("ar_excl", NULL,
                   choices = excl_choices("ar", input$ar_excl_sort %||% "landings"),
                   multiple = TRUE,
                   options = list(placeholder = "no stratum excluded")))

  output$ar_excl_note <- renderUI({
    ex <- input$ar_excl
    if (!length(ex)) return(NULL)
    div(class = "chain", style = "color:#9a5000;font-family:monospace;font-size:10.5px",
        donor_exclusion_expr(ex, unname(dmap("ar")[DIMS]))) })

  output$mg_excl_ui <- renderUI(
    selectizeInput("mg_excl", NULL,
                   choices = excl_choices("mg", input$mg_excl_sort %||% "landings"),
                   multiple = TRUE,
                   options = list(placeholder = "no stratum excluded")))

  output$mg_excl_note <- renderUI({
    ex <- input$mg_excl
    if (!length(ex)) return(NULL)
    div(class = "chain", style = "color:#9a5000;font-family:monospace;font-size:10.5px",
        donor_exclusion_expr(ex, unname(dmap("mg")[DIMS]))) })

  # the two condition lists, ready to paste into a script
  output$man_conds <- renderText({
    if (!length(rv$rules)) return("(no groups yet)")
    paste(emit_rules_code(rv$rules, rv$sets, unname(dmap("mg")[DIMS])),
          collapse = "\n") })

  # push a sparkline per stratum so the hover preview has something to
  # show. Only the length link carries distributions, so this is a no-op
  # until one is loaded.
  observe({
    d <- tryCatch(dat(), error = function(e) NULL)
    dst <- if (!is.null(rv$dist)) rv$dist
           else if (!is.null(rv$ic$distributions)) as.data.frame(rv$ic$distributions)
           else NULL
    if (is.null(d) || is.null(dst)) return()
    dims <- unname(dmap("ar")[DIMS])
    lk <- tryCatch(link_dist_to_strata(d, dst, c("catchCategory", dims), NULL),
                   error = function(e) NULL)
    if (is.null(lk) || !nrow(lk)) return()
    keys <- unique(do.call(paste, c(lapply(dims, function(k)
      as.character(lk[[k]])), sep = " | ")))
    m <- tryCatch(stratum_sparkline_map(lk, dims, keys),
                  error = function(e) list())
    if (length(m)) session$sendCustomMessage("stratSvg", list(map = m)) })

  output$ar_excl_tbl <- renderDT({
    d <- excl_table("ar", input$ar_excl %||% character(0), ar_dr())
    validate(need(!is.null(d) && nrow(d), "Nothing excluded."))
    datatable(d, rownames = FALSE, options = list(dom = "tp", pageLength = 8,
                                                  scrollX = TRUE)) })

  output$mg_excl_tbl <- renderDT({
    d <- excl_table("mg", input$mg_excl %||% character(0), rule_dr())
    validate(need(!is.null(d) && nrow(d), "Nothing excluded."))
    datatable(d, rownames = FALSE, options = list(dom = "tp", pageLength = 8,
                                                  scrollX = TRUE)) })

  output$ar_dr_ui <- renderUI({
    top <- dr_top("ar")
    sliderInput("ar_dr", "Allowed discard rate", 0, top, c(0, top), 0.01) })

  ar_dr <- reactive({
    v <- input$ar_dr; if (is.null(v)) return(c(NA, NA))
    top <- dr_top("ar")
    c(if (v[1] > 0) v[1] else NA, if (v[2] < top) v[2] else NA) })

  rec <- reactive({
    s <- classify_strata(strata_p("ar"), input$threshold)
    s <- flag_donor_exclusion(s, ar_dr()[1], ar_dr()[2])
    recommend_raising(s, hier_cols(), hier_thr(),
                      self_threshold = self_thr_val(),
                      mode = input$hier_mode %||% "nested",
                      dims = unname(dmap("ar")[DIMS])) })

  auto_groups <- reactive(raising_groups(rec()))
  auto_pal <- reactive(group_palette(auto_groups()$group_id))

  # attach the group id to every stratum so the colour is per G, not per level
  rec_g <- reactive({
    g <- auto_groups()
    rec() %>% mutate(group_id = g$group_id[match(raise_condition, g$raise_condition)]) })

  output$diag_tbl <- renderDT({
    d <- rec_g() %>%
      mutate(coverage = round(coverage, 1), discard_rate = round(discard_rate, 3)) %>%
      select(all_of(unname(dmap("ar")[DIMS])), landings, landings_with_discards,
             discards, coverage, discard_rate, donor_ok, Status, group_id,
             raise_level, raise_coverage, raise_n_strata, raise_condition) %>%
      rename(`recommended raising strata` = raise_condition)
    dt_group_colours(
      datatable(d, options = list(scrollX = TRUE, pageLength = 15), rownames = FALSE),
      "group_id", auto_pal()) })

  output$grp_tbl <- renderDT(dt_group_colours(
    datatable(auto_groups(), options = list(scrollX = TRUE), rownames = FALSE),
    "group_id", auto_pal()))

  output$auto_river <- renderPlot({
    d <- rec_g() %>% filter(raise_level != "no raising needed")
    validate(need(nrow(d) > 0, "Nothing needs raising."))
    dd <- unname(dmap("ar")[DIMS])
    p <- plot_river(d, left_var = NULL, right_var = "group_id",
                    value_var = "landings", pal = auto_pal(),
                    left_label = stratum_label(d, dd),
                    right_label = rule_label(d),
                    stratum_axis = stratum_axis_label(hier_cols()))
    validate(need(!is.null(p), "Nothing to plot.")); p })

  # --- 7. manual -------------------------------------------
  # relevant variables first, everything else behind a disclosure
  output$clause_var_chips <- renderUI({
    d <- tryCatch(dat(), error = function(e) NULL)
    shown <- intersect(FILTER_VARS, names(d %||% list()))
    if (!length(shown)) shown <- FILTER_VARS
    core <- intersect(c("metier4","metier5","metier6","Country",
                        "ICESDivision","Season","FleetType"), shown)
    var_chips("clause_var", core, setdiff(c(shown,
      setdiff(names(d %||% list()), c("total","stratum_id"))), core),
      input$clause_var %||% "Country") })

  observe({ req(dat(), input$clause_var, input$clause_var %in% names(dat()))
    updateSelectizeInput(session, "clause_vals",
      choices = sort(unique(as.character(dat()[[input$clause_var]]))), server = TRUE) })

  observeEvent(input$add_clause, {
    req(length(input$clause_vals) >= 1)
    rv$clause <- c(rv$clause, list(list(var = input$clause_var,
                                        values = input$clause_vals,
                                        negate = isTRUE(input$clause_neg)))) })
  observeEvent(input$clear_clause, rv$clause <- list())

  output$clause_chip <- renderUI({
    empty <- !length(rv$clause)
    div(style = "margin:6px 0",
      tags$div(class = paste("dragchip", if (empty) "empty" else ""),
        draggable = if (empty) "false" else "true",
        ondragstart = "event.dataTransfer.setData('text/plain','clause')",
        if (empty) "(build a clause above)" else cond_string(rv$clause))) })

  observeEvent(input$drop_target, {
    req(length(rv$clause) >= 1)
    if (input$drop_target == "strata") rv$pend_raise <- rv$clause
    else rv$pend_source <- rv$clause
    rv$clause <- list() })

  output$strata_txt_ui <- renderUI(tags$span(
    if (is.null(rv$pend_raise)) "(drop a clause here - matches every stratum)"
    else cond_string(rv$pend_raise)))

  output$matched_txt_ui <- renderUI({
    src <- if (is.null(rv$pend_source)) rv$pend_raise else rv$pend_source
    tmp <- new_rule("tmp", "", list(), src %||% list(), rule_dr()[1], rule_dr()[2])
    tags$span(paste0(source_cond_string(tmp),
      if (is.null(rv$pend_source)) "  (mirroring strataCond)" else "")) })

  observeEvent(input$to_strata,  { rv$pend_raise  <- rv$clause; rv$clause <- list() })
  observeEvent(input$to_matched, { rv$pend_source <- rv$clause; rv$clause <- list() })
  observeEvent(input$mirror,      rv$pend_source <- rv$pend_raise)
  observeEvent(input$mirror_back, rv$pend_raise  <- rv$pend_source)

  observeEvent(input$save_rule, {
    req(nzchar(input$rule_id))
    r <- new_rule(input$rule_id, input$rule_label, rv$pend_raise %||% list(),
                  rv$pend_source, rule_dr()[1], rule_dr()[2],
                  excluded = input$mg_excl %||% character(0))
    ids <- vapply(rv$rules, `[[`, character(1), "id")
    if (r$id %in% ids) {
      rv$rules[[which(ids == r$id)]] <- r
      showNotification(paste0("Group '", r$id, "' overwritten"),
                       type = "warning", duration = 3)
    } else {
      rv$rules <- c(rv$rules, list(r))
      showNotification(paste0("Group '", r$id, "' saved"),
                       type = "message", duration = 2)
    }
    rv$clause <- list(); rv$pend_raise <- NULL; rv$pend_source <- NULL
    updateTextInput(session, "rule_id", value = paste0("G", length(rv$rules) + 1)) })

  observeEvent(input$add_catchall, {
    dr <- c(if (input$catchall_dr[1] > 0) input$catchall_dr[1] else NA,
            if (input$catchall_dr[2] < 1) input$catchall_dr[2] else NA)
    rv$rules <- c(rv$rules, list(new_rule(paste0("G", length(rv$rules) + 1),
      "catch-all", list(), NULL, dr[1], dr[2],
      # by default the catch-all keeps every stratum: an exclusion made
      # for one group is rarely meant to remove the stratum entirely
      excluded = if (isTRUE(input$catchall_keep_excl))
        input$mg_excl %||% character(0) else character(0))))
    showNotification("Catch-all added at the end", duration = 2) })

  man_pal <- reactive(group_palette(vapply(rv$rules, `[[`, character(1), "id")))

  output$rule_order <- renderUI({
    if (!length(rv$rules)) return(div(class = "note", "No groups yet."))
    pal <- man_pal()
    tagList(lapply(seq_along(rv$rules), function(i) {
      r <- rv$rules[[i]]
      btn <- function(dir, sym) tags$button(
        class = "rulebtn", HTML(sym),
        onclick = sprintf(
          "Shiny.setInputValue('rule_move',{i:%d,dir:'%s'},{priority:'event'})",
          i, dir))
      div(class = "rulerow",
          div(class = "rulechip", style = paste0("background:", pal[[r$id]]), r$id),
          div(style = "flex:1;overflow:hidden;text-overflow:ellipsis",
              tags$b(r$label), tags$br(),
              tags$span(style = "font-family:monospace;font-size:10px;color:#555",
                        cond_string(r$raise))),
          btn("up", "&#9650;"), btn("down", "&#9660;"), btn("del", "&#10005;"))
    })) })

  observeEvent(input$rule_move, {
    i <- input$rule_move$i; d <- input$rule_move$dir
    if (d == "del") { rv$rules[[i]] <- NULL; return(invisible()) }
    j <- if (d == "up") i - 1 else i + 1
    if (j >= 1 && j <= length(rv$rules)) {
      t <- rv$rules[[i]]; rv$rules[[i]] <- rv$rules[[j]]; rv$rules[[j]] <- t } })

  man_strata <- reactive(strata_p("mg"))

  # ---------------------------------------------------------
  #  The manual decision ladder
  # ---------------------------------------------------------
  # The same view the hierarchical tab has always had, because the question
  # is the same one: what does this rule take, how much of the stock is
  # that, and what is left afterwards. Reading it as cards rather than as a
  # table is what makes an over-broad rule obvious - it shows up as one card
  # swallowing 80% of the landings before the specific rules below it get a
  # chance.
  man_decision <- reactive({
    req(length(rv$rules) >= 1)
    rule_decision_table(man_strata(), rv$rules, rv$sets) })

  man_river_d <- reactive({
    req(length(rv$rules) >= 1)
    rule_river_data(man_strata(), rv$rules, rv$sets) })

  output$man_ladder <- renderUI({
    validate(need(length(rv$rules) >= 1, "No groups yet."))
    tr <- man_decision(); validate(need(!is.null(tr), "Nothing to show."))
    pal <- man_pal()
    rows <- lapply(seq_len(nrow(tr)), function(i) {
      r <- tr[i, ]
      unass <- identical(r$rule, "(unassigned)")
      col <- if (unass) "#7a1f1f" else (pal[[r$rule]] %||% "#12324f")
      fluidRow(style = "margin-bottom:10px",
        column(4,
          div(style = sprintf(
            "border-left:6px solid %s;background:%s;border:1px solid #e2e2e8;
             border-radius:7px;padding:7px 10px;font-size:12px", col,
            if (unass) "#fff3f3" else "#fbfbfd"),
            tags$b(if (unass) "Not covered by any rule"
                   else sprintf("%s: %s", r$rule, r$label)),
            tags$br(),
            # the rule itself, so the card explains the number beside it
            if (!unass) tagList(
              tags$span(style = "color:#666", "raises "),
              tags$span(style = "font-family:monospace;font-size:10.5px;color:#333",
                        r$raises), tags$br(),
              tags$span(style = "color:#666", "from "),
              tags$span(style = "font-family:monospace;font-size:10.5px;color:#333",
                        r$donors), tags$br())
            else tagList(
              tags$span(style = "color:#7a1f1f",
                "These strata reach catchRaising() in no group at all. Add a ",
                "catch-all, or widen a rule."), tags$br()),
            tags$span(style = sprintf("color:%s;font-weight:700", col),
              sprintf("%s strata | %s t (%s%% of landings)",
                      r$n_strata, fmt_t3(r$landings), r$pct_landings)),
            # A rule that claims more than it takes is not a bug: the rules
            # above it got there first. Saying so on the card is what stops
            # a catch-all looking like it double-raises.
            if (!unass && !is.na(r$n_claimed) && r$n_claimed > r$n_strata)
              tagList(tags$br(), tags$span(style = "color:#9a5000;font-size:11px",
                sprintf("clause matches %s, but %s were already taken above",
                        r$n_claimed, r$n_claimed - r$n_strata)))
            else NULL,
            tags$br(),
            tags$span(style = "color:#777;font-size:11px",
              sprintf("cumulative: %s%% of strata, %s%% of landings resolved",
                      r$cum_pct_strata, r$cum_pct_landings)),
            if (!unass && !is.na(r$n_donors)) tagList(tags$br(),
              tags$span(style = "color:#777;font-size:11px",
                sprintf("donor pool: %s strata, %s%% coverage, DR %s",
                        r$n_donors,
                        if (is.na(r$donor_coverage)) "-" else r$donor_coverage,
                        if (is.na(r$donor_DR)) "-" else r$donor_DR)))
            else NULL)),
        column(8,
          if (r$n_strata > 0)
            plotOutput(paste0("man_river_", i),
                       height = paste0(max(240, 60 + r$n_strata * 26), "px"))
          else div(class = "note", style = "padding-top:24px",
                   "nothing left for this rule to raise")))
    })
    do.call(tagList, rows) })

  observe({
    tr <- man_decision(); req(!is.null(tr))
    d <- man_river_d(); pal <- man_pal(); dd <- unname(dmap("mg")[DIMS])
    for (i in seq_len(nrow(tr))) local({
      j <- i; id <- tr$rule[j]
      output[[paste0("man_river_", j)]] <- renderPlot({
        p <- plot_river_level(d, id, dd, pal)
        validate(need(!is.null(p), "")); p })
    }) })

  # Does the rule set partition the stock? The one thing a reader cannot
  # check by eye, and the one that silently loses landings when it fails.
  output$man_check <- renderUI({
    tr <- man_decision(); req(!is.null(tr))
    miss <- tr[tr$rule == "(unassigned)", , drop = FALSE]
    ok <- !nrow(miss)
    div(style = sprintf(
      "border-radius:7px;padding:7px 10px;font-size:12px;margin:6px 0;
       background:%s;border:1px solid %s;color:%s",
      if (ok) "#eef7ee" else "#fff3f3", if (ok) "#59A14F" else "#c0392b",
      if (ok) "#14532d" else "#7a1f1f"),
      if (ok) tagList(tags$b("Every stratum is covered."),
                      " The rules partition the stock, so nothing is raised ",
                      "twice and nothing is left out.")
      else tagList(tags$b(sprintf(
        "%s strata (%s t) are not covered by any rule.",
        miss$n_strata, fmt_t3(miss$landings))),
        " They will reach catchRaising() in no group. Add a catch-all as ",
        "the last rule, or widen one above.")) })

  output$rules_tbl <- renderDT({
    validate(need(length(rv$rules) >= 1, "No groups yet."))
    dt_group_colours(datatable(rule_group_summary(man_strata(), rv$rules, rv$sets),
                               options = list(scrollX = TRUE), rownames = FALSE),
                     "group_id", man_pal()) })

  man_assigned <- reactive({
    req(length(rv$rules) >= 1)
    assign_rule_groups(man_strata(), rv$rules, rv$sets) })

  output$rules_strata_tbl <- renderDT({
    validate(need(length(rv$rules) >= 1, "No groups yet."))
    d <- man_assigned() %>%
      mutate(coverage = round(coverage, 1), discard_rate = round(discard_rate, 3)) %>%
      select(-usedToRaiseGroup) %>% rename(donates_to = usedToRaiseGroups_txt)
    dt_group_colours(datatable(d, options = list(scrollX = TRUE, pageLength = 15),
                               rownames = FALSE), "toBeRaisedGroup", man_pal()) })

  output$man_ov <- renderDT({
    validate(need(length(rv$rules) >= 1, "No groups yet."))
    dt_group_colours(datatable(manual_overview(man_assigned(), rv$rules),
                               options = list(scrollX = TRUE, dom = "t"),
                               rownames = FALSE), "group", man_pal()) })

  output$man_river <- renderPlot({
    validate(need(length(rv$rules) >= 1, "No groups yet."))
    a <- man_assigned()
    dd <- unname(dmap("mg")[DIMS])
    # map each group id to its rule meaning: the label plus the clause
    rl <- setNames(vapply(rv$rules, function(r) {
      cl <- cond_string(r$raise)
      base <- if (nzchar(r$label %||% "")) r$label else r$id
      if (identical(cl, "TRUE")) paste0(base, ": all remaining strata  [", r$id, "]")
      else paste0(cl, "  [", r$id, "]")
    }, character(1)), vapply(rv$rules, `[[`, character(1), "id"))
    right <- unname(rl[as.character(a$toBeRaisedGroup)])
    right[is.na(right)] <- as.character(a$toBeRaisedGroup)[is.na(right)]
    p <- plot_river(a, left_var = NULL, right_var = "toBeRaisedGroup",
                    value_var = "landings", pal = man_pal(),
                    title = "Strata and the group that raises them",
                    left_label = stratum_label(a, dd),
                    right_label = right,
                    stratum_axis = stratum_axis_label(dd))
    validate(need(!is.null(p), "Nothing to plot.")); p })

  # ---- group allocations (saved setups) ----
  save_sc <- function(name, sc) {
    dup <- name %in% names(rv$scenarios)
    rv$scenarios[[name]] <- sc
    showNotification(
      if (dup) paste0("Allocation '", name, "' OVERWRITTEN")
      else paste0("Allocation '", name, "' saved - ", length(rv$scenarios),
                  " in this session"),
      type = if (dup) "warning" else "message", duration = 5) }

  observeEvent(input$save_auto, {
    req(nzchar(input$auto_name))
    save_sc(input$auto_name, scenario_auto(
      input$auto_name, unname(dmap("ar")[DIMS]), hier_cols(), hier_thr(),
      input$ar_fleet, input$ar_area,
      self_threshold = self_thr_val(),
      mode = input$hier_mode %||% "nested",
      dr_min = ar_dr()[1], dr_max = ar_dr()[2])) })

  observeEvent(input$save_manual, {
    req(nzchar(input$man_name), length(rv$rules) >= 1)
    save_sc(input$man_name, scenario_manual(
      input$man_name, unname(dmap("mg")[DIMS]), rv$rules, rv$sets,
      input$mg_fleet, input$mg_area)) })

  observe(updateSelectInput(session, "del_sc_id", choices = names(rv$scenarios)))
  observeEvent(input$del_sc, { req(input$del_sc_id)
    nm <- input$del_sc_id; rv$scenarios[[nm]] <- NULL
    showNotification(paste0("Removed '", nm, "'"), duration = 2) })

  observeEvent(input$up_sc, {
    req(input$up_sc)
    sc <- scenarios_from_json(readLines(input$up_sc$datapath, warn = FALSE))
    for (x in sc) rv$scenarios[[x$name]] <- x
    showNotification(paste("Loaded", length(sc), "allocation(s)"), duration = 3) })

  output$dl_sc <- downloadHandler(
    filename = function() paste0("group_allocations_", Sys.Date(), ".json"),
    content = function(f) writeLines(scenarios_to_json(unname(rv$scenarios)), f))

  sc_table <- reactive({
    if (!length(rv$scenarios))
      return(data.frame(name = character(0), method = character(0),
                        detail = character(0), strata = character(0),
                        saved = character(0)))
    data.frame(
      name = names(rv$scenarios),
      method = vapply(rv$scenarios, `[[`, character(1), "method"),
      strata = vapply(rv$scenarios, function(x)
        paste(x$dims, collapse = " x "), character(1)),
      detail = vapply(rv$scenarios, function(x)
        if (x$method == "auto")
          paste0(paste(x$hierarchy, collapse = " > "), "  @ ",
                 paste(x$thresholds, collapse = "/"), "%",
                 if (!is.null(x$self_threshold) && !is.na(x$self_threshold))
                   paste0(" (self ", x$self_threshold, "%)") else "")
        else paste(length(x$rules), "groups"), character(1)),
      level = vapply(rv$scenarios, function(x)
        paste(x$fleet_level, "/", x$area_level), character(1)),
      saved = vapply(rv$scenarios, `[[`, character(1), "saved"),
      stringsAsFactors = FALSE) })

  output$sc_tbl <- renderDT(datatable(sc_table(), rownames = FALSE,
                                      options = list(dom = "t", scrollX = TRUE)))

  runs <- reactive({
    req(length(rv$scenarios) >= 1)
    setNames(lapply(rv$scenarios, run_scenario, catch_data = dat()),
             names(rv$scenarios)) })

  cmp_keys <- reactive({
    k <- common_keys(runs())
    intersect(k, c("fleetValue","metier4","metier5","metier6","Country",
                   "areaValue","Season")) })

  output$cmp_note <- renderUI({
    validate(need(length(rv$scenarios) >= 1,
                  "Save at least one group allocation first."))
    if (length(unique(vapply(rv$scenarios, function(x)
      paste(x$fleet_level, x$area_level), character(1)))) > 1)
      div(class = "note", style = "color:#9a5000",
          "Allocations use different levels of detail, so only the keys ",
          "they share can be compared.") else NULL })

  output$rule_dr_ui <- renderUI({
    top <- dr_top("mg")
    sliderInput("rule_dr", NULL, 0, top, c(0, top), 0.01) })

  rule_dr <- reactive({
    if (!isTRUE(input$dr_on)) return(c(NA, NA))
    v <- input$rule_dr; if (is.null(v)) return(c(NA, NA))
    top <- dr_top("mg")
    c(if (v[1] > 0) v[1] else NA, if (v[2] < top) v[2] else NA) })

  # the comparison chips speak in DIM labels (Fleet, Area, ...); the runs
  # are keyed by the resolved columns. Translate through the level actually
  # used, falling back to the canonical default for each dimension.
  cmp_col <- function(dim_label) {
    if (is.null(dim_label) || !nzchar(dim_label)) return(NULL)
    def <- c(Fleet = "metier4", Area = "ICESDivision", Season = "Season",
             Country = "Country")
    col <- unname(def[dim_label])
    if (is.na(col)) col <- dim_label
    if (col %in% cmp_keys()) col else NULL
  }

  cmp <- reactive({
    x <- cmp_col(input$cmp_x)
    req(!is.null(x))
    keys <- unique(c(x, cmp_col(input$cmp_facet)))
    compare_scenarios(runs(), keys) })

  cmp_sig <- reactive(list(input$cmp_x, input$cmp_facet,
                           input$cmp_fleet, input$cmp_area))
  cmp_g <- gate_of("cmp", cmp_sig, refresh = reactive(rv$scenarios))

  cmp_plot_obj <- gated(cmp_g, {
    x <- cmp_col(input$cmp_x); req(!is.null(x))
    plot_comparison(cmp(), x, cmp_col(input$cmp_facet)) })

  output$cmp_plot <- renderPlot({
    validate(need(length(rv$scenarios) >= 1, "Save or load at least one group allocation."),
             need(isTruthy(input$cmp_x), "Pick an X axis from the chips."))
    p <- cmp_plot_obj()
    validate(need(!is.null(p), "Nothing to plot."))
    p + theme(legend.position = "none") })

  output$cmp_legend <- renderPlot({
    validate(need(length(rv$scenarios) >= 1, ""), need(isTruthy(input$cmp_x), ""))
    p <- cmp_plot_obj(); validate(need(!is.null(p), ""))
    draw_legend(p) }, bg = "transparent")

  keep_plot("cmp_plot", cmp_plot_obj, gate = cmp_g,
    section = "output",
    title = "Allocation comparison",
    note = function() sprintf("across %s saved allocation(s)",
                              length(rv$scenarios)),
    prep = function() c(
      "## compare_scenarios() needs the raised runs; re-run the allocations",
      "## in model_allocate_raise_discards.R and collect them into `runs`",
      sprintf("cmp <- compare_scenarios(runs, %s)",
              fmt_vals(unique(c(cmp_col(input$cmp_x),
                                cmp_col(input$cmp_facet)))))),
    call = function() taf_call("plot_comparison", list(
      "cmp", taf_q(cmp_col(input$cmp_x)), taf_q(cmp_col(input$cmp_facet)))))

  output$cmp_tbl <- renderDT({
    validate(need(length(rv$scenarios) >= 1, "Save or load at least one group allocation."))
    x <- cmp_col(input$cmp_x); validate(need(!is.null(x), "Pick an X axis."))
    keys <- unique(c(x, cmp_col(input$cmp_facet)))
    datatable(comparison_table(cmp(), keys),
              options = list(scrollX = TRUE, pageLength = 15), rownames = FALSE) })

  # --- 9. code ---------------------------------------------
  code_lines <- reactive({
    out <- character(0)
    if ("head" %in% input$code_parts)
      out <- c(out, emit_header(if (is.null(input$file)) "(none)" else input$file$name,
                                input$stock, nrow(dat())))
    if ("derive" %in% input$code_parts)
      out <- c(out,
        emit_load_code(if (is.null(input$file)) "catch_data.csv" else input$file$name,
                       input$sep),
        c(emit_area_helper(), emit_derive_code()),
        emit_filter_code(input$stock, input$year, unname(dmap("ar")[DIMS]),
                         ar_dr()[1], ar_dr()[2]))
    if ("auto" %in% input$code_parts)
      out <- c(out, emit_hier_code(rec(), hier_cols(), hier_thr(),
                                   "fine_to_coarse", unname(dmap("ar")[DIMS])))
    if ("manual" %in% input$code_parts && length(rv$rules) >= 1)
      out <- c(out, emit_rules_code(rv$rules, rv$sets,
                                    unname(dmap("mg")[DIMS])))
    out })

  # Fragments and the live script are the same text; the checkboxes only
  # choose which blocks are shown, never a different rendering.
  output$code_txt <- renderText({
    keep <- input$code_parts %||% LOG_ORDER
    map <- c(head = "header", derive = "load_cef", auto = "auto_raising",
             manual = "auto_raising")
    ids <- unique(c("header", "setup", unname(map[keep]), "load_cef",
                    "strata", "explore", "auto_raising", "session"))
    lg <- rv$log; lg$blocks <- lg$blocks[intersect(names(lg$blocks), ids)]
    paste(log_render(lg), collapse = "\n") })

  # =========================================================
  #  SECTION 3 - Apply raising through catchRaising()
  # =========================================================
  nr_conds <- reactive({
    if (identical(input$nr_source, "manual")) {
      req(length(rv$rules) >= 1)
      conds_from_rules(rv$rules, rv$sets)
    } else conds_from_auto(rec())
  })

  output$nr_conds <- renderText({
    cd <- tryCatch(nr_conds(), error = function(e) NULL)
    if (is.null(cd)) return("Define groups first.")
    paste(c("strataCond:",
            paste0("  ", names(cd$strataCond), " = ",
                   vapply(cd$strataCond, rlang::quo_text, character(1))),
            "", "matchedDataCond:",
            paste0("  ", names(cd$matchedDataCond), " = ",
                   vapply(cd$matchedDataCond, rlang::quo_text, character(1)))),
          collapse = "\n") })

  output$nr_status <- renderUI({
    ck <- cef_check(dat())
    if (!EXT_STATUS$raising)
      return(div(class = "chain", style = "color:#7a1f1f",
        tags$b("catchRaising() is not loaded."),
        " Point the external script folder at 0_Functions_discards_raising.R ",
        "and 0_Functions_other.R. The code is still written to the R script."))
    if (!ck$ok)
      return(div(class = "chain", style = "color:#9a5000",
        tags$b("The CEF table is missing columns catchRaising() needs: "),
        paste(ck$missing, collapse = ", "),
        tags$br(), "A table converted in section 1 will have them."))
    div(class = "chain", style = "color:#14532d",
        "Ready: CEF table has every column catchRaising() needs.") })

  observeEvent(input$run_native, {
    r <- with_busy("Raising discards...", tryCatch(run_native_raising(
      dat(), unname(dmap("nr")[DIMS]), nr_conds(),
      type = input$nr_type, originType = input$nr_origin,
      variableType = input$nr_vartype,
      log_file = if (nzchar(input$nr_log %||% "")) input$nr_log else NULL,
      assembled_output = isTRUE(input$nr_assembled)),
      error = function(e) e))
    if (inherits(r, "error")) {
      rv$native <- NULL
      showNotification(paste("Raising failed:", conditionMessage(r)),
                       type = "error", duration = 10)
    } else {
      rv$native <- r
      showNotification(sprintf("Raised: %s rows", nrow(r)),
                       type = "message", duration = 4)
    } })

  output$nr_tbl <- renderDT({
    validate(need(!is.null(rv$native), "Run the raising to see the result."))
    datatable(head(rv$native, 500), options = list(scrollX = TRUE, pageLength = 10),
              rownames = FALSE) })

  output$nr_grp <- renderDT({
    validate(need(!is.null(rv$native), "Run the raising to see the result."))
    datatable(native_summary(rv$native, unname(dmap("nr")[DIMS])),
              options = list(scrollX = TRUE), rownames = FALSE) })

  # group allocations, listed in a small box like the level-of-detail one
  output$alloc_box <- renderUI({
    n <- length(rv$scenarios)
    div(class = "allocbox",
      div(class = "alloctitle", sprintf("Group allocations (%s)", n)),
      if (!n) div(class = "note", "None saved yet.")
      else tagList(lapply(names(rv$scenarios), function(k) {
        s <- rv$scenarios[[k]]
        div(style = "font-size:11px;margin:3px 0;padding:3px 5px;
                     border-left:4px solid #59A14F;background:#fff;
                     border-radius:3px",
            tags$b(k), tags$br(),
            tags$span(style = "color:#555",
              if (s$method == "auto")
                sprintf("auto | %s | %s%%", paste(s$hierarchy, collapse = ">"),
                        paste(s$thresholds, collapse = "/"))
              else sprintf("manual | %s groups", length(s$rules))))
      }))) })

  # the plots actually on screen, as code
  active_plots <- reactive({
    r <- function(v) if (is.null(v) || !nzchar(v)) "NULL" else sprintf('"%s"', v)
    list(
      sprintf('plot_discard_rate(strata, type = "raw", x = %s, colour = %s, shape = %s, facet = %s)',
              r(role("dr","x")), r(role("dr","fill")),
              r(role("dr","shape")), r(role("dr","facet"))),
      sprintf('plot_discard_rate(strata, type = "box", x = %s, fill = %s, facet = %s)',
              r(col_of("dr", input$box_x)), r(col_of("dr", input$box_fill)),
              r(col_of("dr", input$box_facet))),
      sprintf('plot_coverage(classify_strata(strata, %s), type = "heatmap", y = %s, fill = %s, facet = %s, threshold = %s)',
              input$threshold %||% 50, r(col_of("hm", input$hm_y)),
              r(col_of("hm", input$hm_x)), r(col_of("hm", input$hm_facet)),
              input$threshold %||% 50),
      sprintf('plot_coverage(classify_strata(strata, %s), type = "bars", y = %s, fill = %s, facet = %s)',
              input$threshold %||% 50, r(col_of("cb", input$cb_y)),
              r(col_of("cb", input$cb_fill)), r(col_of("cb", input$cb_facet)))) })

  # =========================================================
  #  Merged coverage plot (heatmap / bubbles / bars share one menu)
  # =========================================================
  cov_sc <- reactive({
    req(isTruthy(input$cov_y))
    classify_strata(strata_roles("cov", c(input$cov_y, input$cov_fill,
                                          input$cov_facet)), input$threshold) })

  # A heatmap or a bubble grid needs two axes. With X / Fill on (none)
  # there is nothing to put on the x axis, so those two icons are greyed
  # out and only Bars stays clickable.
  cov_type_off <- reactive(
    if (isTruthy(input$cov_fill)) character(0) else c("heatmap", "bubbles"))

  # the type actually drawn: falls back to bars when the chosen type needs
  # an x axis that is no longer set
  cov_type_eff <- reactive({
    ty <- input$cov_type %||% "heatmap"
    if (ty %in% cov_type_off()) "bars" else ty })

  output$cov_type_bar <- renderUI(
    pick_bar("cov_type",
             list(heatmap = "Heatmap", bubbles = "Bubbles", bars = "Bars"),
             cov_type_eff(), disabled = cov_type_off()))

  # build once; the main panel shows it with no legend, the legend is drawn
  # separately beside the plot-type icons
  # input$cov_type is deliberately absent from the signature: switching
  # heatmap/bubbles/bars is a different view of the same configuration, not
  # a reconfiguration, so it goes through as `live` and redraws at once.
  cov_sig <- reactive(list(input$cov_y, input$cov_fill, input$cov_facet,
                           input$threshold, input$cov_fleet, input$cov_area))
  cov_live <- reactive(input$cov_type)
  cov_g <- gate_of("cov", cov_sig, live = cov_live)

  cov_plot_obj <- gated(cov_g, {
    y <- col_of("cov", input$cov_y); f <- col_of("cov", input$cov_fill)
    fc <- col_of("cov", input$cov_facet)
    plot_coverage(cov_sc(), type = cov_type_eff(), y = y, fill = f,
                  facet = fc, threshold = input$threshold, what = "discard") },
    live = cov_live)

  output$cov_plot_ui <- renderUI({
    cov_g$now(); cov_live()
    plotOutput("cov_plot",
               height = paste0(isolate(hgt("cov", input$cov_facet, 16)), "px")) })

  output$cov_plot <- renderPlot({
    p <- cov_plot_obj()
    validate(need(!is.null(p), "Nothing to plot."))
    p + theme(legend.position = "none") })

  output$cov_legend <- renderPlot({
    p <- cov_plot_obj(); validate(need(!is.null(p), ""))
    draw_legend(p) }, bg = "transparent")

  keep_plot("cov_plot", cov_plot_obj, gate = cov_g,
    section = "model_explore_discards",
    title = function() sprintf("Discard coverage - %s", cov_type_eff()),
    note = function() sprintf("threshold %s%%; fleet = %s, area = %s",
      input$threshold %||% 50, unname(dmap("cov")["Fleet"]),
      unname(dmap("cov")["Area"])),
    # strata_discards comes off disk from the model stage, but it was built
    # at that stage's level of detail; re-deriving it here keeps the plot
    # honest when the coverage tab was looking at a different resolution
    prep = function() c(
      sprintf("strata_cov <- classify_strata(build_strata(catch_data, %s), %s)",
              fmt_vals(unname(dmap("cov")[DIMS])), input$threshold %||% 50)),
    call = function() taf_call("plot_coverage", list(
      "strata_cov", type = taf_q(cov_type_eff()),
      y = taf_q(col_of("cov", input$cov_y)),
      fill = taf_q(col_of("cov", input$cov_fill)),
      facet = taf_q(col_of("cov", input$cov_facet)),
      threshold = input$threshold %||% 50, what = '"discard"')))

  # merged discard-rate plot
  # same for the raw/boxplot toggle
  dr_sig <- reactive(list(input$dr_x, input$dr_fill,
                          input$dr_shape, input$dr_facet, input$dr_jitter,
                          input$box_x, input$box_fill, input$box_facet,
                          input$box_points, input$box_pooled,
                          input$dr_fleet, input$dr_area))
  dr_live <- reactive(input$dr_type)
  dr_g <- gate_of("dr", dr_sig, live = dr_live)

  dr_plot_obj <- gated(dr_g, {
    if (identical(input$dr_type, "box")) {
      req(isTruthy(input$box_x))
      plot_discard_rate(strata_p("dr"), type = "box",
                  x = col_of("dr", input$box_x),
                  fill = col_of("dr", input$box_fill),
                  facet = col_of("dr", input$box_facet),
                  show_points = input$box_points, show_pooled = input$box_pooled)
    } else
      plot_discard_rate(strata_p("dr"), type = "raw",
                  x = role("dr","x"), colour = role("dr","fill"),
                  shape = role("dr","shape"), facet = role("dr","facet"),
                  jitter = input$dr_jitter) },
    live = dr_live)

  output$dr_plot_ui <- renderUI({
    dr_g$now(); dr_live()
    plotOutput("dr_plot", height = paste0(isolate(
      hgt("dr", if (identical(input$dr_type, "box")) input$box_facet
                else input$dr_facet)), "px")) })

  output$dr_plot <- renderPlot({
    p <- dr_plot_obj()
    validate(need(!is.null(p), "No strata with discard data."))
    p + theme(legend.position = "none") })

  output$dr_legend <- renderPlot({
    p <- dr_plot_obj(); validate(need(!is.null(p), ""))
    draw_legend(p) }, bg = "transparent")

  keep_plot("dr_plot", dr_plot_obj, gate = dr_g,
    section = "model_explore_discards",
    title = function() sprintf("Discard rate - %s",
      if (identical(input$dr_type, "box")) "boxplot" else "per stratum"),
    note = function() sprintf("fleet = %s, area = %s",
      unname(dmap("dr")["Fleet"]), unname(dmap("dr")["Area"])),
    prep = function()
      sprintf("strata_dr <- build_strata(catch_data, %s)",
              fmt_vals(unname(dmap("dr")[DIMS]))),
    call = function() if (identical(input$dr_type, "box"))
      taf_call("plot_discard_rate", list(
        "strata_dr", type = '"box"', x = taf_q(col_of("dr", input$box_x)),
        fill = taf_q(col_of("dr", input$box_fill)),
        facet = taf_q(col_of("dr", input$box_facet)),
        show_points = if (isTRUE(input$box_points)) "TRUE" else "FALSE",
        show_pooled = if (isTRUE(input$box_pooled)) "TRUE" else "FALSE"))
    else taf_call("plot_discard_rate", list(
        "strata_dr", type = '"raw"', x = taf_q(role("dr", "x")),
        colour = taf_q(role("dr", "fill")), shape = taf_q(role("dr", "shape")),
        facet = taf_q(role("dr", "facet")),
        jitter = if (isTRUE(input$dr_jitter)) "TRUE" else "FALSE")))

  # =========================================================
  #  CEF database call (framework only)
  #  db_fetch_cef() is the single seam where the real database call
  #  will go. Everything around it - credentials, the request form, the
  #  busy overlay, and the Result view - is wired, so only this function
  #  body needs filling in. When implemented it should return a list with
  #  $catches / $distributions / $effort, which flow into the same slots
  #  the CEF folder loader fills.
  # =========================================================
  db_fetch_cef <- function(user, pass, stock, year, tables) {
    stop("The CEF database call is not implemented yet.")
  }

  observeEvent(input$db_connect, {
    rv$db_auth <- list(user = input$db_user %||% "",
                       ok = nzchar(input$db_user %||% ""))
    showNotification(
      if (isTRUE(rv$db_auth$ok)) "Credentials captured." else "Enter a username.",
      type = if (isTRUE(rv$db_auth$ok)) "message" else "warning", duration = 3) })

  output$db_cred_status <- renderUI({
    a <- rv$db_auth
    if (is.null(a))
      return(div(class = "note",
                 "Enter your database username and password, then Connect."))
    div(class = "chain",
        style = if (isTRUE(a$ok)) "color:#14532d" else "color:#9a5000",
        if (isTRUE(a$ok))
          sprintf("Connected as '%s'. Move on to the Request tab.", a$user)
        else "No username entered yet.") })

  do_db_load <- function() {
    tables <- c(if (isTRUE(input$db_cn)) "CN",
                if (isTRUE(input$db_dn)) "DN",
                if (isTRUE(input$db_en)) "EN")
    if (!length(tables)) {
      showNotification("Tick at least one CEF table (CN, DN or EN).",
                       type = "warning", duration = 5); return() }
    r <- with_busy("Requesting data from the CEF database...",
      tryCatch(db_fetch_cef(input$db_user, input$db_pass, input$db_stock,
                            input$db_year, tables),
               error = function(e) e))
    if (inherits(r, "error")) {
      rv$db_err <- conditionMessage(r)
      showNotification(paste("Request failed:", conditionMessage(r)),
                       type = "error", duration = 10)
    } else {
      rv$cef_catches <- r$catches; rv$dist <- r$distributions
      rv$eff <- r$effort; rv$db_err <- NULL
      rv$cef_files <- NULL
      showNotification("Data received from the CEF database.",
                       type = "message", duration = 4)
    }
    invisible(NULL)
  }

  observeEvent(input$db_request, with_load_guard("rdbes", do_db_load))

  output$db_request_status <- renderUI({
    if (!is.null(rv$db_err))
      return(div(class = "chain", style = "color:#7a1f1f",
                 tags$b("Request failed:"), tags$br(), rv$db_err,
                 tags$br(), tags$br(),
                 tags$span(class = "note",
                   "The database call itself is not built yet - this is the ",
                   "framework around it. Fill in db_fetch_cef() to enable it.")))
    div(class = "note",
        "Set the stock, year and tables, then Request. Results appear on the ",
        "Result tab and feed the rest of the workbench.") })

  # =========================================================
  #  CEF result views (same code for both entry points)
  # =========================================================
  cef_tables <- function(src) {
    if (src == "ic") list(catches = rv$ic$catches,
                          distributions = rv$ic$distributions,
                          effort = rv$ic$effort)
    else list(catches = tryCatch(dat(), error = function(e) NULL),
              distributions = rv$dist, effort = rv$eff)
  }

  local({
    # "db" reuses the same tables slots as the CEF folder loader, so the
    # else branch of cef_tables() covers it once the fetch is implemented
    for (src in c("ic", "cef", "db")) local({
      sc <- src
      ns <- function(x) paste0(sc, "_", x)
      dt <- function(d, ...) datatable(d, rownames = FALSE,
        options = list(scrollX = TRUE, dom = "t", pageLength = 25), ...)

      output[[ns("cat_sum")]] <- renderDT({
        t <- cef_tables(sc)$catches
        validate(need(!is.null(t) && nrow(t), "No catches table yet."))
        dt(catches_summary(t), colnames = c("", "")) })
      output[[ns("cat_cat")]] <- renderDT({
        t <- cef_tables(sc)$catches
        validate(need(!is.null(t) && nrow(t), "No catches table yet."))
        dt(catches_by_category(t)) })
      output[[ns("cat_prev")]] <- renderDT({
        t <- cef_tables(sc)$catches
        validate(need(!is.null(t) && nrow(t), "No catches table yet."))
        datatable(head(t, 200), rownames = FALSE,
                  options = list(scrollX = TRUE, pageLength = 8)) })

      output[[ns("dist_sum")]] <- renderDT({
        t <- cef_tables(sc)
        validate(need(!is.null(t$distributions) && nrow(t$distributions),
                      "No distributions table loaded."))
        dt(distributions_summary(t$distributions, t$catches), colnames = c("","")) })
      output[[ns("dist_type")]] <- renderDT({
        t <- cef_tables(sc)$distributions
        validate(need(!is.null(t) && nrow(t), "No distributions table loaded."))
        dt(distributions_by_type(t)) })
      output[[ns("bio_cov")]] <- renderDT({
        t <- cef_tables(sc)
        validate(need(!is.null(t$catches) && nrow(t$catches), "No catches table."))
        d <- derive_fields(as.data.frame(t$catches))
        dim1 <- unname(dmap("dt")[input[[ns("bio_dim")]] %||% "Fleet"])
        b <- biology_coverage(d, t$distributions, dim1) %>%
          mutate(across(where(is.numeric), ~round(.x, 3)))
        datatable(b, rownames = FALSE,
                  options = list(scrollX = TRUE, pageLength = 10)) })
      output[[ns("dist_prev")]] <- renderDT({
        t <- cef_tables(sc)$distributions
        validate(need(!is.null(t) && nrow(t), "No distributions table loaded."))
        datatable(head(t, 200), rownames = FALSE,
                  options = list(scrollX = TRUE, pageLength = 8)) })

      output[[ns("eff_sum")]] <- renderDT({
        t <- cef_tables(sc)$effort
        validate(need(!is.null(t) && nrow(t), "No effort table loaded."))
        dt(effort_summary(t), colnames = c("", "")) })
      output[[ns("eff_prev")]] <- renderDT({
        t <- cef_tables(sc)$effort
        validate(need(!is.null(t) && nrow(t), "No effort table loaded."))
        datatable(head(t, 200), rownames = FALSE,
                  options = list(scrollX = TRUE, pageLength = 8)) })
    })
  })

  # extra CEF uploads
  output$cef_dist_input <- renderUI({
    needBio <- any(c("lengths", "ages") %in% cfg$need)
    tagList(
      fileInput("file_dist",
                if (needBio) "distributions" else "distributions (optional)",
                accept = c(".csv", ".txt")),
      if (!needBio)
        div(class = "note",
            "Not required for this run, but you can still load it to explore ",
            "the length or age sampling.") else NULL) })

  rv_read <- function(f) if (is.null(f)) NULL else
    read.csv(f$datapath, sep = input$sep %||% ",", stringsAsFactors = FALSE)

  # Uploading CEF tables by hand is the CEF route by another door, so it
  # claims ownership the same way the folder loader does. The catches file
  # is what defines the dataset, so that is the upload that triggers the
  # guard; the two companions just fill their slots.
  observeEvent(input$file, with_load_guard("cef", function() {
    rv$cef_files <- list(dir = ".", catches = input$file$name,
                         distributions = NA_character_, effort = NA_character_)
    invisible(NULL) }), ignoreInit = TRUE)

  observe({
    rv$dist <- rv_read(input$file_dist)
    if (!is.null(input$file_dist) && !is.null(rv$cef_files))
      rv$cef_files$distributions <- input$file_dist$name })
  observe({
    rv$eff <- rv_read(input$file_eff)
    if (!is.null(input$file_eff) && !is.null(rv$cef_files))
      rv$cef_files$effort <- input$file_eff$name })

  output$cef_file_check <- renderUI({
    row <- function(lbl, ok, req) div(style = sprintf("color:%s;font-size:12px",
      if (!req) "#8a8a8a" else if (ok) "#14532d" else "#7a1f1f"),
      HTML(sprintf("%s %s", if (!req) "&#8211;" else if (ok) "&#10003;" else
        "&#10007;", lbl)))
    needBio <- any(c("lengths","ages") %in% cfg$need)
    div(class = "chain",
        row("catches", !is.null(input$file) || !is.null(rv$ic$catches), TRUE),
        row("distributions", !is.null(rv$dist), needBio),
        row("effort (optional)", !is.null(rv$eff), FALSE)) })

  # =========================================================
  #  Final raising
  # =========================================================
  observe(updateSelectInput(session, "final_alloc", choices = names(rv$scenarios)))

  observeEvent(input$run_final, {
    req(isTruthy(input$final_alloc))
    sc <- rv$scenarios[[input$final_alloc]]
    conds <- if (sc$method == "auto") {
      st <- flag_donor_exclusion(build_strata(dat(), sc$dims),
                                 sc$dr_min %||% NA, sc$dr_max %||% NA)
      conds_from_auto(recommend_raising(st, sc$hierarchy, sc$thresholds,
        self_threshold = sc$self_threshold %||% NA,
        mode = sc$mode %||% "nested", dims = sc$dims))
    } else conds_from_rules(sc$rules, sc$sets %||% list())
    r <- with_busy(sprintf("Raising with '%s'...", input$final_alloc),
      tryCatch(run_native_raising(dat(), sc$dims, conds,
      type = input$nr_type %||% "discards",
      originType = input$nr_origin %||% "WGEstimate",
      variableType = input$nr_vartype %||% "WeightLive",
      log_file = if (nzchar(input$nr_log %||% "")) input$nr_log else NULL),
      error = function(e) e))
    if (inherits(r, "error")) {
      rv$final <- NULL
      showNotification(paste("Raising failed:", conditionMessage(r)),
                       type = "error", duration = 10)
    } else {
      rv$final <- r
      showNotification(sprintf("Raised with '%s': %s rows",
                               input$final_alloc, nrow(r)), duration = 4)
    } })

  output$final_status <- renderUI({
    if (is.null(rv$final))
      return(div(class = "note", "Pick an allocation and run the raising."))
    div(class = "chain", style = "color:#14532d",
        sprintf("Adopted: %s | %s rows | this is the allocation the script records as final.",
                input$final_alloc, format(nrow(rv$final), big.mark = ","))) })

  fin_d <- reactive({ req(!is.null(rv$final)); derive_fields(rv$final) })

  output$fin_plot_ui <- renderUI(plotOutput("fin_plot", height = paste0(
    plot_height(if (is.null(rv$final)) NULL else fin_d(),
                col_of("nr", input$fin_facet), 12), "px")))

  fin_sig <- reactive(list(input$fin_x, input$fin_facet,
                           input$nr_fleet, input$nr_area))
  fin_g <- gate_of("fin", fin_sig, refresh = reactive(rv$final))

  fin_plot_obj <- gated(fin_g, {
    validate(need(!is.null(rv$final), "Run the raising first."))
    plot_raised_composition(fin_d(), col_of("nr", input$fin_x),
                            col_of("nr", input$fin_facet)) })

  output$fin_plot <- renderPlot({
    p <- fin_plot_obj()
    validate(need(!is.null(p), "Nothing to plot.")); p })

  keep_plot("fin_plot", fin_plot_obj, gate = fin_g,
    section = "output",
    title = "Raised catch composition",
    note = function() sprintf("adopted allocation: %s",
                              input$final_alloc %||% "(none)"),
    prep = "d_fin <- derive_fields(catch_data_raised)",
    call = function() taf_call("plot_raised_composition", list(
      "d_fin", taf_q(col_of("nr", input$fin_x)),
      taf_q(col_of("nr", input$fin_facet)))))

  output$fin_overview <- renderDT({
    validate(need(!is.null(rv$final), "Run the raising first."))
    datatable(raised_overview_table(rv$final), rownames = FALSE,
              options = list(dom = "t", scrollX = TRUE)) })

  output$fin_crosstab <- renderDT({
    validate(need(!is.null(rv$final), "Run the raising first."))
    datatable(raised_crosstab(fin_d(), col_of("nr", input$fin_row),
                              col_of("nr", input$fin_col)),
              rownames = FALSE, options = list(dom = "t", scrollX = TRUE)) })

  # =========================================================
  #  The analysis, as code
  # =========================================================
  # The grouping and raising code is wanted in two places at once: the
  # running log on the Fragments tab, and model_allocate_raise_discards.R
  # in the TAF set. Building it once and reading it from both is what stops
  # the two drifting into telling different stories about the same session.
  raise_code <- reactive(tryCatch({
      out <- character(0)
      emitted <- character(0)

      # (1) live auto cascade - always, so the exploration is reproducible
      live_auto <- tryCatch({
        code_auto_rule("live_auto", unname(dmap("ar")[DIMS]),
                       hier_cols(), hier_thr(),
                       self_thr_val(),
                       input$hier_mode %||% "nested",
                       ar_dr()[1], ar_dr()[2])
      }, error = function(e) NULL)
      if (!is.null(live_auto)) {
        out <- c(out, "## ===== Live automatic allocation (as configured now) =====",
                 live_auto,
                 code_raise("live_auto", unname(dmap("ar")[DIMS]),
                            input$nr_type %||% "discards",
                            input$nr_origin %||% "WGEstimate",
                            input$nr_vartype %||% "WeightLive",
                            input$nr_log %||% "Log.txt"))
        emitted <- c(emitted, "live_auto")
      }

      # (1b) live manual groups, if any are defined
      if (length(rv$rules) >= 1) {
        out <- c(out, "## ===== Live manual allocation (as configured now) =====",
                 code_manual_rule("live_manual", unname(dmap("mg")[DIMS]),
                                  rv$rules, rv$sets %||% list()),
                 code_raise("live_manual", unname(dmap("mg")[DIMS]),
                            input$nr_type %||% "discards",
                            input$nr_origin %||% "WGEstimate",
                            input$nr_vartype %||% "WeightLive",
                            input$nr_log %||% "Log.txt"))
        emitted <- c(emitted, "live_manual")
      }

      # (2) each SAVED allocation
      for (nm in names(rv$scenarios)) {
        sc <- rv$scenarios[[nm]]
        out <- c(out,
          sprintf("## ===== Saved allocation '%s' =====", nm),
          if (sc$method == "auto")
            code_auto_rule(nm, sc$dims, sc$hierarchy, sc$thresholds,
                           sc$self_threshold %||% NA, sc$mode %||% "nested",
                           sc$dr_min %||% NA, sc$dr_max %||% NA)
          else code_manual_rule(nm, sc$dims, sc$rules, sc$sets %||% list()),
          code_raise(nm, sc$dims, input$nr_type %||% "discards",
                     input$nr_origin %||% "WGEstimate",
                     input$nr_vartype %||% "WeightLive",
                     input$nr_log %||% "Log.txt"))
        emitted <- c(emitted, nm)
      }

      # (3) and (4) are returned SEPARATELY rather than glued onto `out`,
      # because the TAF split puts them in the same file but the running
      # log wants them in a fixed order, and appending them here as well
      # would print each of them twice.
      final <- if (isTruthy(input$final_alloc)) input$final_alloc
               else if (length(emitted)) emitted[1] else NULL

      # The length/age allocation used to be tacked onto the end of this
      # block. It now has its own script (model_allocate_length_age.R),
      # because it runs on the RAISED catches this block produces and that
      # dependency is worth making visible.
      list(groups = out, emitted = emitted,
           compare = if (length(emitted) > 1) code_compare(emitted) else NULL,
           final = if (!is.null(final)) code_final(final) else NULL)
    }, error = function(e)
      list(groups = c("## the raising code could not be generated:",
                      paste0("##   ", conditionMessage(e))),
           emitted = character(0), compare = NULL, final = NULL)))

  # The length/age allocations, per store. Emitted per saved allocation so
  # a session that tried three groupings leaves all three in the script,
  # with the aggregation that followed each.
  bio_alloc_code <- function(store, type, tag, pfx, obj) {
    allocs <- rv[[store]] %||% list()
    if (!length(allocs)) return(NULL)
    unlist(lapply(names(allocs), function(nm) c(
      sprintf("## --- allocation '%s' (%s) ---", nm,
              allocs[[nm]]$method %||% "hierarchical"),
      emit_alloc_grouping_code(allocs[[nm]]$spec,
                               allocs[[nm]]$method %||% "hierarchical", tag),
      "",
      emit_alloc_code(allocs[[nm]]$groups, type,
                      input[[paste0(pfx, "_rz_origin")]] %||% "WGEstimate",
                      input[[paste0(pfx, "_rz_vartype")]] %||% "WeightLive"),
      "",
      emit_alloc_agg_code(tag),
      "",
      sprintf("%s <- alloc_res", obj),
      sprintf('write.csv(numbers_at, "model/numbers_at_%s.csv", row.names = FALSE)',
              tolower(tag)),
      "")), use.names = FALSE)
  }

  # The two sufficiency thresholds of a biology module, addressed the same
  # way the module itself addresses them.
  bio_thr <- function(p, which, default)
    input[[paste0(p, "_thr_", which)]] %||% default

  # The load block for data.R - ONE route, the one that owns the data.
  # Emitting all four with three commented out would leave the reader
  # guessing which one ran, and a stock whose provenance is a guess is a
  # stock whose numbers cannot be defended.
  taf_load_lines <- reactive({
    m <- rv$load_method
    sep_txt <- switch(input$sep %||% ",", "," = '","', ";" = '";"',
                      "\t" = '"\\t"', '","')
    if (is.null(m))
      return(c("## No input route has been completed yet. Load the data in the",
               "## workbench and this block will describe the route you used.",
               ""))
    if (m %in% c("ic_exchange", "ic_output")) {
      i <- tryCatch(ic_inputs(), error = function(e) NULL)
      if (is.null(i)) return(c("## InterCatch conversion settings unavailable.", ""))
      return(c(
        sprintf("## ---- Input route: %s ----", TAF_METHOD_LABEL[[m]]),
        "## The conversion IS the data step: the CEF tables this workflow",
        "## runs on do not exist until it has run, so it belongs here and",
        "## not in a preparatory script somebody has to remember to run.",
        ic_code(i),
        "distributions <- res$distributions",
        "effort        <- res$effort",
        ""))
    }
    if (identical(m, "rdbes")) {
      return(c(
        sprintf("## ---- Input route: %s ----", TAF_METHOD_LABEL[[m]]),
        "## The workbench holds the framework for this call; the fetch",
        "## itself is not implemented yet. Replace db_fetch_cef() with your",
        "## own query and the rest of the set runs unchanged.",
        sprintf('cef <- db_fetch_cef(stock = "%s", year = %s,',
                input$db_stock %||% (cfg$stock %||% ""),
                input$db_year %||% (cfg$year %||% "NA")),
        sprintf("                    tables = %s)",
                fmt_vals(c(if (isTRUE(input$db_cn)) "CN",
                           if (isTRUE(input$db_dn)) "DN",
                           if (isTRUE(input$db_en)) "EN"))),
        "catch_data    <- cef$catches",
        "distributions <- cef$distributions",
        "effort        <- cef$effort",
        ""))
    }
    # CEF files: name the files that were actually read, rather than making
    # the reader re-run the app's name matching on their own machine
    f <- rv$cef_files %||% list(dir = ".", catches = "catches.csv",
                                distributions = NA_character_,
                                effort = NA_character_)
    rd <- function(obj, nm, required) {
      if (is.na(nm %||% NA))
        return(sprintf("## %s: no file was matched in the session", obj))
      sprintf('%s <- read.csv(file.path(cefPath, "%s"), sep = %s, stringsAsFactors = FALSE)',
              obj, nm, sep_txt)
    }
    c(sprintf("## ---- Input route: %s ----", TAF_METHOD_LABEL[["cef"]]),
      "## All three CEF tables, read as they were read in the session.",
      sprintf('cefPath <- "%s"', f$dir %||% "."),
      rd("catch_data", f$catches, TRUE),
      rd("distributions", f$distributions, FALSE),
      rd("effort", f$effort, FALSE),
      "")
  })

  # Everything the TAF emitters need, in one place. Assembled defensively:
  # a half-configured session should still produce a readable script set
  # rather than a blank tab.
  taf_ctx <- reactive({
    rc <- raise_code()
    tc <- function(x) tryCatch(x, error = function(e) NULL)
    list(
      external_dir = EXT$dir,
      load_method = rv$load_method,
      input_desc = {
        f <- rv$cef_files
        if (!is.null(f) && !is.null(f$catches))
          file.path(f$dir %||% ".", f$catches)
        else TAF_METHOD_LABEL[[rv$load_method %||% "cef"]] %||% "the input files"
      },
      # one route, and derive_fields() from the package rather than a
      # hand-rolled copy of the area splitter written into the script
      load_lines = tc(taf_load_lines()),
      stock = cfg$stock %||% input$stock, year = cfg$year %||% input$year,
      dims_disc   = tc(unname(dmap("ar")[DIMS])),
      fleet_level = tc(unname(dmap("ar")["Fleet"])),
      area_level  = tc(unname(dmap("ar")["Area"])),
      threshold   = input$threshold %||% 50,
      dr_min = tc(ar_dr()[1]), dr_max = tc(ar_dr()[2]),
      group_lines = rc$groups, compare_lines = rc$compare,
      final_lines = rc$final,
      dims_len = tc(unique(c("catchCategory", unname(dmap("len_lv")[DIMS])))),
      # read the way the modules write them - threshold_box() is called as
      # threshold_box(paste0(p, "_thr_cov"), ...), so the id only exists as
      # a constructed string. Spelling it out literally here worked, but it
      # made two halves of one id that must agree look unrelated, and the
      # structural audit could no longer match them up.
      len_threshold = bio_thr("len", "cov", 50),
      len_min_meas  = bio_thr("len", "meas", 0),
      age_threshold = bio_thr("age", "cov", 50),
      age_min_meas  = bio_thr("age", "meas", 0),
      len_alloc_lines = tc(bio_alloc_code("len_allocs", "LengthTotal",
                                          "Length", "len", "alloc_length")),
      age_alloc_lines = tc(bio_alloc_code("age_allocs", "Age",
                                          "Age", "age", "alloc_age")))
  })

  # The seven scripts, rebuilt whenever anything they depend on moves.
  taf_files <- reactive(taf_bundle(taf_ctx(), rv$kept))

  # =========================================================
  #  Running R script + session state
  # =========================================================
  # There is no single script file any more, so the only path the session
  # still needs is the one the state JSON sits at, beside the seven scripts.
  state_path <- reactive(file.path(input$log_dir %||% ".",
                                   "session_state.json"))

  # every block re-derives itself, so the script always matches the app
  observe({
    lg <- log_new()
    lg <- log_set(lg, "header", code_header("the TAF script set"))
    lg <- log_set(lg, "setup", code_setup(EXT$dir))
    lg <- log_set(lg, "intercatch", tryCatch(ic_code(ic_inputs()), error = function(e) NULL))
    lg <- log_set(lg, "load_cef", tryCatch(c(
      emit_load_code(if (is.null(input$file)) "catch_data.csv" else input$file$name,
                     input$sep %||% ","),
      emit_derive_code()), error = function(e) NULL))
    lg <- log_set(lg, "strata", tryCatch(
      emit_filter_code(input$stock, input$year, unname(dmap("ar")[DIMS]),
                       ar_dr()[1], ar_dr()[2]), error = function(e) NULL))
    # The script must reproduce the WHOLE analysis, not only what was
    # saved. So it always writes:
    #   1. the allocation method(s) currently on screen (live), even if
    #      nothing was saved yet - the auto cascade as a RULE, the manual
    #      groups as explicit lists;
    #   2. every saved allocation, the same way;
    #   3. the comparison across them, if more than one exists;
    #   4. which allocation was adopted as final.
    lg <- log_set(lg, "auto_raising", tryCatch({
      rc <- raise_code()
      c(rc$groups, rc$compare, rc$final,
        if (length(rv$len_allocs)) c("## ===== Length allocation =====",
          bio_alloc_code("len_allocs", "LengthTotal", "Length", "len",
                         "alloc_length")),
        if (length(rv$age_allocs)) c("## ===== Age allocation =====",
          bio_alloc_code("age_allocs", "Age", "Age", "age", "alloc_age")))
      }, error = function(e) NULL))
    lg <- log_set(lg, "manual_groups", NULL)
    lg <- log_set(lg, "native_raising", NULL)
    lg <- log_set(lg, "explore", tryCatch(code_plots(active_plots()),
                                          error = function(e) NULL))
    lg <- log_set(lg, "session", code_session(state_path()))
    rv$log <- lg
  })

  # ---------------------------------------------------------
  #  The seven scripts: one view and one download each
  # ---------------------------------------------------------
  # Built in a loop rather than written out seven times: the parts are
  # already named in TAF_FILES, and hand-repeating them is exactly how a
  # tab ends up quietly rendering the wrong file.
  for (.pt in names(TAF_FILES)) local({
    pt <- .pt
    output[[paste0("taf_", pt, "_txt")]] <- renderText(
      paste(taf_files()[[pt]], collapse = "\n"))
    output[[paste0("dl_taf_", pt)]] <- downloadHandler(
      filename = function() TAF_FILES[[pt]],
      content  = function(f) writeLines(taf_files()[[pt]], f))
  })

  stock_slug <- reactive(taf_slug(cfg$stock %||% input$stock %||% "stock"))

  # the "full" view is the same seven files, concatenated in run order
  output$log_txt <- renderText(paste(taf_concat(taf_files()), collapse = "\n"))

  output$dl_taf_all <- downloadHandler(
    filename = function() sprintf("%s_taf.zip", stock_slug()),
    content  = function(f) taf_zip(taf_files(), names(TAF_FILES), f))

  output$dl_taf_sel <- downloadHandler(
    filename = function() sprintf("%s_taf_selected.zip", stock_slug()),
    content  = function(f)
      taf_zip(taf_files(), input$taf_parts %||% names(TAF_FILES), f))

  output$dl_log <- downloadHandler(
    filename = function() sprintf("%s_taf_all_in_one.R", stock_slug()),
    content  = function(f) writeLines(taf_concat(taf_files()), f))

  # Writing straight to a folder is off by default now: seven files landing
  # in the working directory on every slider move is not a courtesy.
  observe({
    req(isTRUE(input$log_auto))
    try(taf_write(taf_files(), input$log_dir %||% "."), silent = TRUE) })

  observeEvent(input$log_write_now, {
    r <- tryCatch(taf_write(taf_files(), input$log_dir %||% "."),
                  error = function(e) e)
    if (inherits(r, "error"))
      showNotification(paste("Could not write:", conditionMessage(r)),
                       type = "error", duration = 8)
    else
      showNotification(sprintf("Wrote %s scripts to %s", length(r),
                               normalizePath(input$log_dir %||% ".",
                                             mustWork = FALSE)),
                       type = "message", duration = 6) })

  # ---------------------------------------------------------
  #  The kept-plot list
  # ---------------------------------------------------------
  output$kept_list <- renderUI({
    if (!length(rv$kept))
      return(div(class = "note",
                 "Nothing kept yet. Press 'Keep for script' under any plot."))
    tagList(lapply(rv$kept, function(k)
      div(class = "keptrow",
          div(style = "flex:1",
              div(class = "ttl", k$title),
              div(class = "sub", sprintf("-> %s | kept %s%s",
                  TAF_FILES[[k$section %||% "output"]] %||% "output.R",
                  k$stamp %||% "?",
                  if (length(k$note)) paste0(" - ", k$note) else ""))),
          actionButton(paste0("kept_del_", k$uid), "remove",
                       class = "btn-xs btn-danger")))) })

  # Delete buttons are wired by UID, never by position. Wiring by position
  # is the classic version of this bug: remove the second of four and the
  # observers still point at the old indices, so the next click deletes
  # something the user did not choose.
  kept_env <- new.env(parent = emptyenv())
  observe({
    for (k in rv$kept) local({
      u  <- k$uid
      id <- paste0("kept_del_", u)
      if (!exists(id, envir = kept_env, inherits = FALSE))
        assign(id, observeEvent(input[[id]], {
          rv$kept <- Filter(function(z) !identical(z$uid, u), rv$kept)
        }, ignoreInit = TRUE), envir = kept_env)
    }) })

  observeEvent(input$kept_clear, {
    rv$kept <- list()
    showNotification("Cleared. output.R is empty again.", duration = 3) })

  output$dl_state <- downloadHandler(
    filename = function() "session_state.json",
    content = function(f) writeLines(state_to_json(state_capture(input, rv)), f))

  observeEvent(input$up_state, {
    req(input$up_state)
    st <- tryCatch(state_from_json(readLines(input$up_state$datapath, warn = FALSE)),
                   error = function(e) e)
    if (inherits(st, "error")) {
      showNotification(paste("Could not read state:", conditionMessage(st)),
                       type = "error", duration = 8); return()
    }
    if (!is.null(st$rules)) rv$rules <- st$rules
    if (!is.null(st$scenarios) && length(st$scenarios))
      rv$scenarios <- setNames(st$scenarios,
                               vapply(st$scenarios, `[[`, character(1), "name"))
    res <- state_apply(session, st)
    rv$restore <- res
    showNotification(sprintf("Restored %s settings, %s groups, %s scenarios",
                             length(res$applied), length(rv$rules),
                             length(rv$scenarios)),
                     type = "message", duration = 6) })

  output$state_status <- renderUI({
    if (is.null(rv$restore)) return(NULL)
    div(class = "note",
        sprintf("Restored %s controls.", length(rv$restore$applied)),
        if (length(rv$restore$skipped))
          tags$div(style = "color:#9a5000",
                   sprintf("Not restored: %s",
                           paste(head(rv$restore$skipped, 8), collapse = ", ")))
        else NULL) })
}

shinyApp(ui, server)
