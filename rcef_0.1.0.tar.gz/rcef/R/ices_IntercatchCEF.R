#' InterCatch exchange format to CEF v17.1
#'
#' @param dat_path folder with intercatch echange format files
#' @param stock_relation
#' @param output_format where should the output go
#' @param out_path if it should be in files, where
#'
#' @returns
#' @export
#'
#' @examples
funIntercatchCEF <- function(dat_path = getwd(),
                             stock_relation = stock_relation,
                             output_format = c("to_environment", "to_file", "to_upload_file"), #
                             out_path = getwd(),
                             file_prefix = "",
                             file_suffix = paste0("_CEF_v", getOption("CEF_version")),
                             include_BMS_Caton = TRUE,
                             patch_missing_DIS_PSU = FALSE,
                             metier6 = NULL) # Delayed evaluation makes it okay!
{
  options("CEF_version" = "17.1")


  ###********************************** Load in intercatch eschange format files ****************************
  lst <- list.files(dat_path, pattern = ".csv", full.names = T)

  print("Creating CEF from:")
  print(basename(lst))

  dat <- rbindlist(lapply(lst, read.csv,
                          col.names = paste0("V", 1:34), header = F, check.names = F),
                   fill = T)

  ## deal with potential white space for some reason..
  cols_to_be_rectified <- names(dat)[vapply(dat, is.character, logical(1))]
  dat[, cols_to_be_rectified] <- lapply(dat[, cols_to_be_rectified, with = F], trimws)

  ## re-code
  dat$V12[dat$V12 %in% c("L", "LAN", "Landings")] <- "Lan"
  dat$V12[dat$V12 %in% c("D", "DIS", "Discards")] <- "Dis"
  dat$V12[dat$V12 %in% "B"] <- "BMS"
  dat$V12[dat$V12 %in% "Logbook Registered Discard"] <- "RegDIS"

  ## table(dat$V12)

  ## intercatch naming
  hi_names <- c("RecordType", "Country", "Year", "SeasonType", "Season",
                "Fleet", "AreaType", "FishingArea", "DepthRange", "UnitEffort",
                "Effort", "AreaQualifier")

  si_names <- c("RecordType","Country","Year", "SeasonType", "Season", "Fleet",
                "AreaType", "FishingArea", "DepthRange", "Species", "Stock_orig",
                "CatchCategory","ReportingCategory","DataToForm","Usage",
                "SamplesOrigin", "QualityFlag", "UnitCaton", "Caton", "OffLandings",
                "VarCaton", "InfoFleet", "InfoStockCoordinator", "InfoGeneral")

  sd_names <- c("RecordType","Country","Year","SeasonType","Season","Fleet",
                "AreaType","FishingArea","DepthRange","Species","Stock_orig",
                "CatchCategory","ReportingCategory","Sex","CANUMtype",
                "AgeLength","PlusGroup","SampledCatch","NumSamplesLngt",
                "NumLngtMeas","NumSamplesAge","NumAgeMeas","UnitMeanWeight",
                "UnitCANUM","UnitAgeOrLength","UnitMeanLength","Maturity",
                "NumberCaught","MeanWeight","MeanLength","varNumLanded",
                "varWgtLanded","varLgtLanded")


  ## split into intercatch formats
  hi <- dat[dat$V1 == "HI", 1:length(hi_names)]
  si <- dat[dat$V1 == "SI", 1:length(si_names)]
  sd <- dat[dat$V1 == "SD", 1:length(sd_names)]

  if(dim(sd)[1]>0){
    sdDAT<-TRUE
  }else{
    sdDAT<-FALSE} # any SD data in the IC file?

  names(hi) <- hi_names
  hi$UnitEffort[hi$UnitEffort == "NA"] <- NA
  names(si) <- si_names
  names(sd) <- sd_names

  ###********************************** create Census catches from SI *********************************

  ## set the match key
  hi$key = paste(hi$Country,
                 hi$Year,
                 hi$Season,
                 hi$FishingArea,
                 hi$Fleet,
                 hi$UnitEffort,
                 sep = "_")

  si$key = paste(si$Country,
                 si$Year,
                 si$Season,
                 si$Species,
                 si$FishingArea,
                 si$Fleet,
                 si$CatchCategory,
                 sep = "_")

  sd$key = paste(sd$Country,
                 sd$Year,
                 sd$Season,
                 sd$Species,
                 sd$FishingArea,
                 sd$Fleet,
                 sd$CatchCategory,
                 sep = "_")

  ## clean up SI

  if (any(duplicated(si$key)))
    warning("\n\n## ", sum(duplicated(si$key)), " dupplicated keys!")

  si <- si[!duplicated(si$key), ] # [YR] Shouldn't there be an error or aggregation instead?
  # [JS] probably, but for me it is mos often an artifact of length and age files with overlapping information

  ## merge with code list for the stock area and wg
  stock_relation$FishingArea <- stock_relation$ICESArea
  si$FishingArea <- as.character(si$FishingArea)

  si <- merge(si, stock_relation, by = c("Species", "FishingArea"), all.x = T)

  if (any(is.na(si$StockCode)))
    warning("\n\n## ", "Stock code was not matched for all records, check 'stock_relation' table")

  ## create domains, and fill in discard domain for covered landings domains.
  si$key2 = paste(si$Country,
                  si$Year,
                  si$Season,
                  si$Species,
                  si$FishingArea,
                  si$Fleet, # Without CatchCategory (for matching across them).
                  sep = "_")
  tbl <- unique(si[, c("key2", "CatchCategory")])

  ## Used keys per catch category:
  has_categ <- sapply(c("Dis", "RegDIS", "BMS"),
                      function(cat)
                      {
                        tbl2 <- tbl[tbl$CatchCategory %in% c(cat, "Lan"), ]
                        tbl2[duplicated(key2), ]$key2
                      }, simplify = FALSE)

  si$domain = paste("IC",
                    si$Season,
                    si$FishingArea,
                    si$Fleet,
                    sep = "_")

  ## create columns for format
  si$domainCatchDis <- ifelse((si$key2 %in% unlist(has_categ[c("Dis", "RegDIS")]) &
                                 si$CatchCategory == "Lan") |
                                si$CatchCategory %in% c("Dis", "RegDIS"),
                              si$domain, NA)

  si$domainCatchBMS <- ifelse((si$key2 %in% has_categ[["BMS"]] &
                                 si$CatchCategory == "Lan") |
                                si$CatchCategory %in% c("BMS"),
                              si$domain, NA)

  si$domainBiology <- ifelse(si$key %in% sd$key,
                             si$domain, NA)


  si$quarter <- ifelse(si$SeasonType == "Quarter",
                       si$Season, NA)

  si <- si[order(si$key), ]

  ###********************************** combined census and estimated catches from SI *********************************
  ## make final table:
  xx <- unique(sd[sd$CatchCategory != "LAN", c("NumSamplesLngt", "key")])
  si <- merge(si, xx, by = "key", all.x = T)

  si$PSU = ifelse(!is.na(si$NumSamplesLngt),
                  "FishingTrip", NA)

  ## hack missing PSU when domain discard is present
  if (patch_missing_DIS_PSU & nrow(si[! is.na(si$domainCatchDis) &
                                  si$CatchCategory == "Dis" & is.na(si$PSU), ]) > 0){

    warning("\n\n## ", "domainCatchDis pressent wiutout PSU, inserting 'fishingTrip' and 0")

    si[! is.na(si$domainCatchDis) & si$CatchCategory == "Dis" &
         is.na(si$PSU), "NumSamplesLngt"] <- 0

    si[! is.na(si$domainCatchDis) & si$CatchCategory == "Dis" &
         is.na(si$PSU), "PSU"] <- "FishingTrip"


  }


  si <- melt(si, measure.vars = c("Caton", "OffLandings"), na.rm = TRUE)

  if (include_BMS_Caton == F)
    si <- si[! (si$variable == "Caton" & si$CatchCategory == "BMS"), ]

  #if no samples for official BMS, then no domain
  si[si$variable == "OffLandings" & is.na(si$PSU)
     & ! is.na(si$domainCatchBMS), "domainCatchBMS"] <- NA

  catches <- data.frame(recordType = "CN",
                        vesselFlagCountry = si$Country,
                        year = si$Year,
                        workingGroup = si$EG,
                        stock = si$StockCode,
                        speciesCode = si$speciesCode,
                        catchCategory	= sub("Logbook Registered Discard|RegDIS", "Dis", si$CatchCategory),
                        seasonType = ifelse(is.na(as.numeric(si$quarter)),
                                            "Year", "Quarter"),
                        seasonValue = ifelse(is.na(as.numeric(si$quarter)),
                                             as.numeric(si$Year),
                                             as.numeric(si$quarter)),
                        areaType = "ICESArea",
                        areaValue = si$FishingArea,
                        fisheriesManagementUnit = NA,
                        metier6 = "MIS_MIS_0_0_0",
                        fleetType = "Fleet",
                        fleetValue = si$Fleet,
                        domainCatchDis = si$domainCatchDis,
                        domainCatchBMS = si$domainCatchBMS,
                        domainBiology = si$domainBiology,
                        originType = ifelse(si$variable == "Caton", "WGEstimate", "Official"),
                        variableType = "WeightLive",
                        variableUnit = si$UnitCaton,
                        total = si$value,
                        variance = NA,
                        PSU = si$PSU,
                        numPSUs = si$NumSamplesLngt,
                        numTrips = si$NumSamplesLngt,
                        comment = si$InfoStockCoordinator)

  if(!is.null(metier6)) {
    if(metier6 == "Fleet") {
      catches <- catches %>%
        dplyr::mutate(metier6 = fleetValue,
                      variableUnit = case_when(variableUnit %in% c("k", "k") ~ "NE3",
                                               ## What is the RDBES unit for 1 indiv.?
                                               TRUE ~ variableUnit))
    }
  }


  ###**************************** create length age and whatever distribution from sd *****************

  if(sdDAT){
    sd <- merge(sd, stock_relation, by = c("Species", "FishingArea"))

    ## recode / create costum columns
    sd$distributionType <- ifelse(tolower(sd$CANUMtype) == "age", "Age", "LengthTotal")
    sd$ageType <- ifelse(sd$distributionType == "Age", "ageyear", "")
    sd$numPSUs <- ifelse(sd$distributionType == "Age", sd$NumSamplesAge, sd$NumSamplesLngt)
    sd$numMeasurements <- ifelse(sd$distributionType == "Age", sd$NumAgeMeas, sd$NumLngtMeas)

    sd$domain = paste("IC",
                      sd$Season,
                      sd$FishingArea,
                      sd$Fleet,
                      sep = "_")

    #stack the data
    sd <- melt(sd, measure.vars = c("NumberCaught", "MeanWeight", "MeanLength"),
               variable.name = "valueType", value.name = "value",
               variable.factor = FALSE, na.rm = TRUE)

    sd <- sd[sd$value != "-9", ]
    sd$Sex[sd$Sex == "N"] <- NA

    sd$unit <- ifelse(sd$valueType == "NumberCaught", sd$UnitCANUM,
                      ifelse(sd$valueType == "MeanWeight", sd$UnitMeanWeight,
                             sd$UnitMeanLength))

    sd[sd$valueType == "NumberCaught", "variableType"] <- "Number"
    sd[sd$valueType == "MeanWeight", "variableType"] <- "WeightLive"
    sd[sd$valueType == "MeanLength", "variableType"] <- "LengthTotal"

    sd$PSU = ifelse(!is.na(sd$numPSUs),
                    "FishingTrip", NA)

    #fix units
    sd$UnitAgeOrLength[sd$UnitAgeOrLength == "year"] <- "y"

    sd$AgeLength <- as.numeric(sd$AgeLength)
    sd[sd$UnitAgeOrLength == "cm", "AgeLength"] <-
      sd[sd$UnitAgeOrLength == "cm", ]$AgeLength*10

    sd$UnitAgeOrLength[sd$UnitAgeOrLength == "cm"] <- "mm"

    #
    sd$value <- as.numeric(sd$value)
    sd[sd$unit == "cm", "value"] <- sd[sd$unit == "cm", ]$value*10
    sd$unit[sd$unit == "cm"] <- "mm"

    #value is restricted to 3 digits so number is changed from 1000 (N3K) to number N as to avoid 0
    sd[sd$unit %in% c("k", "K"), "value"] <- sd[sd$unit %in% c("k", "K"), ]$value * 1000
    sd$unit[sd$unit %in% c("k", "K")] <- "N"

    ## make final table
    distributions <- data.frame(recordType = "DN",
                                vesselFlagCountry = sd$Country,
                                year = sd$Year,
                                workingGroup = sd$EG,
                                stock = sd$StockCode,
                                speciesCode = sd$speciesCode,
                                catchCategory	= sd$CatchCategory,
                                domainBiology = sd$domain,
                                distributionType = sd$distributionType,
                                distributionUnit = sd$UnitAgeOrLength,
                                distributionClass	= sd$AgeLength,
                                ageGroupPlus = ifelse(sd$PlusGroup == "-9", NA,
                                                      as.numeric(sd$PlusGroup)),
                                attributeType = ifelse(! is.na(sd$Sex), "Sex", NA),
                                attributeValue = sd$Sex,
                                variableType = sd$variableType,
                                variableUnit = sd$unit,
                                valueType = ifelse(sd$valueType %like% "Mean",
                                                   "Mean", "Total"),
                                value = round(sd$value, 3),
                                variance = NA,
                                PSU = sd$PSU,
                                numPSUs = as.numeric(sd$numPSUs),
                                numTrips = as.numeric(sd$numPSUs),
                                numMeasurements = sd$numMeasurements)
  }

  ###**************************** effort data from HI *****************
  setDT(hi)
  hi <- hi[! is.na(hi$UnitEffort) & !duplicated(hi$key), ]


  if(nrow(hi) == 0){
    print("warning: no UnitEffort is present in IC, returning empty effort table")
    effort<-data.table()
  } else{

    ## code translate
    hi$quarter <- ifelse(hi$SeasonType == "Quarter",
                         hi$Season, NA)

    # code adjust,ents
    hi$UnitEffort[hi$UnitEffort == "dop"] <- "das"

    ## sum by key
    hi$Effort <- as.numeric(hi$Effort)
    hi <- hi[ ,. (total = sum(Effort)),
              by = .(Country, Year, quarter, Season, FishingArea,
                     Fleet, UnitEffort, key)]

    ## add aditional information
    area_wg <- stock_relation[stock_relation$EG %in% sd$EG, ]
    area_wg <- unique(area_wg[, c("FishingArea", "EG")])

    area_wg$UnitEffort <- ifelse(area_wg$EG == "WGBFAS", "das", "kWd")
    hi$FishingArea <- as.character(hi$FishingArea)

    hi <- merge(hi, area_wg, by = c("FishingArea", "UnitEffort"))



    #order and output format
    hi <- hi[order(hi$key), ]
    effort <- data.frame(recordType = "EN",
                         vesselFlagCountry = hi$Country,
                         year = hi$Year,
                         workingGroup = hi$EG,
                         seasonType = ifelse(is.na(as.numeric(hi$quarter)),
                                             "Year", "Quarter"),
                         seasonValue = ifelse(is.na(as.numeric(hi$quarter)),
                                              as.numeric(hi$Year),
                                              as.numeric(hi$quarter)),
                         areaType = "ICESArea",
                         areaValue = hi$FishingArea,
                         fisheriesManagementUnit = "",
                         metier6 = "MIS_MIS_0_0_0",
                         fleetType = "WGFleet",
                         fleetValue = hi$Fleet,
                         originType = "WGEstimate",
                         variableType = hi$UnitEffort,
                         total = as.numeric(hi$total)
    )


    if(!is.null(metier6)) {
      if(metier6 == "Fleet") {
        effort <- effort %>%
        dplyr::mutate(metier6 = fleetValue)

        }

      }

    }


  # clean up domains





  ###**************************** output results to environment or file *****************
  if ("to_environment" %in% output_format)
  {
    attr(catches, "CEF_version") <- getOption("CEF_version")
    if(sdDAT) attr(distributions, "CEF_version") <- getOption("CEF_version")
    attr(effort, "CEF_version") <- getOption("CEF_version")

    assign("catches", catches, .GlobalEnv)
    if(sdDAT) assign("distributions", distributions, .GlobalEnv)
    assign("effort", effort, .GlobalEnv)

  }
  if ("to_file" %in% output_format)
  {
    write.csv(catches,
              file = file.path(out_path,
                               paste0(file_prefix, "catches", file_suffix, ".csv")),
              row.names = FALSE, quote = FALSE,  na = "")
    if(sdDAT)
      write.csv(distributions,                                     #### JCedit  if(sdDAT)
                         file = file.path(out_path,
                                          paste0(file_prefix, "distributions", file_suffix, ".csv")),
                         row.names = FALSE, quote = FALSE,  na = "")
    write.csv(effort,
              file = file.path(out_path,
                               paste0(file_prefix, "effort", file_suffix, ".csv")),
              row.names = FALSE, quote = FALSE,  na = "")
  }

  if("to_upload" %in% output_format)
  {
    write.table(catches,
              file = file.path(out_path,
                               paste0(file_prefix, "CEF", file_suffix, "_HNI.csv")),
              row.names = F, quote = F, na = "", col.names = F, sep = ",")
    if(sdDAT)
      write.table(distributions,                                     #### JCedit  if(sdDAT)
                         file = file.path(out_path,
                                          paste0(file_prefix, "CEF", file_suffix, "_HNI.csv")),
                  row.names = F, quote = F, na = "", col.names = F, sep = ",",
                  append = T)

    write.table(effort,
              file = file.path(out_path,
                               paste0(file_prefix, "effort", file_suffix, "_HEN.csv")),
              row.names = F, quote = F, na = "", col.names = F, sep = ",")
  }

  if("to_list" %in% output_format)
  {
    res <- list("catches" = catches,
                "distributions"= distributions,
                "effort"= effort)
    attr(res, "CEF_version") <- getOption("CEF_version")

    return(res)
  }
}
