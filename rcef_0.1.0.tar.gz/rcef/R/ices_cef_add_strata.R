' Add strata Columns to Census Data
#'
#' This function creates various strata combinations from census catch data
#' by combining different dimensions (country, seasonValue, fleetValue, area, gear levels)
#' to support stratified sampling and analysis procedures. It generates gear
#' classifications and creates all possible strata combinations for flexible
#' data aggregation.
#'
#' @param df_cef Data frame. Census catches data frame containing fisheries
#'   data with columns: vesselFlagCountry, seasonValue, fleetValue, area, stock, and
#'   metier6. Typically the output from \code{convExchange_tidy()} function.
#'
#' @details
#' The function performs several key operations:
#' \itemize{
#'   \item Creates gear classifications from metier6 codes:
#'     \itemize{
#'       \item \code{gear}: First 3 characters of metier6
#'       \item \code{super_gear}: First character of gear, with special mappings
#'     }
#'   \item Generates strata combinations using all possible combinations of:
#'     \itemize{
#'       \item c = vesselFlagCountry
#'       \item q = seasonValue
#'       \item f = fleetValue
#'       \item a = area
#'       \item g = gear (3-character)
#'       \item sg = super_gear (1-character)
#'       \item lvl6 = metier6 (full 6-character code)
#'     }
#'   \item Converts fleetValue to factor for consistent handling
#'   \item Creates a full strata identifier combining stock and all dimensions
#' }
#'
#' @section Gear Classification Logic:
#' The function creates hierarchical gear classifications:
#' \itemize{
#'   \item \strong{gear}: First 3 characters of metier6 (e.g., "OTM", "GNS")
#'   \item \strong{super_gear}: Simplified gear categories with special mappings:
#'     \itemize{
#'       \item "OTM" → "P" (Pelagic trawl)
#'       \item "TTB" → "O" (Other trawl)
#'       \item "TBB" → "O" (Other trawl)
#'       \item "PTB" → "O" (Other trawl)
#'       \item "PS" → "S" (Seine)
#'       \item Others → First character of gear
#'     }
#' }
#'
#' @section strata Naming Convention:
#' strata names follow the pattern \code{strata_[dimensions]_[gear_level]}:
#' \itemize{
#'   \item Base combinations: c, q, f, a and their combinations
#'   \item Gear-enhanced: same combinations + g (gear)
#'   \item Super-gear-enhanced: same combinations + sg (super_gear)
#'   \item Level-6-enhanced: same combinations + lvl6 (metier6)
#' }
#'
#' Examples: \code{strata_c_q} (country-seasonValue), \code{strata_f_a_g} (fleetValue-area-gear)
#'
#' @returns
#' Data frame. The input data frame with additional columns:
#' \itemize{
#'   \item \code{fleetValue}: Converted to factor
#'   \item \code{strata_full}: Complete strata identifier with stock
#'   \item \code{gear}: 3-character gear code from metier6
#'   \item \code{super_gear}: 1-character simplified gear category
#'   \item \code{strata_*}: 63 different strata combination columns
#' }
#'
#' @section Required Packages:
#' The function requires the following packages:
#' \itemize{
#'   \item \code{dplyr}: For data manipulation
#'   \item \code{forcats}: For factor handling
#'   \item \code{glue}: For string interpolation
#'   \item \code{stringr}: For string manipulation
#' }
#'
#' @section Input Data Requirements:
#' The input data frame must contain the following columns:
#' \itemize{
#'   \item \code{vesselFlagCountry}: Country code
#'   \item \code{seasonValue}: Time seasonValue
#'   \item \code{fleetValue}: fleetValue identifier
#'   \item \code{area}: Fishing area
#'   \item \code{stock}: Stock identifier
#'   \item \code{metier6}: 6-character metier code
#' }
#'
#' @examples
#' \dontrun{
#' # Add strata columns to census data
#' census_with_strata <- census_add_strata(census_catches)
#'
#' # View the new strata columns
#' names(census_with_strata)[grepl("strata_", names(census_with_strata))]
#'
#' # Example: aggregate by country-seasonValue strata
#' library(dplyr)
#' census_with_strata %>%
#'   group_by(strata_c_q) %>%
#'   summarise(total_catch = sum(total, na.rm = TRUE))
#' }
#'
#' @seealso
#' \code{census_remove_strata} to remove strata columns
#' \code{convExchange_tidy} to generate census data
#'
#' @author Jean-Baptiste Lecomte
#' @export
#'
cef_add_strata <- function(df_cef,
                              only_full_strata = FALSE) {

  if(only_full_strata) {
    df_cef <- df_cef %>%
      dplyr::mutate(
        fleetValue = forcats::as_factor(.data$fleetValue),
        strata_full = forcats::as_factor(glue::glue("{stock};{vesselFlagCountry};q{seasonValue};{areaValue};{fleetValue};{metier6}")))
  } else {
  df_cef <- df_cef %>%
    dplyr::mutate(
      fleetValue = forcats::as_factor(.data$fleetValue),
      strata_full = forcats::as_factor(glue::glue("{stock};{vesselFlagCountry};q{seasonValue};{areaValue};{fleetValue};{metier6}")),
      gear = stringr::str_sub(string = .data$metier6, start = 1,  end = 3),
      super_gear = stringr::str_sub(string = .data$gear, start = 1, end = 1),
      super_gear = dplyr::case_when(gear == "OTM" ~ "P",
                                    gear == "TTB" ~ "O",
                                    gear == "TBB" ~ "O",
                                    gear == "PTB" ~ "O",
                                    gear == "PS" ~ "S",
                                    TRUE ~ super_gear),

      # Top combinations
      strata_c_q_f_a = glue::glue("{vesselFlagCountry};q{seasonValue};{fleetValue};{areaValue}"),
      strata_c_q_f = glue::glue("{vesselFlagCountry};q{seasonValue};{fleetValue}"),
      strata_c_q_a = glue::glue("{vesselFlagCountry};q{seasonValue};{areaValue}"),
      strata_c_q = glue::glue("{vesselFlagCountry};q{seasonValue}"),
      strata_c_f_a = glue::glue("{vesselFlagCountry};{fleetValue};{areaValue}"),
      strata_c_f = glue::glue("{vesselFlagCountry};{fleetValue}"),
      strata_c_a = glue::glue("{vesselFlagCountry};{areaValue}"),
      strata_c = glue::glue("{vesselFlagCountry}"),
      strata_q_f_a = glue::glue("q{seasonValue};{fleetValue};{areaValue}"),
      strata_q_f = glue::glue("q{seasonValue};{fleetValue}"),
      strata_q_a = glue::glue("q{seasonValue};{areaValue}"),
      strata_q = glue::glue("q{seasonValue}"),
      strata_f_a = glue::glue("{fleetValue};{areaValue}"),
      strata_f = glue::glue("{fleetValue}"),
      strata_a = glue::glue("{areaValue}"),

      # Combinations with gear
      strata_c_q_f_a_g = glue::glue("{vesselFlagCountry};q{seasonValue};{fleetValue};{areaValue};{gear}"),
      strata_c_q_f_g = glue::glue("{vesselFlagCountry};q{seasonValue};{fleetValue};{gear}"),
      strata_c_q_a_g = glue::glue("{vesselFlagCountry};q{seasonValue};{areaValue};{gear}"),
      strata_c_q_g = glue::glue("{vesselFlagCountry};q{seasonValue};{gear}"),
      strata_c_f_a_g = glue::glue("{vesselFlagCountry};{fleetValue};{areaValue};{gear}"),
      strata_c_f_g = glue::glue("{vesselFlagCountry};{fleetValue};{gear}"),
      strata_c_a_g = glue::glue("{vesselFlagCountry};{areaValue};{gear}"),
      strata_c_g = glue::glue("{vesselFlagCountry};{gear}"),
      strata_q_f_a_g = glue::glue("q{seasonValue};{fleetValue};{areaValue};{gear}"),
      strata_q_f_g = glue::glue("q{seasonValue};{fleetValue};{gear}"),
      strata_q_a_g = glue::glue("q{seasonValue};{areaValue};{gear}"),
      strata_q_g = glue::glue("q{seasonValue};{gear}"),
      strata_f_a_g = glue::glue("{fleetValue};{areaValue};{gear}"),
      strata_f_g = glue::glue("{fleetValue};{gear}"),
      strata_a_g = glue::glue("{areaValue};{gear}"),
      strata_g = glue::glue("{gear}"),

      # Combinations with super_gear
      strata_c_q_f_a_sg = glue::glue("{vesselFlagCountry};q{seasonValue};{fleetValue};{areaValue};{super_gear}"),
      strata_c_q_f_sg = glue::glue("{vesselFlagCountry};q{seasonValue};{fleetValue};{super_gear}"),
      strata_c_q_a_sg = glue::glue("{vesselFlagCountry};q{seasonValue};{areaValue};{super_gear}"),
      strata_c_q_sg = glue::glue("{vesselFlagCountry};q{seasonValue};{super_gear}"),
      strata_c_f_a_sg = glue::glue("{vesselFlagCountry};{fleetValue};{areaValue};{super_gear}"),
      strata_c_f_sg = glue::glue("{vesselFlagCountry};{fleetValue};{super_gear}"),
      strata_c_a_sg = glue::glue("{vesselFlagCountry};{areaValue};{super_gear}"),
      strata_c_sg = glue::glue("{vesselFlagCountry};{super_gear}"),
      strata_q_f_a_sg = glue::glue("q{seasonValue};{fleetValue};{areaValue};{super_gear}"),
      strata_q_f_sg = glue::glue("q{seasonValue};{fleetValue};{super_gear}"),
      strata_q_a_sg = glue::glue("q{seasonValue};{areaValue};{super_gear}"),
      strata_q_sg = glue::glue("q{seasonValue};{super_gear}"),
      strata_f_a_sg = glue::glue("{fleetValue};{areaValue};{super_gear}"),
      strata_f_sg = glue::glue("{fleetValue};{super_gear}"),
      strata_a_sg = glue::glue("{areaValue};{super_gear}"),
      strata_sg = glue::glue("{super_gear}"),

      # Combinations with metier6
      strata_c_q_f_a_lvl6 = glue::glue("{vesselFlagCountry};q{seasonValue};{fleetValue};{areaValue};{metier6}"),
      strata_c_q_f_lvl6 = glue::glue("{vesselFlagCountry};q{seasonValue};{fleetValue};{metier6}"),
      strata_c_q_a_lvl6 = glue::glue("{vesselFlagCountry};q{seasonValue};{areaValue};{metier6}"),
      strata_c_q_lvl6 = glue::glue("{vesselFlagCountry};q{seasonValue};{metier6}"),
      strata_c_f_a_lvl6 = glue::glue("{vesselFlagCountry};{fleetValue};{areaValue};{metier6}"),
      strata_c_f_lvl6 = glue::glue("{vesselFlagCountry};{fleetValue};{metier6}"),
      strata_c_a_lvl6 = glue::glue("{vesselFlagCountry};{areaValue};{metier6}"),
      strata_c_lvl6 = glue::glue("{vesselFlagCountry};{metier6}"),
      strata_q_f_a_lvl6 = glue::glue("q{seasonValue};{fleetValue};{areaValue};{metier6}"),
      strata_q_f_lvl6 = glue::glue("q{seasonValue};{fleetValue};{metier6}"),
      strata_q_a_lvl6 = glue::glue("q{seasonValue};{areaValue};{metier6}"),
      strata_q_lvl6 = glue::glue("q{seasonValue};{metier6}"),
      strata_f_a_lvl6 = glue::glue("{fleetValue};{areaValue};{metier6}"),
      strata_f_lvl6 = glue::glue("{fleetValue};{metier6}"),
      strata_a_lvl6 = glue::glue("{areaValue};{metier6}"),
      strata_lvl6 = glue::glue("{metier6}")
    )
  }
  return(df_cef)
}

#' Remove strata Columns from Census Data
#'
#' This function removes all strata-related columns from a census data frame,
#' keeping only the \code{strata_full} column. This is useful for cleaning up
#' data after stratified analysis or when strata columns are no longer needed.
#'
#' @param df_cef Data frame. Census data with strata columns, typically
#'   the output from \code{census_add_strata()} function.
#' @param extra_strata a character vector with strata names to be kept.
#'
#' @details
#' The function removes all columns that start with "strata_" except for
#' \code{strata_full}. This includes:
#' \itemize{
#'   \item All basic strata combinations (e.g., \code{strata_c}, \code{strata_q})
#'   \item All gear-enhanced combinations (e.g., \code{strata_c_g})
#'   \item All super-gear combinations (e.g., \code{strata_c_sg})
#'   \item All level-6 metier combinations (e.g., \code{strata_c_lvl6})
#' }
#'
#' The \code{strata_full} column is preserved as it contains the complete
#' strata identifier that may be needed for referencing or joining operations.
#'
#' @returns
#' Data frame. The input data frame with all strata columns removed except
#' \code{strata_full}. The gear classification columns (\code{gear},
#' \code{super_gear}) are also removed if they were created by
#' \code{census_add_strata()}.
#'
#' @section Required Packages:
#' The function requires the following packages:
#' \itemize{
#'   \item \code{dplyr}: For data manipulation and column selection
#' }
#'
#' @examples
#' \dontrun{
#' # Add strata columns
#' census_with_strata <- census_add_strata(census_catches)
#'
#' # Check column count before removal
#' ncol(census_with_strata)
#'
#' # Remove strata columns
#' census_cleaned <- census_remove_strata(census_with_strata)
#'
#' # Check column count after removal
#' ncol(census_cleaned)
#'
#' # Verify strata_full is still present
#' "strata_full" %in% names(census_cleaned)
#' }
#'
#' @seealso
#' \code{census_add_strata} to add strata columns
#'
#' @note
#' This function uses a logical OR operation in the \code{dplyr::select()}
#' statement to exclude columns starting with "strata_" while keeping
#' \code{strata_full}. The syntax \code{-starts_with("strata_") | strata_full}
#' means "exclude columns starting with 'strata_' OR keep strata_full".
#'
#' @author Jean-Baptiste Lecomte
#' @export
cef_remove_strata <- function(df_cef, extra_strata = NULL) {

  cols_to_keep <- c("strata_full", extra_strata)

  df_cef <- df_cef %>%
    dplyr::select(-dplyr::starts_with("strata_") | dplyr::any_of(cols_to_keep))

  return(df_cef)
}

###



#' Generate Unique strata Combinations from Census Data
#'
#' This function creates lists of unique strata labels based on specified combinations
#' of hierarchical grouping columns from a census-like data frame. It also derives new
#' gear columns and supports optional selection of specific strata groupings.
#'
#' @param df_cef A data frame containing census or survey data. Must include columns
#'        such as vesselFlagCountry, seasonValue, fleetValue, area, and metier6.
#' @param selected_strata Optional character vector of strata names to limit the output.
#'        If NULL, all strata combinations defined in the function will be used.
#'
#' @details
#' The function derives additional gear columns (`gear`, `super_gear`) from the `metier6`
#' column to support more granular or aggregated gear stratifications. It defines multiple
#' strata groupings (e.g., by country, seasonValue, fleetValue, area, gear, etc.), and, for each,
#' produces a vector of unique string labels corresponding to present combinations in the data.
#' If `selected_strata` is provided, the output will be restricted to those groups, warning about
#' any requested group not defined in the mapping.
#'
#' @return A named list. Each entry is a character vector of unique strata labels for the
#'         grouping, with values concatenated by "-".
#'
#' @examples
#' \dontrun{
#' result <- generate_strata_combinations(df_cef)
#' # Limit to specific strata
#' result <- generate_strata_combinations(df_cef, selected_strata = c('strata_c_q_f_a', 'strata_f'))
#' }
#'
#' @export
cef_generate_strata_combinations <- function(df_cef, selected_strata = NULL) {
  # Prepare any derived columns needed for combinations (like gear, super_gear)
  df_processed <- dplyr::mutate(
    df_cef,
    gear = stringr::str_sub(metier6, 1, 3),
    super_gear = stringr::str_sub(gear, 1, 1),
    super_gear = dplyr::case_when(
      gear == "OTM" ~ "P",
      gear %in% c("TTB", "TBB", "PTB") ~ "O",
      gear == "PS" ~ "S",
      TRUE ~ super_gear
    )
  )
  # Define lists of column sets with their strata names
  strata_cols <- list(
    strata_c_q_f_a = c("vesselFlagCountry", "seasonValue", "fleetValue", "areaValue"),
    strata_c_q_f = c("vesselFlagCountry", "seasonValue", "fleetValue"),
    strata_c_q_a = c("vesselFlagCountry", "seasonValue", "areaValue"),
    strata_c_q = c("vesselFlagCountry", "seasonValue"),
    strata_c_f_a = c("vesselFlagCountry", "fleetValue", "areaValue"),
    strata_c_f = c("vesselFlagCountry", "fleetValue"),
    strata_c_a = c("vesselFlagCountry", "areaValue"),
    strata_c = c("vesselFlagCountry"),
    strata_q_f_a = c("seasonValue", "fleetValue", "areaValue"),
    strata_q_f = c("seasonValue", "fleetValue"),
    strata_q_a = c("seasonValue", "areaValue"),
    strata_q = c("seasonValue"),
    strata_f_a = c("fleetValue", "areaValue"),
    strata_f = c("fleetValue"),
    strata_a = c("areaValue"),
    # with gear
    strata_c_q_f_a_g = c("vesselFlagCountry", "seasonValue", "fleetValue", "areaValue", "gear"),
    strata_c_q_f_g = c("vesselFlagCountry", "seasonValue", "fleetValue", "gear"),
    strata_c_q_a_g = c("vesselFlagCountry", "seasonValue", "areaValue", "gear"),
    strata_c_q_g = c("vesselFlagCountry", "seasonValue", "gear"),
    strata_c_f_a_g = c("vesselFlagCountry", "fleetValue", "areaValue", "gear"),
    strata_c_f_g = c("vesselFlagCountry", "fleetValue", "gear"),
    strata_c_a_g = c("vesselFlagCountry", "areaValue", "gear"),
    strata_c_g = c("vesselFlagCountry", "gear"),
    strata_q_f_a_g = c("seasonValue", "fleetValue", "areaValue", "gear"),
    strata_q_f_g = c("seasonValue", "fleetValue", "gear"),
    strata_q_a_g = c("seasonValue", "areaValue", "gear"),
    strata_q_g = c("seasonValue", "gear"),
    strata_f_a_g = c("fleetValue", "areaValue", "gear"),
    strata_f_g = c("fleetValue", "gear"),
    strata_a_g = c("areaValue", "gear"),
    strata_g = c("gear"),
    # with super_gear
    strata_c_q_f_a_sg = c("vesselFlagCountry", "seasonValue", "fleetValue", "areaValue", "super_gear"),
    strata_c_q_f_sg = c("vesselFlagCountry", "seasonValue", "fleetValue", "super_gear"),
    strata_c_q_a_sg = c("vesselFlagCountry", "seasonValue", "areaValue", "super_gear"),
    strata_c_q_sg = c("vesselFlagCountry", "seasonValue", "super_gear"),
    strata_c_f_a_sg = c("vesselFlagCountry", "fleetValue", "areaValue", "super_gear"),
    strata_c_f_sg = c("vesselFlagCountry", "fleetValue", "super_gear"),
    strata_c_a_sg = c("vesselFlagCountry", "areaValue", "super_gear"),
    strata_c_sg = c("vesselFlagCountry", "super_gear"),
    strata_q_f_a_sg = c("seasonValue", "fleetValue", "areaValue", "super_gear"),
    strata_q_f_sg = c("seasonValue", "fleetValue", "super_gear"),
    strata_q_a_sg = c("seasonValue", "areaValue", "super_gear"),
    strata_q_sg = c("seasonValue", "super_gear"),
    strata_f_a_sg = c("fleetValue", "areaValue", "super_gear"),
    strata_f_sg = c("fleetValue", "super_gear"),
    strata_a_sg = c("areaValue", "super_gear"),
    strata_sg = c("super_gear"),
    # with metier6
    strata_c_q_f_a_lvl6 = c("vesselFlagCountry", "seasonValue", "fleetValue", "areaValue", "metier6"),
    strata_c_q_f_lvl6 = c("vesselFlagCountry", "seasonValue", "fleetValue", "metier6"),
    strata_c_q_a_lvl6 = c("vesselFlagCountry", "seasonValue", "areaValue", "metier6"),
    strata_c_q_lvl6 = c("vesselFlagCountry", "seasonValue", "metier6"),
    strata_c_f_a_lvl6 = c("vesselFlagCountry", "fleetValue", "areaValue", "metier6"),
    strata_c_f_lvl6 = c("vesselFlagCountry", "fleetValue", "metier6"),
    strata_c_a_lvl6 = c("vesselFlagCountry", "areaValue", "metier6"),
    strata_c_lvl6 = c("vesselFlagCountry", "metier6"),
    strata_q_f_a_lvl6 = c("seasonValue", "fleetValue", "areaValue", "metier6"),
    strata_q_f_lvl6 = c("seasonValue", "fleetValue", "metier6"),
    strata_q_a_lvl6 = c("seasonValue", "areaValue", "metier6"),
    strata_q_lvl6 = c("seasonValue", "metier6"),
    strata_f_a_lvl6 = c("fleetValue", "areaValue", "metier6"),
    strata_f_lvl6 = c("fleetValue", "metier6"),
    strata_a_lvl6 = c("areaValue", "metier6"),
    strata_lvl6 = c("metier6")
  )
  # If selected_strata given, filter the list keys accordingly
  if (!is.null(selected_strata)) {
    missing_strata <- setdiff(selected_strata, names(strata_cols))
    if (length(missing_strata) > 0) {
      warning("Some selected strata names not found: ", paste(missing_strata, collapse = ", "))
    }
    strata_cols <- strata_cols[names(strata_cols) %in% selected_strata]
  }
  # For each defined combination, extract unique pasted labels
  strata_list <- purrr::map(strata_cols, function(cols) {
    present_cols <- base::intersect(cols, base::names(df_processed))
    if (length(present_cols) == 0) {
      return(character(0))
    }
    df_processed %>%
      dplyr::select(tidyselect::all_of(present_cols)) %>%
      dplyr::distinct() %>%
      tidyr::unite("strata_label", tidyselect::everything(), sep = "-") %>%
      dplyr::pull(strata_label)
  })
  return(strata_list)
}

#' Rebuild strata columns from strata_full
#'
#' This function reconstructs the component columns and all strata_* columns
#' from an existing `strata_full` column created by `cef_add_strata()`.
#'
#' Expected strata_full format:
#'   {stock};{vesselFlagCountry};q{seasonValue};{areaValue};{fleetValue};{metier6}
#'
#' @param df_cef A data frame containing at least a `strata_full` column.
#'
#' @returns
#' The input data frame with reconstructed columns:
#' `stock`, `vesselFlagCountry`, `seasonValue`, `areaValue`, `fleetValue`,
#' `metier6`, `gear`, `super_gear`, and all `strata_*` columns.
#'
#' @export
cef_expand_strata_full <- function(df_cef) {

  if (!"strata_full" %in% names(df_cef)) {
    stop("`df_cef` must contain a `strata_full` column.")
  }

  df_cef <- df_cef %>%
    dplyr::mutate(strata_full = as.character(.data$strata_full)) %>%
    tidyr::separate(
      col = "strata_full",
      into = c("stock", "vesselFlagCountry", "season_part", "areaValue", "fleetValue", "metier6"),
      sep = ";",
      remove = FALSE
    ) %>%
    dplyr::mutate(
      seasonValue = as.character(stringr::str_remove(.data$season_part, "^q")),
      fleetValue = forcats::as_factor(.data$fleetValue),
      gear = stringr::str_sub(.data$metier6, 1, 3),
      super_gear = stringr::str_sub(.data$gear, 1, 1),
      super_gear = dplyr::case_when(
        .data$gear == "OTM" ~ "P",
        .data$gear %in% c("TTB", "TBB", "PTB") ~ "O",
        .data$gear == "PS" ~ "S",
        TRUE ~ .data$super_gear
      )
    ) %>%
    dplyr::select(-.data$season_part) %>%
    dplyr::mutate(

      # Base combinations
      strata_c_q_f_a = glue::glue("{vesselFlagCountry};q{seasonValue};{fleetValue};{areaValue}"),
      strata_c_q_f   = glue::glue("{vesselFlagCountry};q{seasonValue};{fleetValue}"),
      strata_c_q_a   = glue::glue("{vesselFlagCountry};q{seasonValue};{areaValue}"),
      strata_c_q     = glue::glue("{vesselFlagCountry};q{seasonValue}"),
      strata_c_f_a   = glue::glue("{vesselFlagCountry};{fleetValue};{areaValue}"),
      strata_c_f     = glue::glue("{vesselFlagCountry};{fleetValue}"),
      strata_c_a     = glue::glue("{vesselFlagCountry};{areaValue}"),
      strata_c       = glue::glue("{vesselFlagCountry}"),
      strata_q_f_a   = glue::glue("q{seasonValue};{fleetValue};{areaValue}"),
      strata_q_f     = glue::glue("q{seasonValue};{fleetValue}"),
      strata_q_a     = glue::glue("q{seasonValue};{areaValue}"),
      strata_q       = glue::glue("q{seasonValue}"),
      strata_f_a     = glue::glue("{fleetValue};{areaValue}"),
      strata_f       = glue::glue("{fleetValue}"),
      strata_a       = glue::glue("{areaValue}"),

      # With gear
      strata_c_q_f_a_g = glue::glue("{vesselFlagCountry};q{seasonValue};{fleetValue};{areaValue};{gear}"),
      strata_c_q_f_g   = glue::glue("{vesselFlagCountry};q{seasonValue};{fleetValue};{gear}"),
      strata_c_q_a_g   = glue::glue("{vesselFlagCountry};q{seasonValue};{areaValue};{gear}"),
      strata_c_q_g     = glue::glue("{vesselFlagCountry};q{seasonValue};{gear}"),
      strata_c_f_a_g   = glue::glue("{vesselFlagCountry};{fleetValue};{areaValue};{gear}"),
      strata_c_f_g     = glue::glue("{vesselFlagCountry};{fleetValue};{gear}"),
      strata_c_a_g     = glue::glue("{vesselFlagCountry};{areaValue};{gear}"),
      strata_c_g       = glue::glue("{vesselFlagCountry};{gear}"),
      strata_q_f_a_g   = glue::glue("q{seasonValue};{fleetValue};{areaValue};{gear}"),
      strata_q_f_g     = glue::glue("q{seasonValue};{fleetValue};{gear}"),
      strata_q_a_g     = glue::glue("q{seasonValue};{areaValue};{gear}"),
      strata_q_g       = glue::glue("q{seasonValue};{gear}"),
      strata_f_a_g     = glue::glue("{fleetValue};{areaValue};{gear}"),
      strata_f_g       = glue::glue("{fleetValue};{gear}"),
      strata_a_g       = glue::glue("{areaValue};{gear}"),
      strata_g         = glue::glue("{gear}"),

      # With super_gear
      strata_c_q_f_a_sg = glue::glue("{vesselFlagCountry};q{seasonValue};{fleetValue};{areaValue};{super_gear}"),
      strata_c_q_f_sg   = glue::glue("{vesselFlagCountry};q{seasonValue};{fleetValue};{super_gear}"),
      strata_c_q_a_sg   = glue::glue("{vesselFlagCountry};q{seasonValue};{areaValue};{super_gear}"),
      strata_c_q_sg     = glue::glue("{vesselFlagCountry};q{seasonValue};{super_gear}"),
      strata_c_f_a_sg   = glue::glue("{vesselFlagCountry};{fleetValue};{areaValue};{super_gear}"),
      strata_c_f_sg     = glue::glue("{vesselFlagCountry};{fleetValue};{super_gear}"),
      strata_c_a_sg     = glue::glue("{vesselFlagCountry};{areaValue};{super_gear}"),
      strata_c_sg       = glue::glue("{vesselFlagCountry};{super_gear}"),
      strata_q_f_a_sg   = glue::glue("q{seasonValue};{fleetValue};{areaValue};{super_gear}"),
      strata_q_f_sg     = glue::glue("q{seasonValue};{fleetValue};{super_gear}"),
      strata_q_a_sg     = glue::glue("q{seasonValue};{areaValue};{super_gear}"),
      strata_q_sg       = glue::glue("q{seasonValue};{super_gear}"),
      strata_f_a_sg     = glue::glue("{fleetValue};{areaValue};{super_gear}"),
      strata_f_sg       = glue::glue("{fleetValue};{super_gear}"),
      strata_a_sg       = glue::glue("{areaValue};{super_gear}"),
      strata_sg         = glue::glue("{super_gear}"),

      # With metier6
      strata_c_q_f_a_lvl6 = glue::glue("{vesselFlagCountry};q{seasonValue};{fleetValue};{areaValue};{metier6}"),
      strata_c_q_f_lvl6   = glue::glue("{vesselFlagCountry};q{seasonValue};{fleetValue};{metier6}"),
      strata_c_q_a_lvl6   = glue::glue("{vesselFlagCountry};q{seasonValue};{areaValue};{metier6}"),
      strata_c_q_lvl6     = glue::glue("{vesselFlagCountry};q{seasonValue};{metier6}"),
      strata_c_f_a_lvl6   = glue::glue("{vesselFlagCountry};{fleetValue};{areaValue};{metier6}"),
      strata_c_f_lvl6     = glue::glue("{vesselFlagCountry};{fleetValue};{metier6}"),
      strata_c_a_lvl6     = glue::glue("{vesselFlagCountry};{areaValue};{metier6}"),
      strata_c_lvl6       = glue::glue("{vesselFlagCountry};{metier6}"),
      strata_q_f_a_lvl6   = glue::glue("q{seasonValue};{fleetValue};{areaValue};{metier6}"),
      strata_q_f_lvl6     = glue::glue("q{seasonValue};{fleetValue};{metier6}"),
      strata_q_a_lvl6     = glue::glue("q{seasonValue};{areaValue};{metier6}"),
      strata_q_lvl6       = glue::glue("q{seasonValue};{metier6}"),
      strata_f_a_lvl6     = glue::glue("{fleetValue};{areaValue};{metier6}"),
      strata_f_lvl6       = glue::glue("{fleetValue};{metier6}"),
      strata_a_lvl6       = glue::glue("{areaValue};{metier6}"),
      strata_lvl6         = glue::glue("{metier6}")
    )

  return(df_cef)
}
